package com.example.data.firebase

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.data.dao.DriverDao
import com.example.data.dao.DriverPaymentDao
import com.example.data.dao.HisabDao
import com.example.data.dao.TruckDao
import com.example.data.dao.UserDao
import com.example.data.model.Driver
import com.example.data.model.DriverPayment
import com.example.data.model.HisabEntry
import com.example.data.model.Truck
import com.example.data.model.UserAccount
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class FirestoreSyncService(
  private val context: Context,
  private val userDao: UserDao,
  private val driverDao: DriverDao,
  private val hisabDao: HisabDao,
  private val paymentDao: DriverPaymentDao,
  private val truckDao: TruckDao
) {
  val auth = Firebase.auth

  // CRITICAL: Always initialize Firestore using R.string.firestore_database_id
  val db: FirebaseFirestore by lazy {
    FirebaseFirestore.getInstance(context.getString(R.string.firestore_database_id))
  }

  private val _currentFirebaseUser = MutableStateFlow<FirebaseUser?>(auth.currentUser)
  val currentFirebaseUser: StateFlow<FirebaseUser?> = _currentFirebaseUser.asStateFlow()

  private val credentialManager = CredentialManager.create(context)
  private var driverListenerRegistration: ListenerRegistration? = null
  private var hisabListenerRegistration: ListenerRegistration? = null
  private var paymentListenerRegistration: ListenerRegistration? = null
  private var truckListenerRegistration: ListenerRegistration? = null

  init {
    auth.addAuthStateListener { firebaseAuth ->
      val user = firebaseAuth.currentUser
      _currentFirebaseUser.value = user
      if (user != null) {
        startSync(user.uid)
      } else {
        stopSync()
      }
    }
  }

  fun signInWithGoogle(
    activity: Activity,
    onSuccess: (FirebaseUser) -> Unit,
    onError: (String) -> Unit,
    onCancelled: () -> Unit = {}
  ) {
    val clientId = try {
      context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
      onError("Google Client ID configuration missing.")
      return
    }

    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

    CoroutineScope(Dispatchers.Main).launch {
      try {
        val result = credentialManager.getCredential(activity, request)
        val credential = result.credential
        if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
          val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
          val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
          val authResult = auth.signInWithCredential(authCredential).await()
          val user = authResult.user
          if (user != null) {
            _currentFirebaseUser.value = user
            saveUserProfileToCloud(user)
            startSync(user.uid)
            onSuccess(user)
          } else {
            onError("User credentials empty")
          }
        } else {
          onError("Unexpected credential type")
        }
      } catch (e: GetCredentialCancellationException) {
        Log.w("Auth", "Google Sign-In cancelled: ${e.message}", e)
        onCancelled()
      } catch (e: Exception) {
        Log.e("Auth", "Google Sign-In failed", e)
        onError(e.localizedMessage ?: "Google sign in failed")
      }
    }
  }

  fun signOut(onComplete: () -> Unit = {}) {
    stopSync()
    auth.signOut()
    _currentFirebaseUser.value = null
    CoroutineScope(Dispatchers.IO).launch {
      try {
        credentialManager.clearCredentialState(ClearCredentialStateRequest())
      } catch (e: Exception) {
        Log.e("Auth", "Failed to clear credential state", e)
      } finally {
        withContext(Dispatchers.Main) {
          onComplete()
        }
      }
    }
  }

  private fun saveUserProfileToCloud(user: FirebaseUser) {
    val uid = user.uid
    val userDocRef = db.collection("users").document(uid)
    val data = mapOf(
      "userId" to uid,
      "ownerName" to (user.displayName ?: "Truck Owner"),
      "businessName" to "ट्रांसपोर्ट हिसाब",
      "mobile" to (user.phoneNumber ?: ""),
      "updatedAt" to FieldValue.serverTimestamp()
    )
    userDocRef.set(data)
      .addOnFailureListener { e ->
        handleFirestoreError(e, OperationType.WRITE, userDocRef.path)
      }
  }

  fun startSync(userId: String) {
    stopSync()

    // 1. Sync Drivers from Cloud
    val driversRef = db.collection("users").document(userId).collection("drivers")
    driverListenerRegistration = driversRef.addSnapshotListener { snapshot, error ->
      if (error != null) {
        handleFirestoreError(error, OperationType.LIST, driversRef.path)
        return@addSnapshotListener
      }
      if (snapshot != null) {
        CoroutineScope(Dispatchers.IO).launch {
          for (doc in snapshot.documents) {
            val name = doc.getString("name") ?: continue
            val phone = doc.getString("phone") ?: ""
            val assignedTruck = doc.getString("assignedTruck") ?: ""
            val salary = doc.getDouble("monthlySalary") ?: 0.0
            val notes = doc.getString("notes") ?: ""
            driverDao.insertDriver(
              Driver(
                name = name,
                phone = phone,
                assignedTruck = assignedTruck,
                monthlySalary = salary,
                notes = notes
              )
            )
          }
        }
      }
    }

    // 2. Sync Hisab Entries from Cloud
    val hisabRef = db.collection("users").document(userId).collection("hisab_entries")
    hisabListenerRegistration = hisabRef.addSnapshotListener { snapshot, error ->
      if (error != null) {
        handleFirestoreError(error, OperationType.LIST, hisabRef.path)
        return@addSnapshotListener
      }
      if (snapshot != null) {
        CoroutineScope(Dispatchers.IO).launch {
          for (doc in snapshot.documents) {
            val date = doc.getString("date") ?: continue
            val driverName = doc.getString("driverName") ?: continue
            val truckNumber = doc.getString("truckNumber") ?: continue
            val salary = doc.getDouble("salary") ?: 0.0
            val expenseTotal = doc.getDouble("expenseTotal") ?: 0.0
            val diesel = doc.getDouble("dieselExpense") ?: 0.0
            val toll = doc.getDouble("tollExpense") ?: 0.0
            val repair = doc.getDouble("repairExpense") ?: 0.0
            val food = doc.getDouble("foodExpense") ?: 0.0
            val other = doc.getDouble("otherExpense") ?: 0.0
            val deposit = doc.getDouble("deposit") ?: 0.0
            val balance = doc.getDouble("balance") ?: 0.0
            val notes = doc.getString("notes") ?: ""

            hisabDao.insertEntry(
              HisabEntry(
                date = date,
                driverId = 0L,
                driverName = driverName,
                truckNumber = truckNumber,
                salary = salary,
                expenseTotal = expenseTotal,
                dieselExpense = diesel,
                tollExpense = toll,
                repairExpense = repair,
                foodExpense = food,
                otherExpense = other,
                deposit = deposit,
                balance = balance,
                notes = notes
              )
            )
          }
        }
      }
    }

    // 3. Sync Driver Payments from Cloud
    val paymentsRef = db.collection("users").document(userId).collection("driver_payments")
    paymentListenerRegistration = paymentsRef.addSnapshotListener { snapshot, error ->
      if (error != null) {
        handleFirestoreError(error, OperationType.LIST, paymentsRef.path)
        return@addSnapshotListener
      }
      if (snapshot != null) {
        CoroutineScope(Dispatchers.IO).launch {
          for (doc in snapshot.documents) {
            val driverName = doc.getString("driverName") ?: continue
            val date = doc.getString("date") ?: continue
            val amount = doc.getDouble("amount") ?: 0.0
            val paymentType = doc.getString("paymentType") ?: "एडवांस (Advance)"
            val paymentMode = doc.getString("paymentMode") ?: "नकद (Cash)"
            val remarks = doc.getString("remarks") ?: ""
            val driverIdStr = doc.getString("driverId") ?: "0"
            val driverId = driverIdStr.toLongOrNull() ?: 0L

            paymentDao.insertPayment(
              DriverPayment(
                driverId = driverId,
                driverName = driverName,
                date = date,
                amount = amount,
                paymentType = paymentType,
                paymentMode = paymentMode,
                remarks = remarks
              )
            )
          }
        }
      }
    }

    // 4. Sync Trucks from Cloud
    val trucksRef = db.collection("users").document(userId).collection("trucks")
    truckListenerRegistration = trucksRef.addSnapshotListener { snapshot, error ->
      if (error != null) {
        handleFirestoreError(error, OperationType.LIST, trucksRef.path)
        return@addSnapshotListener
      }
      if (snapshot != null) {
        CoroutineScope(Dispatchers.IO).launch {
          for (doc in snapshot.documents) {
            val truckNumber = doc.getString("truckNumber") ?: continue
            val truckName = doc.getString("truckName") ?: continue
            val truckModel = doc.getString("truckModel") ?: ""
            val assignedDriverName = doc.getString("assignedDriverName") ?: ""
            val notes = doc.getString("notes") ?: ""
            val existing = truckDao.getTruckByNumber(truckNumber)
            truckDao.insertTruck(
              Truck(
                id = existing?.id ?: 0L,
                truckNumber = truckNumber,
                truckName = truckName,
                truckModel = truckModel,
                assignedDriverName = assignedDriverName,
                notes = notes
              )
            )
          }
        }
      }
    }
  }

  fun stopSync() {
    driverListenerRegistration?.remove()
    driverListenerRegistration = null
    hisabListenerRegistration?.remove()
    hisabListenerRegistration = null
    paymentListenerRegistration?.remove()
    paymentListenerRegistration = null
    truckListenerRegistration?.remove()
    truckListenerRegistration = null
  }

  suspend fun uploadDriverToCloud(driver: Driver) = withContext(Dispatchers.IO) {
    val uid = auth.currentUser?.uid ?: return@withContext
    val docRef = db.collection("users").document(uid).collection("drivers").document("drv_${driver.name.hashCode()}")
    val data = mapOf(
      "userId" to uid,
      "name" to driver.name,
      "phone" to driver.phone,
      "assignedTruck" to driver.assignedTruck,
      "monthlySalary" to driver.monthlySalary,
      "notes" to driver.notes,
      "updatedAt" to FieldValue.serverTimestamp()
    )
    try {
      docRef.set(data).await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
    }
  }

  suspend fun uploadPaymentToCloud(payment: DriverPayment) = withContext(Dispatchers.IO) {
    val uid = auth.currentUser?.uid ?: return@withContext
    val docRef = db.collection("users").document(uid).collection("driver_payments").document("pay_${payment.date}_${payment.driverName.hashCode()}_${payment.id}")
    val data = mapOf(
      "userId" to uid,
      "driverId" to payment.driverId.toString(),
      "driverName" to payment.driverName,
      "date" to payment.date,
      "amount" to payment.amount,
      "paymentType" to payment.paymentType,
      "paymentMode" to payment.paymentMode,
      "remarks" to payment.remarks,
      "updatedAt" to FieldValue.serverTimestamp()
    )
    try {
      docRef.set(data).await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
    }
  }

  suspend fun deletePaymentFromCloud(payment: DriverPayment) = withContext(Dispatchers.IO) {
    val uid = auth.currentUser?.uid ?: return@withContext
    val docRef = db.collection("users").document(uid).collection("driver_payments").document("pay_${payment.date}_${payment.driverName.hashCode()}_${payment.id}")
    try {
      docRef.delete().await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docRef.path)
    }
  }

  suspend fun uploadHisabToCloud(entry: HisabEntry) = withContext(Dispatchers.IO) {
    val uid = auth.currentUser?.uid ?: return@withContext
    val docRef = db.collection("users").document(uid).collection("hisab_entries").document("hisab_${entry.date}_${entry.driverName.hashCode()}_${entry.id}")
    val data = mapOf(
      "userId" to uid,
      "date" to entry.date,
      "driverId" to entry.driverId.toString(),
      "driverName" to entry.driverName,
      "truckNumber" to entry.truckNumber,
      "salary" to entry.salary,
      "expenseTotal" to entry.expenseTotal,
      "dieselExpense" to entry.dieselExpense,
      "tollExpense" to entry.tollExpense,
      "repairExpense" to entry.repairExpense,
      "foodExpense" to entry.foodExpense,
      "otherExpense" to entry.otherExpense,
      "deposit" to entry.deposit,
      "balance" to entry.balance,
      "notes" to entry.notes,
      "updatedAt" to FieldValue.serverTimestamp()
    )
    try {
      docRef.set(data).await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
    }
  }

  suspend fun deleteHisabFromCloud(entry: HisabEntry) = withContext(Dispatchers.IO) {
    val uid = auth.currentUser?.uid ?: return@withContext
    val docRef = db.collection("users").document(uid).collection("hisab_entries").document("hisab_${entry.date}_${entry.driverName.hashCode()}_${entry.id}")
    try {
      docRef.delete().await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docRef.path)
    }
  }

  suspend fun deleteDriverFromCloud(driver: Driver): Unit = withContext(Dispatchers.IO) {
    val uid = auth.currentUser?.uid ?: return@withContext
    val docRef = db.collection("users").document(uid).collection("drivers").document("drv_${driver.name.hashCode()}")
    try {
      docRef.delete().await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docRef.path)
    }
  }

  suspend fun uploadTruckToCloud(truck: Truck): Unit = withContext(Dispatchers.IO) {
    val uid = auth.currentUser?.uid ?: return@withContext
    val docRef = db.collection("users").document(uid).collection("trucks").document("trk_${truck.truckNumber.replace(" ", "_")}")
    val data = mapOf(
      "userId" to uid,
      "truckNumber" to truck.truckNumber,
      "truckName" to truck.truckName,
      "truckModel" to truck.truckModel,
      "assignedDriverName" to truck.assignedDriverName,
      "notes" to truck.notes,
      "updatedAt" to FieldValue.serverTimestamp()
    )
    try {
      docRef.set(data).await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
    }
  }

  suspend fun deleteTruckFromCloud(truck: Truck): Unit = withContext(Dispatchers.IO) {
    val uid = auth.currentUser?.uid ?: return@withContext
    val docRef = db.collection("users").document(uid).collection("trucks").document("trk_${truck.truckNumber.replace(" ", "_")}")
    try {
      docRef.delete().await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docRef.path)
    }
  }
}
