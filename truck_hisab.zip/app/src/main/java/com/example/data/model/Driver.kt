package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "drivers")
data class Driver(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val name: String,
  val phone: String = "",
  val assignedTruck: String = "",
  val monthlySalary: Double = 0.0,
  val notes: String = "",
  val createdAt: Long = System.currentTimeMillis()
)
