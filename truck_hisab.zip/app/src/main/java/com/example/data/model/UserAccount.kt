package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_accounts")
data class UserAccount(
  @PrimaryKey
  val mobile: String,
  val password: String,
  val ownerName: String,
  val businessName: String,
  val primaryTruck: String = "",
  val createdAt: Long = System.currentTimeMillis()
)
