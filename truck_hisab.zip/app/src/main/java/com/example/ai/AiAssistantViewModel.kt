package com.example.ai

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Driver
import com.example.data.model.DriverPayment
import com.example.data.model.HisabEntry
import com.example.data.model.Truck
import com.example.ui.viewmodel.HisabViewModel
import com.example.util.DateUtils
import com.example.util.FormatUtils
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.content
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "AiAssistantViewModel"

data class NavigationRequest(
  val targetTab: Int,
  val title: String,
  val date: String? = null,
  val truckFilter: String? = null,
  val driverFilterId: Long? = null
)

class AiAssistantViewModel(
  private val hisabViewModel: HisabViewModel,
  private val voiceManager: VoiceAssistantManager,
  private val appContext: Context
) : ViewModel() {

  // Lazy model initialization per Firebase AI Logic guidelines
  private val model by lazy {
    Firebase.ai.generativeModel(
      modelName = "gemini-3.8-flash"
    )
  }

  private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
  val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

  private val _isLoading = MutableStateFlow(false)
  val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

  private val _inputText = MutableStateFlow("")
  val inputText: StateFlow<String> = _inputText.asStateFlow()

  private val _navigationEvent = MutableSharedFlow<NavigationRequest>(extraBufferCapacity = 2)
  val navigationEvent: SharedFlow<NavigationRequest> = _navigationEvent.asSharedFlow()

  val isListening: StateFlow<Boolean> = voiceManager.isListening
  val isSpeaking: StateFlow<Boolean> = voiceManager.isSpeaking
  val autoSpeakEnabled: StateFlow<Boolean> = voiceManager.autoSpeakEnabled

  val suggestionPrompts = listOf(
    "आज का पूरा हिसाब बताओ",
    "आज RJ 14 GA 5521 का 5000 रुपये डीजल लिखो",
    "राम ड्राइवर को 2000 रुपये एडवांस लिख दो",
    "नया ट्रक जोड़ो RJ 20 GA 9090",
    "नया ड्राइवर जोड़ो: विक्रम गुर्जर, वेतन 18000",
    "गाड़ी खाता खोलो",
    "ड्राइवर खाता खोलो",
    "मासिक रिपोर्ट दिखाओ",
    "RJ 14 का हिसाब शेयर करो",
    "किस ट्रक में सबसे ज्यादा डीजल खर्च हुआ?"
  )

  init {
    // Add initial warm welcome message explaining all automated actions
    val welcomeText = "राम राम जी! 🙏 मैं आपका **MySmart Dairy AI मुनीम** हूँ।\n\n" +
      "अब आप लॉग इन करने के बाद मुझसे बोलकर या लिखकर **ऐप का हर काम** करवा सकते हैं:\n\n" +
      "• ⛽ **हिसाब लिखवाना:** *'आज RJ 14 का 5000 डीजल लिखो'* या *'राम को 2000 एडवांस दो'*\n" +
      "• 🚛 **नया ट्रक जोड़ना:** *'नया ट्रक जोड़ो RJ 20 GA 9090 भारतबेंज'*\n" +
      "• 👤 **नया ड्राइवर जोड़ना:** *'नया ड्राइवर जोड़ो: विक्रम गुर्जर, वेतन 18000'*\n" +
      "• 📊 **हिसाब पूछना:** *'आज की कुल कमाई व खर्च'* या *'किस गाड़ी ने ज्यादा मुनाफा दिया?'*\n" +
      "• 📂 **स्क्रीन व खाता खोलना:** *'गाड़ी खाता खोलो'* या *'ड्राइवर खाता दिखाओ'*\n" +
      "• 📲 **पर्ची शेयर करना:** *'RJ 14 GA 5521 का हिसाब WhatsApp पर भेजो'*"

    _messages.value = listOf(
      ChatMessage(
        sender = AiMessageSender.ASSISTANT,
        text = welcomeText
      )
    )
  }

  fun onInputTextChanged(text: String) {
    _inputText.value = text
  }

  fun toggleAutoSpeak() {
    voiceManager.toggleAutoSpeak()
  }

  fun speakMessage(message: ChatMessage) {
    if (voiceManager.isSpeaking.value) {
      voiceManager.stopSpeaking()
    } else {
      voiceManager.speak(message.text)
    }
  }

  fun stopSpeaking() {
    voiceManager.stopSpeaking()
  }

  fun startVoiceListening(onError: (String) -> Unit) {
    voiceManager.startListening(
      onResult = { recognizedText ->
        _inputText.value = recognizedText
        sendMessage(recognizedText)
      },
      onError = onError
    )
  }

  fun stopVoiceListening() {
    voiceManager.stopListening()
  }

  fun sendMessage(userText: String = _inputText.value) {
    val cleanPrompt = userText.trim()
    if (cleanPrompt.isBlank() || _isLoading.value) return

    _inputText.value = ""
    voiceManager.stopSpeaking()

    // Append user message
    val userMsg = ChatMessage(
      sender = AiMessageSender.USER,
      text = cleanPrompt
    )
    _messages.value = _messages.value + userMsg
    _isLoading.value = true

    viewModelScope.launch {
      try {
        val snapshot = TruckHisabAiContextBuilder.buildAccountingSnapshotPrompt(
          trucks = hisabViewModel.allTrucks.value,
          drivers = hisabViewModel.allDrivers.value,
          truckSummaries = hisabViewModel.truckSummaries.value,
          driverSummaries = hisabViewModel.driverSummaries.value,
          allEntries = hisabViewModel.allEntries.value,
          recentPayments = hisabViewModel.allPayments.value,
          todayDate = hisabViewModel.selectedDate.value
        )

        val fullSystemPrompt = buildSystemPrompt(snapshot)

        // Realistic timeout 60s as mandated by guidelines
        val response = withTimeout(60_000L) {
          model.generateContent(
            content {
              text(fullSystemPrompt)
              text("उपयोगकर्ता (User Command / Query): $cleanPrompt")
            }
          )
        }

        val rawResponseText = response.text.orEmpty()
        if (rawResponseText.isBlank()) {
          addAssistantErrorMessage("माफ़ कीजिए, AI से खाली जवाब मिला। कृपया दोबारा प्रयास करें।")
          return@launch
        }

        // Parse possible action card (Confirm before save / execute)
        val (displayText, proposedAction) = parseProposedActionFromResponse(rawResponseText)

        val aiMsg = ChatMessage(
          sender = AiMessageSender.ASSISTANT,
          text = displayText,
          proposedAction = proposedAction
        )
        _messages.value = _messages.value + aiMsg

        // If auto-speak is enabled, speak conversational text aloud in Hindi
        if (voiceManager.autoSpeakEnabled.value) {
          voiceManager.speak(displayText)
        }

      } catch (e: TimeoutCancellationException) {
        Log.e(TAG, "AI Assistant timed out", e)
        addAssistantErrorMessage("समय समाप्त (Timeout)। कृपया थोड़ा छोटा सवाल पूछें या दोबारा प्रयास करें।")
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        Log.e(TAG, "AI Assistant inference failed", e)
        addAssistantErrorMessage("क्षमा करें, हिसाब जांचने में समस्या आई: ${e.localizedMessage ?: "इंटरनेट कनेक्शन चेक करें।"}")
      } finally {
        _isLoading.value = false
      }
    }
  }

  private fun addAssistantErrorMessage(error: String) {
    _messages.value = _messages.value + ChatMessage(
      sender = AiMessageSender.ASSISTANT,
      text = error,
      isError = true
    )
  }

  private fun buildSystemPrompt(snapshot: String): String {
    return """
      आप एक अत्यंत बुद्धिमान, विनम्र और विश्वसनीय 'MySmart Dairy AI मुनीम' हैं।
      आप भारतीय ट्रांसपोर्ट व डेयरी व्यवसाय के मालिक / मुंशी के सर्व-सक्षम निजी सहायक हैं।
      आप हिंदी और हिंग्लिश (Hinglish) दोनों में स्वाभाविक और आदरपूर्वक बात करते हैं (जैसे: भाईजी, सेठजी, जी)।

      $snapshot

      नियम और दिशानिर्देश:
      1. डेटा के आधार पर सच जवाब देना (ACCURACY):
         - यदि यूजर कमाई, खर्च, नफा/नुकसान, किसी गाड़ी का हिसाब या ड्राइवर के बैलेंस के बारे में पूछे, तो ऊपर दिए गए असली डेटा (Live Data Snapshot) से सटीक गणना करके बताएं।
         - मन से कोई भी झूठा या काल्पनिक आंकड़ा न बनाएं।
         - स्पष्ट रूप से रुपये (₹) और हिंदी में जवाब दें।

      2. ऐप के सभी काम AI द्वारा करना (ACTIONS VIA AI):
         जब यूजर कोई कार्य करने का आदेश दे, तो पहले विनम्रता से बताएं कि क्या समझा गया है, और क्रियान्वयन हेतु अंत में एक JSON ब्लॉक अवश्य दें:

         (A) दैनिक हिसाब (Hisab Entry: डीजल, टोल, रिपेयर, खाना, वेतन, भाड़ा कमाई):
         ```json
         {
           "action": "ADD_HISAB",
           "truckNumber": "RJ 14 GA 5521",
           "driverName": "राम सिंह",
           "date": "${DateUtils.getTodayDateString()}",
           "dieselExpense": 5000.0,
           "tollExpense": 0.0,
           "repairExpense": 0.0,
           "foodExpense": 0.0,
           "otherExpense": 0.0,
           "salary": 0.0,
           "deposit": 0.0,
           "notes": "डीजल खर्च"
         }
         ```

         (B) ड्राइवर एडवांस या वेतन भुगतान (Driver Payment):
         ```json
         {
           "action": "ADD_PAYMENT",
           "driverName": "राम सिंह",
           "date": "${DateUtils.getTodayDateString()}",
           "amount": 2000.0,
           "paymentType": "एडवांस (Advance)",
           "paymentMode": "नकद (Cash)",
           "remarks": "एडवांस दिया"
         }
         ```

         (C) नया ट्रक जोड़ना (Add Truck):
         'नया ट्रक जोड़ो RJ 20 GA 9090 भारतबेंज 16 चक्का'
         ```json
         {
           "action": "ADD_TRUCK",
           "truckNumber": "RJ 20 GA 9090",
           "truckName": "भारतबेंज 16 चक्का",
           "truckModel": "16 चक्का",
           "assignedDriverName": "राम सिंह",
           "notes": "ऑल इंडिया परमिट"
         }
         ```

         (D) नया ड्राइवर जोड़ना (Add Driver):
         'नया ड्राइवर जोड़ो: विक्रम गुर्जर, मोबाइल 9829012345, मासिक वेतन 18000'
         ```json
         {
           "action": "ADD_DRIVER",
           "name": "विक्रम गुर्जर",
           "phone": "9829012345",
           "assignedTruck": "RJ 14 GA 5521",
           "monthlySalary": 18000.0,
           "notes": "अनुभवी ड्राइवर"
         }
         ```

         (E) स्क्रीन या खाता खोलना (Navigate Screen):
         'गाड़ी खाता खोलो' -> targetTab: 1
         'ड्राइवर खाता खोलो' -> targetTab: 2
         'कैलेंडर खोलो' -> targetTab: 0
         'मासिक रिपोर्ट दिखाओ' -> targetTab: 4
         ```json
         {
           "action": "NAVIGATE",
           "targetTab": 1,
           "title": "गाड़ी खाता",
           "date": "${DateUtils.getTodayDateString()}",
           "truckFilter": "RJ 14 GA 5521"
         }
         ```

         (F) खाता पर्ची शेयर करना (Share Slip on WhatsApp/SMS):
         'RJ 14 का हिसाब शेयर करो' या 'राम ड्राइवर का खाता भेजो'
         ```json
         {
           "action": "SHARE_SLIP",
           "shareType": "TRUCK",
           "targetName": "RJ 14 GA 5521"
         }
         ```

         नियम:
         - बिना यूजर के कन्फर्म किए सीधे पैसे का हिसाब या नया डेटाबेस रिकॉर्ड सेव नहीं होगा, इसलिए UI में कन्फर्मेशन कार्ड बनेगा।
         - यदि केवल सामान्य प्रश्न या बातचीत है, तो कोई JSON ब्लॉक न दें। सिर्फ सुंदर हिंदी में उत्तर दें।
    """.trimIndent()
  }

  private fun parseProposedActionFromResponse(rawText: String): Pair<String, ProposedAction?> {
    val jsonRegex = Regex("```(?:json)?\\s*(\\{[\\s\\S]*?\\})\\s*```")
    val match = jsonRegex.find(rawText)

    if (match != null) {
      val jsonContent = match.groupValues[1]
      val cleanDisplayText = rawText.replace(match.value, "").trim()

      try {
        val jsonObj = JSONObject(jsonContent)
        val action = jsonObj.optString("action")

        val allTrucks = hisabViewModel.allTrucks.value
        val allDrivers = hisabViewModel.allDrivers.value

        when (action) {
          "ADD_HISAB" -> {
            val reqTruckNumber = jsonObj.optString("truckNumber", "").trim()
            val reqDriverName = jsonObj.optString("driverName", "").trim()
            val date = jsonObj.optString("date", DateUtils.getTodayDateString())
            val diesel = jsonObj.optDouble("dieselExpense", 0.0)
            val toll = jsonObj.optDouble("tollExpense", 0.0)
            val repair = jsonObj.optDouble("repairExpense", 0.0)
            val food = jsonObj.optDouble("foodExpense", 0.0)
            val other = jsonObj.optDouble("otherExpense", 0.0)
            val salary = jsonObj.optDouble("salary", 0.0)
            val deposit = jsonObj.optDouble("deposit", 0.0)
            val notes = jsonObj.optString("notes", "AI द्वारा दर्ज हिसाब")

            // Match truck
            val matchedTruck = allTrucks.find {
              it.truckNumber.replace(" ", "").contains(reqTruckNumber.replace(" ", ""), ignoreCase = true) ||
                reqTruckNumber.replace(" ", "").contains(it.truckNumber.replace(" ", ""), ignoreCase = true)
            } ?: allTrucks.firstOrNull()

            val finalTruckNumber = matchedTruck?.truckNumber ?: if (reqTruckNumber.isNotBlank()) reqTruckNumber else "RJ 14 GA 5521"

            // Match driver
            val matchedDriver = allDrivers.find {
              it.name.contains(reqDriverName, ignoreCase = true) ||
                reqDriverName.contains(it.name, ignoreCase = true)
            } ?: allDrivers.find { it.assignedTruck == finalTruckNumber } ?: allDrivers.firstOrNull()

            val finalDriverName = matchedDriver?.name ?: if (reqDriverName.isNotBlank()) reqDriverName else "मुख्य ड्राइवर"
            val finalDriverId = matchedDriver?.id ?: 1L

            val expenseTotal = diesel + toll + repair + food + other
            val balance = deposit - (salary + expenseTotal)

            val entry = HisabEntry(
              id = 0L,
              date = date,
              driverId = finalDriverId,
              driverName = finalDriverName,
              truckNumber = finalTruckNumber,
              salary = salary,
              expenseTotal = expenseTotal,
              dieselExpense = diesel,
              tollExpense = toll,
              repairExpense = repair,
              foodExpense = food,
              otherExpense = other,
              deposit = deposit,
              balance = balance,
              notes = notes
            )
            return Pair(cleanDisplayText, ProposedAction.AddHisabEntry(entry))
          }

          "ADD_PAYMENT" -> {
            val reqDriverName = jsonObj.optString("driverName", "").trim()
            val date = jsonObj.optString("date", DateUtils.getTodayDateString())
            val amount = jsonObj.optDouble("amount", 0.0)
            val paymentType = jsonObj.optString("paymentType", "एडवांस (Advance)")
            val paymentMode = jsonObj.optString("paymentMode", "नकद (Cash)")
            val remarks = jsonObj.optString("remarks", "AI द्वारा दर्ज भुगतान")

            val matchedDriver = allDrivers.find {
              it.name.contains(reqDriverName, ignoreCase = true) ||
                reqDriverName.contains(it.name, ignoreCase = true)
            } ?: allDrivers.firstOrNull()

            val finalDriverName = matchedDriver?.name ?: if (reqDriverName.isNotBlank()) reqDriverName else "चालक"
            val finalDriverId = matchedDriver?.id ?: 1L

            val payment = DriverPayment(
              id = 0L,
              driverId = finalDriverId,
              driverName = finalDriverName,
              date = date,
              amount = amount,
              paymentType = paymentType,
              paymentMode = paymentMode,
              remarks = remarks
            )
            return Pair(cleanDisplayText, ProposedAction.AddDriverPayment(payment))
          }

          "ADD_TRUCK" -> {
            val truckNumber = jsonObj.optString("truckNumber", "").trim()
            val truckName = jsonObj.optString("truckName", "नया ट्रक").trim()
            val truckModel = jsonObj.optString("truckModel", "16 चक्का").trim()
            val assignedDriver = jsonObj.optString("assignedDriverName", "").trim()
            val notes = jsonObj.optString("notes", "").trim()

            val truck = Truck(
              id = 0L,
              truckNumber = if (truckNumber.isNotBlank()) truckNumber else "RJ 14 GA 0000",
              truckName = truckName,
              truckModel = truckModel,
              assignedDriverName = assignedDriver,
              notes = notes
            )
            return Pair(cleanDisplayText, ProposedAction.AddNewTruck(truck))
          }

          "ADD_DRIVER" -> {
            val name = jsonObj.optString("name", "नया ड्राइवर").trim()
            val phone = jsonObj.optString("phone", "").trim()
            val assignedTruck = jsonObj.optString("assignedTruck", "").trim()
            val monthlySalary = jsonObj.optDouble("monthlySalary", 15000.0)
            val notes = jsonObj.optString("notes", "").trim()

            val driver = Driver(
              id = 0L,
              name = name,
              phone = phone,
              assignedTruck = assignedTruck,
              monthlySalary = monthlySalary,
              notes = notes
            )
            return Pair(cleanDisplayText, ProposedAction.AddNewDriver(driver))
          }

          "NAVIGATE" -> {
            val targetTab = jsonObj.optInt("targetTab", 0)
            val title = jsonObj.optString("title", "स्क्रीन")
            val date = jsonObj.optString("date", null)
            val truckFilter = jsonObj.optString("truckFilter", null)
            return Pair(cleanDisplayText, ProposedAction.NavigateToScreen(targetTab, title, date, truckFilter))
          }

          "SHARE_SLIP" -> {
            val shareType = jsonObj.optString("shareType", "TRUCK")
            val targetName = jsonObj.optString("targetName", "")

            val matchedTruck = allTrucks.find {
              it.truckNumber.replace(" ", "").contains(targetName.replace(" ", ""), ignoreCase = true)
            }
            val matchedDriver = allDrivers.find {
              it.name.contains(targetName, ignoreCase = true)
            }

            return Pair(
              cleanDisplayText,
              ProposedAction.ShareSummarySlip(
                shareType = shareType,
                targetName = targetName,
                truck = matchedTruck,
                driver = matchedDriver
              )
            )
          }
        }
      } catch (e: Exception) {
        Log.e(TAG, "Error parsing action JSON from AI", e)
      }
    }

    return Pair(rawText, null)
  }

  fun confirmAction(messageId: String, action: ProposedAction) {
    viewModelScope.launch {
      when (action) {
        is ProposedAction.AddHisabEntry -> {
          hisabViewModel.saveHisab(action.entry)
          action.status = ActionCardStatus.CONFIRMED

          val confirmText = "✓ **हिसाब दर्ज हो गया:** गाड़ी ${action.entry.truckNumber} के लिए ₹${action.entry.expenseTotal + action.entry.salary + action.entry.deposit} का हिसाब Firebase में सुरक्षित सेव हो गया है।"
          updateMessageWithAction(messageId, action, confirmText)
          if (voiceManager.autoSpeakEnabled.value) {
            voiceManager.speak("हिसाब सफलतापूर्वक दर्ज हो गया है।")
          }
        }

        is ProposedAction.AddDriverPayment -> {
          hisabViewModel.saveDriverPayment(action.payment)
          action.status = ActionCardStatus.CONFIRMED

          val confirmText = "✓ **भुगतान दर्ज हो गया:** ड्राइवर ${action.payment.driverName} को ₹${action.payment.amount} (${action.payment.paymentType}) का रिकॉर्ड Firebase में सेव हो गया है।"
          updateMessageWithAction(messageId, action, confirmText)
          if (voiceManager.autoSpeakEnabled.value) {
            voiceManager.speak("ड्राइवर का भुगतान दर्ज कर लिया गया है।")
          }
        }

        is ProposedAction.AddNewTruck -> {
          hisabViewModel.saveTruck(action.truck)
          action.status = ActionCardStatus.CONFIRMED

          val confirmText = "✓ **नया ट्रक पंजीकृत हुआ:** गाड़ी ${action.truck.truckNumber} (${action.truck.truckName}) को आपके फ्लीट में सफलतापूर्वक जोड़ दिया गया है।"
          updateMessageWithAction(messageId, action, confirmText)
          if (voiceManager.autoSpeakEnabled.value) {
            voiceManager.speak("नई गाड़ी सफलतापूर्वक जोड़ दी गई है।")
          }
        }

        is ProposedAction.AddNewDriver -> {
          hisabViewModel.saveDriver(action.driver)
          action.status = ActionCardStatus.CONFIRMED

          val confirmText = "✓ **नया ड्राइवर पंजीकृत हुआ:** ड्राइवर ${action.driver.name} (वेतन ₹${action.driver.monthlySalary}) को सफलतापूर्वक जोड़ दिया गया है।"
          updateMessageWithAction(messageId, action, confirmText)
          if (voiceManager.autoSpeakEnabled.value) {
            voiceManager.speak("नया ड्राइवर सफलतापूर्वक जोड़ दिया गया है।")
          }
        }

        is ProposedAction.NavigateToScreen -> {
          action.status = ActionCardStatus.CONFIRMED
          _navigationEvent.emit(
            NavigationRequest(
              targetTab = action.targetTab,
              title = action.title,
              date = action.date,
              truckFilter = action.truckFilter,
              driverFilterId = action.driverFilterId
            )
          )
          updateMessageWithAction(messageId, action, "📂 **${action.title}** स्क्रीन पर ले जाया जा रहा है...")
        }

        is ProposedAction.ShareSummarySlip -> {
          action.status = ActionCardStatus.CONFIRMED
          val allEntries = hisabViewModel.allEntries.value
          val allPayments = hisabViewModel.allPayments.value

          if (action.shareType == "TRUCK" && action.truck != null) {
            val truckEntries = allEntries.filter { it.truckNumber.equals(action.truck.truckNumber, ignoreCase = true) }
            FormatUtils.shareTruckSummary(appContext, action.truck, truckEntries, "MySmart Dairy")
          } else if (action.shareType == "DRIVER" && action.driver != null) {
            val driverEntries = allEntries.filter { it.driverId == action.driver.id }
            val driverPayments = allPayments.filter { it.driverId == action.driver.id }
            FormatUtils.shareDriverSummary(appContext, action.driver, driverEntries, driverPayments, "MySmart Dairy")
          }
          updateMessageWithAction(messageId, action, "📤 **शेयर पर्ची तैयार की गई:** सिस्टम शेयर विकल्प खोल दिया गया है।")
        }
      }
    }
  }

  private fun updateMessageWithAction(messageId: String, action: ProposedAction, systemNote: String) {
    _messages.value = _messages.value.map {
      if (it.id == messageId) it.copy(proposedAction = action) else it
    } + ChatMessage(
      sender = AiMessageSender.SYSTEM,
      text = systemNote
    )
  }

  fun cancelAction(messageId: String, action: ProposedAction) {
    action.status = ActionCardStatus.CANCELLED
    _messages.value = _messages.value.map {
      if (it.id == messageId) it.copy(proposedAction = action) else it
    } + ChatMessage(
      sender = AiMessageSender.SYSTEM,
      text = "अनुरोध रद्द कर दिया गया।"
    )
  }

  fun clearChat() {
    val welcomeText = "नमस्ते जी! चैट साफ़ कर दी गई है। आप नया हिसाब लिखवा सकते हैं, नई गाड़ी या ड्राइवर जोड़ सकते हैं या कोई भी जानकारी पूछ सकते हैं।"
    _messages.value = listOf(
      ChatMessage(
        sender = AiMessageSender.ASSISTANT,
        text = welcomeText
      )
    )
  }

  override fun onCleared() {
    super.onCleared()
    voiceManager.destroy()
  }

  class Factory(
    private val hisabViewModel: HisabViewModel,
    private val context: Context
  ) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
      val voiceManager = VoiceAssistantManager(context)
      return AiAssistantViewModel(hisabViewModel, voiceManager, context.applicationContext) as T
    }
  }
}
