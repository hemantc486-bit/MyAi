package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.TruckHisabRepository
import com.example.data.model.Driver
import com.example.data.model.DriverPayment
import com.example.data.model.HisabEntry
import com.example.data.model.Truck
import com.example.util.CalendarDay
import com.example.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

data class MonthSummary(
  val totalSalary: Double = 0.0,
  val totalExpense: Double = 0.0,
  val totalDiesel: Double = 0.0,
  val totalToll: Double = 0.0,
  val totalRepair: Double = 0.0,
  val totalFood: Double = 0.0,
  val totalOther: Double = 0.0,
  val totalDeposit: Double = 0.0,
  val netBalance: Double = 0.0,
  val entryCount: Int = 0
)

data class DriverLedgerSummary(
  val driver: Driver,
  val totalSalary: Double,
  val totalExpense: Double,
  val totalDeposit: Double,
  val totalAdvancePaid: Double = 0.0,
  val totalSalaryPaid: Double = 0.0,
  val totalPaymentsGiven: Double = 0.0,
  val tripBalance: Double = 0.0,
  val netBalance: Double,
  val entryCount: Int,
  val paymentCount: Int = 0
)

data class TruckLedgerSummary(
  val truck: Truck,
  val totalFreightIncome: Double,
  val totalExpense: Double,
  val dieselExpense: Double,
  val tollExpense: Double,
  val repairExpense: Double,
  val salaryExpense: Double,
  val foodExpense: Double,
  val otherExpense: Double,
  val netProfitLoss: Double,
  val isProfit: Boolean,
  val tripCount: Int
)

data class FleetSummary(
  val totalTrucks: Int = 0,
  val totalFreightIncome: Double = 0.0,
  val totalExpense: Double = 0.0,
  val netProfitLoss: Double = 0.0,
  val totalTrips: Int = 0
)

class HisabViewModel(
  private val repository: TruckHisabRepository
) : ViewModel() {

  private val _selectedYear = MutableStateFlow(DateUtils.getCurrentYear())
  val selectedYear: StateFlow<Int> = _selectedYear.asStateFlow()

  private val _selectedMonth = MutableStateFlow(DateUtils.getCurrentMonth())
  val selectedMonth: StateFlow<Int> = _selectedMonth.asStateFlow()

  private val _selectedDate = MutableStateFlow(DateUtils.getTodayDateString())
  val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

  private val _selectedDriverFilterId = MutableStateFlow<Long?>(null)
  val selectedDriverFilterId: StateFlow<Long?> = _selectedDriverFilterId.asStateFlow()

  private val _selectedTruckFilterNumber = MutableStateFlow<String?>(null)
  val selectedTruckFilterNumber: StateFlow<String?> = _selectedTruckFilterNumber.asStateFlow()

  val allDrivers: StateFlow<List<Driver>> = repository.getAllDrivers()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allTrucks: StateFlow<List<Truck>> = repository.getAllTrucks()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allEntries: StateFlow<List<HisabEntry>> = repository.getAllHisabEntries()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allPayments: StateFlow<List<DriverPayment>> = repository.getAllPayments()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Entries for the currently selected month
  val currentMonthPrefix: StateFlow<String> = combine(_selectedYear, _selectedMonth) { y, m ->
    String.format(Locale.US, "%04d-%02d", y, m)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), String.format(Locale.US, "%04d-%02d", DateUtils.getCurrentYear(), DateUtils.getCurrentMonth()))

  val currentMonthEntries: StateFlow<List<HisabEntry>> = combine(allEntries, currentMonthPrefix, _selectedDriverFilterId, _selectedTruckFilterNumber) { entries, prefix, driverFilter, truckFilter ->
    entries.filter {
      it.date.startsWith(prefix) &&
        (driverFilter == null || it.driverId == driverFilter) &&
        (truckFilter == null || it.truckNumber.trim().equals(truckFilter.trim(), ignoreCase = true))
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Entries for the selected date
  val selectedDateEntries: StateFlow<List<HisabEntry>> = combine(allEntries, _selectedDate, _selectedDriverFilterId, _selectedTruckFilterNumber) { entries, date, driverFilter, truckFilter ->
    entries.filter {
      it.date == date &&
        (driverFilter == null || it.driverId == driverFilter) &&
        (truckFilter == null || it.truckNumber.trim().equals(truckFilter.trim(), ignoreCase = true))
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Truck ledgers and profit/loss summaries
  val truckSummaries: StateFlow<List<TruckLedgerSummary>> = combine(allTrucks, allEntries) { trucks, entries ->
    trucks.map { truck ->
      val truckEntries = entries.filter {
        it.truckNumber.trim().equals(truck.truckNumber.trim(), ignoreCase = true)
      }
      val income = truckEntries.sumOf { it.deposit }
      val diesel = truckEntries.sumOf { it.dieselExpense }
      val toll = truckEntries.sumOf { it.tollExpense }
      val repair = truckEntries.sumOf { it.repairExpense }
      val salary = truckEntries.sumOf { it.salary }
      val food = truckEntries.sumOf { it.foodExpense }
      val other = truckEntries.sumOf { it.otherExpense }
      val totalExpense = truckEntries.sumOf { it.expenseTotal + it.salary }
      val netProfitLoss = income - totalExpense

      TruckLedgerSummary(
        truck = truck,
        totalFreightIncome = income,
        totalExpense = totalExpense,
        dieselExpense = diesel,
        tollExpense = toll,
        repairExpense = repair,
        salaryExpense = salary,
        foodExpense = food,
        otherExpense = other,
        netProfitLoss = netProfitLoss,
        isProfit = netProfitLoss >= 0,
        tripCount = truckEntries.size
      )
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Overall Fleet summary
  val fleetSummary: StateFlow<FleetSummary> = truckSummaries.combine(allEntries) { summaries, entries ->
    FleetSummary(
      totalTrucks = summaries.size,
      totalFreightIncome = summaries.sumOf { it.totalFreightIncome },
      totalExpense = summaries.sumOf { it.totalExpense },
      netProfitLoss = summaries.sumOf { it.netProfitLoss },
      totalTrips = entries.size
    )
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FleetSummary())

  // Month overall financial summary
  val monthSummary: StateFlow<MonthSummary> = currentMonthEntries.combine(_selectedDriverFilterId) { entries, _ ->
    val salary = entries.sumOf { it.salary }
    val expense = entries.sumOf { it.expenseTotal }
    val diesel = entries.sumOf { it.dieselExpense }
    val toll = entries.sumOf { it.tollExpense }
    val repair = entries.sumOf { it.repairExpense }
    val food = entries.sumOf { it.foodExpense }
    val other = entries.sumOf { it.otherExpense }
    val deposit = entries.sumOf { it.deposit }
    val balance = entries.sumOf { it.balance }

    MonthSummary(
      totalSalary = salary,
      totalExpense = expense,
      totalDiesel = diesel,
      totalToll = toll,
      totalRepair = repair,
      totalFood = food,
      totalOther = other,
      totalDeposit = deposit,
      netBalance = balance,
      entryCount = entries.size
    )
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MonthSummary())

  // Map of date string -> count of entries / sum balance (for calendar indicators)
  val monthDatesWithEntries: StateFlow<Map<String, Int>> = currentMonthEntries.combine(_selectedDriverFilterId) { entries, _ ->
    entries.groupBy { it.date }.mapValues { it.value.size }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

  // Driver ledgers combining trips and advance payments
  val driverSummaries: StateFlow<List<DriverLedgerSummary>> = combine(allDrivers, allEntries, allPayments) { drivers, entries, payments ->
    drivers.map { driver ->
      val driverEntries = entries.filter { it.driverId == driver.id }
      val driverPayments = payments.filter { it.driverId == driver.id }
      val totalSalary = driverEntries.sumOf { it.salary }
      val totalExpense = driverEntries.sumOf { it.expenseTotal }
      val totalDeposit = driverEntries.sumOf { it.deposit }
      val tripBal = driverEntries.sumOf { it.balance }
      val totalAdv = driverPayments.filter { it.paymentType.contains("एडवांस") || it.paymentType.contains("Advance") }.sumOf { it.amount }
      val totalSalPaid = driverPayments.filter { it.paymentType.contains("वेतन") || it.paymentType.contains("Salary") }.sumOf { it.amount }
      val totalGiven = driverPayments.sumOf { it.amount }
      val netBalance = tripBal + totalAdv - totalSalPaid

      DriverLedgerSummary(
        driver = driver,
        totalSalary = totalSalary,
        totalExpense = totalExpense,
        totalDeposit = totalDeposit,
        totalAdvancePaid = totalAdv,
        totalSalaryPaid = totalSalPaid,
        totalPaymentsGiven = totalGiven,
        tripBalance = tripBal,
        netBalance = netBalance,
        entryCount = driverEntries.size,
        paymentCount = driverPayments.size
      )
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Dialog & Detail states
  private val _isAddEditHisabOpen = MutableStateFlow(false)
  val isAddEditHisabOpen: StateFlow<Boolean> = _isAddEditHisabOpen.asStateFlow()

  private val _editingEntry = MutableStateFlow<HisabEntry?>(null)
  val editingEntry: StateFlow<HisabEntry?> = _editingEntry.asStateFlow()

  private val _isAddDriverOpen = MutableStateFlow(false)
  val isAddDriverOpen: StateFlow<Boolean> = _isAddDriverOpen.asStateFlow()

  private val _driverForDetailLedger = MutableStateFlow<Driver?>(null)
  val driverForDetailLedger: StateFlow<Driver?> = _driverForDetailLedger.asStateFlow()

  // Truck Management & Detail states
  private val _isAddTruckOpen = MutableStateFlow(false)
  val isAddTruckOpen: StateFlow<Boolean> = _isAddTruckOpen.asStateFlow()

  private val _selectedTruckForDetail = MutableStateFlow<Truck?>(null)
  val selectedTruckForDetail: StateFlow<Truck?> = _selectedTruckForDetail.asStateFlow()

  // Driver payment recording dialog state
  private val _isRecordPaymentOpen = MutableStateFlow(false)
  val isRecordPaymentOpen: StateFlow<Boolean> = _isRecordPaymentOpen.asStateFlow()

  private val _paymentTargetDriver = MutableStateFlow<Driver?>(null)
  val paymentTargetDriver: StateFlow<Driver?> = _paymentTargetDriver.asStateFlow()

  private val _editingPayment = MutableStateFlow<DriverPayment?>(null)
  val editingPayment: StateFlow<DriverPayment?> = _editingPayment.asStateFlow()

  // Search & jump by date
  private val _isSearchOpen = MutableStateFlow(false)
  val isSearchOpen: StateFlow<Boolean> = _isSearchOpen.asStateFlow()

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  val searchResults: StateFlow<List<HisabEntry>> = combine(allEntries, _searchQuery) { entries, query ->
    val clean = query.trim().lowercase()
    if (clean.isBlank()) {
      entries.take(20)
    } else {
      entries.filter { entry ->
        entry.date.contains(clean) ||
          entry.driverName.lowercase().contains(clean) ||
          entry.truckNumber.lowercase().contains(clean) ||
          entry.notes.lowercase().contains(clean) ||
          DateUtils.formatToHindiDisplayDate(entry.date).lowercase().contains(clean)
      }
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val isCloudSynced: StateFlow<Boolean> = repository.syncService.currentFirebaseUser
    .combine(MutableStateFlow(true)) { user, _ -> user != null }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), repository.syncService.auth.currentUser != null)

  fun onSearchQueryChange(query: String) {
    _searchQuery.value = query
  }

  fun openSearch() {
    _isSearchOpen.value = true
  }

  fun closeSearch() {
    _isSearchOpen.value = false
    _searchQuery.value = ""
  }

  fun setYearAndMonth(year: Int, month: Int) {
    _selectedYear.value = year
    _selectedMonth.value = month
  }

  fun jumpToSpecificDate(date: String) {
    try {
      val parts = date.split("-")
      if (parts.size == 3) {
        val y = parts[0].toInt()
        val m = parts[1].toInt()
        _selectedYear.value = y
        _selectedMonth.value = m
      }
    } catch (_: Exception) {}
    _selectedDate.value = date
    closeSearch()
  }

  fun selectDate(date: String) {
    _selectedDate.value = date
  }

  fun previousMonth() {
    var y = _selectedYear.value
    var m = _selectedMonth.value - 1
    if (m < 1) {
      m = 12
      y -= 1
    }
    _selectedYear.value = y
    _selectedMonth.value = m
  }

  fun nextMonth() {
    var y = _selectedYear.value
    var m = _selectedMonth.value + 1
    if (m > 12) {
      m = 1
      y += 1
    }
    _selectedYear.value = y
    _selectedMonth.value = m
  }

  fun goToToday() {
    _selectedYear.value = DateUtils.getCurrentYear()
    _selectedMonth.value = DateUtils.getCurrentMonth()
    _selectedDate.value = DateUtils.getTodayDateString()
  }

  fun setDriverFilter(driverId: Long?) {
    _selectedDriverFilterId.value = driverId
  }

  fun openAddHisab(date: String = _selectedDate.value) {
    _editingEntry.value = null
    _selectedDate.value = date
    _isAddEditHisabOpen.value = true
  }

  fun openEditHisab(entry: HisabEntry) {
    _editingEntry.value = entry
    _selectedDate.value = entry.date
    _isAddEditHisabOpen.value = true
  }

  fun closeAddEditHisab() {
    _isAddEditHisabOpen.value = false
    _editingEntry.value = null
  }

  fun saveHisab(entry: HisabEntry) {
    viewModelScope.launch {
      repository.saveHisabEntry(entry)
      _isAddEditHisabOpen.value = false
      _editingEntry.value = null
    }
  }

  fun deleteHisab(id: Long) {
    viewModelScope.launch {
      repository.deleteHisabEntry(id)
    }
  }

  fun openAddDriver() {
    _isAddDriverOpen.value = true
  }

  fun closeAddDriver() {
    _isAddDriverOpen.value = false
  }

  fun saveDriver(driver: Driver) {
    viewModelScope.launch {
      if (driver.id == 0L) {
        repository.insertDriver(driver)
      } else {
        repository.updateDriver(driver)
      }
      _isAddDriverOpen.value = false
    }
  }

  fun deleteDriver(driver: Driver) {
    viewModelScope.launch {
      repository.deleteDriver(driver)
      if (_driverForDetailLedger.value?.id == driver.id) {
        _driverForDetailLedger.value = null
      }
    }
  }

  fun openDriverDetail(driver: Driver) {
    _driverForDetailLedger.value = driver
  }

  fun closeDriverDetail() {
    _driverForDetailLedger.value = null
  }

  fun openRecordPayment(driver: Driver? = null, payment: DriverPayment? = null) {
    _paymentTargetDriver.value = driver
    _editingPayment.value = payment
    _isRecordPaymentOpen.value = true
  }

  fun closeRecordPayment() {
    _isRecordPaymentOpen.value = false
    _paymentTargetDriver.value = null
    _editingPayment.value = null
  }

  fun saveDriverPayment(payment: DriverPayment) {
    viewModelScope.launch {
      repository.saveDriverPayment(payment)
      _isRecordPaymentOpen.value = false
      _editingPayment.value = null
      _paymentTargetDriver.value = null
    }
  }

  fun deleteDriverPayment(id: Long) {
    viewModelScope.launch {
      repository.deleteDriverPayment(id)
    }
  }

  fun openAddTruck() {
    _isAddTruckOpen.value = true
  }

  fun closeAddTruck() {
    _isAddTruckOpen.value = false
  }

  fun saveTruck(truck: Truck) {
    viewModelScope.launch {
      repository.saveTruck(truck)
      _isAddTruckOpen.value = false
    }
  }

  fun deleteTruck(truck: Truck) {
    viewModelScope.launch {
      repository.deleteTruck(truck)
      if (_selectedTruckForDetail.value?.id == truck.id) {
        _selectedTruckForDetail.value = null
      }
    }
  }

  fun openTruckDetail(truck: Truck) {
    _selectedTruckForDetail.value = truck
  }

  fun closeTruckDetail() {
    _selectedTruckForDetail.value = null
  }

  fun setTruckFilter(truckNumber: String?) {
    _selectedTruckFilterNumber.value = truckNumber
  }

  class Factory(private val repository: TruckHisabRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
      return HisabViewModel(repository) as T
    }
  }
}
