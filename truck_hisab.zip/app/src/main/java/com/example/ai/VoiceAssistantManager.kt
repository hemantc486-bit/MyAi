package com.example.ai

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

private const val TAG = "VoiceAssistantManager"

class VoiceAssistantManager(private val context: Context) : TextToSpeech.OnInitListener {

  private var textToSpeech: TextToSpeech? = null
  private var isTtsReady = false

  private var speechRecognizer: SpeechRecognizer? = null

  private val _isListening = MutableStateFlow(false)
  val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

  private val _isSpeaking = MutableStateFlow(false)
  val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

  private val _speechRms = MutableStateFlow(0f)
  val speechRms: StateFlow<Float> = _speechRms.asStateFlow()

  private val _autoSpeakEnabled = MutableStateFlow(true)
  val autoSpeakEnabled: StateFlow<Boolean> = _autoSpeakEnabled.asStateFlow()

  private var onSpeechResultCallback: ((String) -> Unit)? = null
  private var onSpeechErrorCallback: ((String) -> Unit)? = null

  init {
    initTextToSpeech()
  }

  private fun initTextToSpeech() {
    try {
      textToSpeech = TextToSpeech(context.applicationContext, this)
    } catch (e: Exception) {
      Log.e(TAG, "Error initializing TextToSpeech", e)
    }
  }

  override fun onInit(status: Int) {
    if (status == TextToSpeech.SUCCESS) {
      val tts = textToSpeech ?: return
      val hindiLocale = Locale("hi", "IN")
      val hindiAvailable = tts.isLanguageAvailable(hindiLocale)
      if (hindiAvailable >= TextToSpeech.LANG_AVAILABLE) {
        tts.language = hindiLocale
        Log.d(TAG, "TTS initialized with Hindi (hi-IN)")
      } else {
        val indianEnglish = Locale("en", "IN")
        if (tts.isLanguageAvailable(indianEnglish) >= TextToSpeech.LANG_AVAILABLE) {
          tts.language = indianEnglish
        } else {
          tts.language = Locale.getDefault()
        }
        Log.d(TAG, "TTS initialized with fallback: ${tts.language}")
      }
      tts.setPitch(1.0f)
      tts.setSpeechRate(0.95f)

      tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
          _isSpeaking.value = true
        }

        override fun onDone(utteranceId: String?) {
          _isSpeaking.value = false
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
          _isSpeaking.value = false
        }
      })
      isTtsReady = true
    } else {
      Log.e(TAG, "TTS initialization failed with code: $status")
      isTtsReady = false
    }
  }

  fun toggleAutoSpeak() {
    _autoSpeakEnabled.value = !_autoSpeakEnabled.value
    if (!_autoSpeakEnabled.value) {
      stopSpeaking()
    }
  }

  fun speak(text: String) {
    if (!isTtsReady || textToSpeech == null) return
    try {
      stopSpeaking()
      // Clean markdown symbols and JSON markers before speaking
      val cleanText = text
        .replace(Regex("```[\\s\\S]*?```"), "") // Remove JSON blocks
        .replace(Regex("[*#_`~]"), "") // Remove markdown
        .replace("₹", "रुपये ")
        .trim()

      if (cleanText.isNotBlank()) {
        _isSpeaking.value = true
        val params = Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "TruckHisabAiUtterance")
        textToSpeech?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, params, "TruckHisabAiUtterance")
      }
    } catch (e: Exception) {
      Log.e(TAG, "Failed to speak text", e)
      _isSpeaking.value = false
    }
  }

  fun stopSpeaking() {
    try {
      textToSpeech?.stop()
      _isSpeaking.value = false
    } catch (e: Exception) {
      Log.e(TAG, "Error stopping TTS", e)
    }
  }

  fun startListening(
    onResult: (String) -> Unit,
    onError: (String) -> Unit
  ) {
    stopSpeaking()
    onSpeechResultCallback = onResult
    onSpeechErrorCallback = onError

    if (!SpeechRecognizer.isRecognitionAvailable(context)) {
      onError("इस डिवाइस पर स्पीच रिकग्निशन उपलब्ध नहीं है। कृपया टाइप करके लिखें।")
      return
    }

    try {
      if (speechRecognizer != null) {
        speechRecognizer?.destroy()
      }
      speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
        setRecognitionListener(object : RecognitionListener {
          override fun onReadyForSpeech(params: Bundle?) {
            _isListening.value = true
          }

          override fun onBeginningOfSpeech() {
            _isListening.value = true
          }

          override fun onRmsChanged(rmsdB: Float) {
            _speechRms.value = rmsdB
          }

          override fun onBufferReceived(buffer: ByteArray?) {}

          override fun onEndOfSpeech() {
            _isListening.value = false
          }

          override fun onError(error: Int) {
            _isListening.value = false
            val message = when (error) {
              SpeechRecognizer.ERROR_NO_MATCH -> "आवाज़ समझ नहीं आई, कृपया दोबारा बोलें।"
              SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "समय समाप्त। कृपया माइक दबाकर दोबारा बोलें।"
              SpeechRecognizer.ERROR_AUDIO -> "ऑडियो रिकॉर्डिंग में समस्या आई।"
              SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "नेटवर्क समस्या। कृपया इंटरनेट चेक करें।"
              SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "माइक की अनुमति (Permission) दें।"
              else -> "माइक में समस्या आई (कोड: $error)"
            }
            Log.w(TAG, "Speech recognition error: $error ($message)")
            onSpeechErrorCallback?.invoke(message)
          }

          override fun onResults(results: Bundle?) {
            _isListening.value = false
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val recognizedText = matches?.firstOrNull()?.trim()
            if (!recognizedText.isNullOrBlank()) {
              onSpeechResultCallback?.invoke(recognizedText)
            } else {
              onSpeechErrorCallback?.invoke("कोई आवाज़ नहीं मिली।")
            }
          }

          override fun onPartialResults(partialResults: Bundle?) {}

          override fun onEvent(eventType: Int, params: Bundle?) {}
        })
      }

      val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
        putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("hi-IN", "en-IN", "en-US"))
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
      }

      speechRecognizer?.startListening(intent)
      _isListening.value = true
    } catch (e: Exception) {
      Log.e(TAG, "Error starting speech recognition", e)
      _isListening.value = false
      onError("माइक शुरू करने में समस्या आई: ${e.localizedMessage}")
    }
  }

  fun stopListening() {
    try {
      speechRecognizer?.stopListening()
      _isListening.value = false
    } catch (e: Exception) {
      Log.e(TAG, "Error stopping speech recognition", e)
    }
  }

  fun destroy() {
    try {
      stopSpeaking()
      textToSpeech?.shutdown()
      textToSpeech = null
      speechRecognizer?.destroy()
      speechRecognizer = null
    } catch (e: Exception) {
      Log.e(TAG, "Error during destroy", e)
    }
  }
}
