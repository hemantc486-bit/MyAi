package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Driver
import kotlinx.coroutines.flow.Flow

@Dao
interface DriverDao {
  @Query("SELECT * FROM drivers ORDER BY name ASC")
  fun getAllDrivers(): Flow<List<Driver>>

  @Query("SELECT * FROM drivers WHERE id = :id LIMIT 1")
  suspend fun getDriverById(id: Long): Driver?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertDriver(driver: Driver): Long

  @Update
  suspend fun updateDriver(driver: Driver)

  @Delete
  suspend fun deleteDriver(driver: Driver)

  @Query("SELECT COUNT(*) FROM drivers")
  suspend fun getDriverCount(): Int
}
