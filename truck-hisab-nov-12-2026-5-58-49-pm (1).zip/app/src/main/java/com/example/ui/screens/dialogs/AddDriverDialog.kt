package com.example.ui.screens.dialogs

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.Driver

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddDriverDialog(
  onDismiss: () -> Unit,
  onSave: (Driver) -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  var name by remember { mutableStateOf("") }
  var phone by remember { mutableStateOf("") }
  var truckNumber by remember { mutableStateOf("") }
  var salaryText by remember { mutableStateOf("") }
  var notes by remember { mutableStateOf("") }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp)
        .padding(bottom = 36.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "नया ड्राइवर जोड़ें (Add Driver)",
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary
        )
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "बंद करें")
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      OutlinedTextField(
        value = name,
        onValueChange = { name = it },
        label = { Text("ड्राइवर का नाम *") },
        placeholder = { Text("जैसे: विक्रम सिंह") },
        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("driver_name_input"),
        singleLine = true
      )

      Spacer(modifier = Modifier.height(10.dp))

      OutlinedTextField(
        value = phone,
        onValueChange = { if (it.length <= 10) phone = it },
        label = { Text("मोबाइल नंबर (Mobile)") },
        placeholder = { Text("10 अंकों का फोन नंबर") },
        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("driver_phone_input"),
        singleLine = true
      )

      Spacer(modifier = Modifier.height(10.dp))

      OutlinedTextField(
        value = truckNumber,
        onValueChange = { truckNumber = it.uppercase() },
        label = { Text("गाड़ी / ट्रक नंबर (Truck Number)") },
        placeholder = { Text("जैसे: RJ 14 GA 5521") },
        leadingIcon = { Icon(Icons.Default.AllInclusive, contentDescription = null) },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("driver_truck_input"),
        singleLine = true
      )

      Spacer(modifier = Modifier.height(10.dp))

      OutlinedTextField(
        value = salaryText,
        onValueChange = { salaryText = it },
        label = { Text("मासिक तय वेतन (Monthly Salary) ₹") },
        placeholder = { Text("जैसे: 20000") },
        leadingIcon = { Icon(Icons.Default.Payments, contentDescription = null) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("driver_salary_input"),
        singleLine = true
      )

      Spacer(modifier = Modifier.height(10.dp))

      OutlinedTextField(
        value = notes,
        onValueChange = { notes = it },
        label = { Text("रूट / टिप्पणी (Notes)") },
        placeholder = { Text("जैसे: दिल्ली-मुम्बई रूट") },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("driver_notes_input"),
        singleLine = true
      )

      Spacer(modifier = Modifier.height(20.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        OutlinedButton(
          onClick = onDismiss,
          modifier = Modifier
            .weight(1f)
            .height(50.dp),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text("रद्द करें")
        }

        Button(
          onClick = {
            if (name.isBlank()) return@Button
            val driver = Driver(
              name = name.trim(),
              phone = phone.trim(),
              assignedTruck = truckNumber.trim(),
              monthlySalary = salaryText.toDoubleOrNull() ?: 0.0,
              notes = notes.trim()
            )
            onSave(driver)
          },
          modifier = Modifier
            .weight(1.5f)
            .height(50.dp)
            .testTag("save_driver_button"),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
          enabled = name.isNotBlank()
        ) {
          Text("ड्राइवर सेव करें", fontWeight = FontWeight.Bold, color = Color.White)
        }
      }
    }
  }
}
