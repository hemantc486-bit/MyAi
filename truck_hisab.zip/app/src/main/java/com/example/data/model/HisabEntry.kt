package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "hisab_entries")
data class HisabEntry(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val date: String, // Format: YYYY-MM-DD
  val driverId: Long,
  val driverName: String,
  val truckNumber: String,
  val salary: Double = 0.0, // आज का वेतन या एडवांस
  val expenseTotal: Double = 0.0, // कुल खर्च
  val dieselExpense: Double = 0.0, // डीजल
  val tollExpense: Double = 0.0, // टोल / फास्टैग
  val repairExpense: Double = 0.0, // मरम्मत / पंचर
  val foodExpense: Double = 0.0, // खाना / खोराकी
  val otherExpense: Double = 0.0, // चालान / अन्य
  val deposit: Double = 0.0, // जमा / भाड़ा / एडवांस
  val balance: Double = 0.0, // बाकी रकम = deposit - (salary + expenseTotal)
  val notes: String = "", // रूट विवरण या टिप्पणी (जैसे: दिल्ली से मुंबई)
  val createdAt: Long = System.currentTimeMillis()
)
