package com.example.data

import android.content.Context
import com.example.data.model.Driver
import com.example.data.model.DriverPayment
import com.example.data.model.HisabEntry
import com.example.data.model.Truck
import com.example.data.model.UserAccount
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class TruckHisabRepository(
  private val database: TruckHisabDatabase,
  private val context: Context
) {
  private val userDao = database.userDao()
  private val driverDao = database.driverDao()
  private val hisabDao = database.hisabDao()
  private val paymentDao = database.driverPaymentDao()
  private val truckDao = database.truckDao()

  val syncService = com.example.data.firebase.FirestoreSyncService(context, userDao, driverDao, hisabDao, paymentDao, truckDao)

  private val _currentUser = MutableStateFlow<UserAccount?>(null)
  val currentUser: StateFlow<UserAccount?> = _currentUser.asStateFlow()

  // Track session via simple SharedPreferences
  private val prefs = context.getSharedPreferences("truck_hisab_prefs", Context.MODE_PRIVATE)

  init {
    CoroutineScope(Dispatchers.IO).launch {
      ensureInitialSeed()
      val savedMobile = prefs.getString("logged_in_mobile", null)
      if (savedMobile != null) {
        val user = userDao.getUserByMobile(savedMobile)
        _currentUser.value = user
      }
    }
  }

  suspend fun ensureInitialSeed() = withContext(Dispatchers.IO) {
    if (userDao.getFirstUser() == null) {
      val demoUser = UserAccount(
        mobile = "9876543210",
        password = "1234",
        ownerName = "राजेश शर्मा",
        businessName = "शर्मा रोडलाइंस",
        primaryTruck = "RJ 14 GA 5521"
      )
      userDao.insertUser(demoUser)
    }

    if (driverDao.getDriverCount() == 0) {
      val d1 = driverDao.insertDriver(
        Driver(
          name = "रमेश सिंह",
          phone = "9829012345",
          assignedTruck = "RJ 14 GA 5521",
          monthlySalary = 18000.0,
          notes = "जयपुर से दिल्ली रूट"
        )
      )

      val d2 = driverDao.insertDriver(
        Driver(
          name = "कुलदीप यादव",
          phone = "9812067890",
          assignedTruck = "HR 55 AB 9988",
          monthlySalary = 20000.0,
          notes = "गुड़गांव से अहमदाबाद"
        )
      )

      val d3 = driverDao.insertDriver(
        Driver(
          name = "बलविंदर जीत",
          phone = "9878054321",
          assignedTruck = "PB 10 CT 4321",
          monthlySalary = 22000.0,
          notes = "लुधियाना से मुंबई"
        )
      )

      val today = "2026-11-04"
      val yesterday = "2026-11-03"
      val dayBefore = "2026-11-02"

      hisabDao.insertEntry(
        HisabEntry(
          date = today,
          driverId = d1,
          driverName = "रमेश सिंह",
          truckNumber = "RJ 14 GA 5521",
          salary = 600.0,
          expenseTotal = 8500.0,
          dieselExpense = 6800.0,
          tollExpense = 1100.0,
          repairExpense = 200.0,
          foodExpense = 300.0,
          otherExpense = 100.0,
          deposit = 12000.0,
          balance = 12000.0 - (600.0 + 8500.0),
          notes = "जयपुर से दिल्ली माल भाड़ा"
        )
      )

      hisabDao.insertEntry(
        HisabEntry(
          date = today,
          driverId = d2,
          driverName = "कुलदीप यादव",
          truckNumber = "HR 55 AB 9988",
          salary = 700.0,
          expenseTotal = 14200.0,
          dieselExpense = 11500.0,
          tollExpense = 1800.0,
          repairExpense = 500.0,
          foodExpense = 400.0,
          otherExpense = 0.0,
          deposit = 15000.0,
          balance = 15000.0 - (700.0 + 14200.0),
          notes = "रेवाड़ी से वडोदरा कंटेनर"
        )
      )

      hisabDao.insertEntry(
        HisabEntry(
          date = yesterday,
          driverId = d3,
          driverName = "बलविंदर जीत",
          truckNumber = "PB 10 CT 4321",
          salary = 750.0,
          expenseTotal = 16800.0,
          dieselExpense = 13500.0,
          tollExpense = 2100.0,
          repairExpense = 800.0,
          foodExpense = 400.0,
          otherExpense = 0.0,
          deposit = 18000.0,
          balance = 18000.0 - (750.0 + 16800.0),
          notes = "लुधियाना से कांडला पोर्ट"
        )
      )

      hisabDao.insertEntry(
        HisabEntry(
          date = dayBefore,
          driverId = d1,
          driverName = "रमेश सिंह",
          truckNumber = "RJ 14 GA 5521",
          salary = 600.0,
          expenseTotal = 5200.0,
          dieselExpense = 4200.0,
          tollExpense = 650.0,
          repairExpense = 100.0,
          foodExpense = 250.0,
          otherExpense = 0.0,
          deposit = 7000.0,
          balance = 7000.0 - (600.0 + 5200.0),
          notes = "लोकल डिलीवरी"
        )
      )
    }

    if (truckDao.getTruckCount() == 0) {
      truckDao.insertTruck(
        Truck(
          truckNumber = "RJ 14 GA 5521",
          truckName = "भारतबेंज 16 चक्का (ट्रॉला)",
          truckModel = "16 चक्का ट्रेलर",
          assignedDriverName = "रमेश सिंह",
          notes = "जयपुर-दिल्ली-मुंबई नेशनल परमिट"
        )
      )

      truckDao.insertTruck(
        Truck(
          truckNumber = "HR 55 AB 9988",
          truckName = "टाटा सिग्ना 12 चक्का",
          truckModel = "12 चक्का ओपन बॉडी",
          assignedDriverName = "कुलदीप यादव",
          notes = "गुड़गांव-रेवाड़ी-वडोदरा रूट"
        )
      )

      truckDao.insertTruck(
        Truck(
          truckNumber = "PB 10 CT 4321",
          truckName = "अशोक लीलैंड कंटेनर",
          truckModel = "कंटेनर बॉडी (32 फीट)",
          assignedDriverName = "बलविंदर जीत",
          notes = "लुधियाना-कांडला पोर्ट माल ढुलाई"
        )
      )
    }
  }

  suspend fun login(mobile: String, password: String):Result<UserAccount> = withContext(Dispatchers.IO) {
    val cleanMobile = mobile.trim()
    val cleanPassword = password.trim()
    val user = userDao.getUserByMobile(cleanMobile)
    if (user != null) {
      if (user.password == cleanPassword) {
        prefs.edit().putString("logged_in_mobile", cleanMobile).apply()
        _currentUser.value = user
        Result.success(user)
      } else {
        Result.failure(Exception("गलत पासवर्ड! कृपया सही पासवर्ड दर्ज करें।"))
      }
    } else {
      Result.failure(Exception("इस मोबाइल नंबर से कोई खाता नहीं मिला। कृपया 'नया खाता बनाएं' पर क्लिक करें।"))
    }
  }

  suspend fun register(user: UserAccount): Result<UserAccount> = withContext(Dispatchers.IO) {
    val existing = userDao.getUserByMobile(user.mobile.trim())
    if (existing != null) {
      Result.failure(Exception("इस मोबाइल नंबर से पहले ही खाता बना हुआ है। कृपया लॉगिन करें।"))
    } else {
      userDao.insertUser(user)
      prefs.edit().putString("logged_in_mobile", user.mobile.trim()).apply()
      _currentUser.value = user
      Result.success(user)
    }
  }

  fun signInWithGoogle(
    activity: android.app.Activity,
    onSuccess: (com.google.firebase.auth.FirebaseUser) -> Unit,
    onError: (String) -> Unit,
    onCancelled: () -> Unit = {}
  ) {
    syncService.signInWithGoogle(
      activity = activity,
      onSuccess = { user ->
        val userAccount = UserAccount(
          mobile = user.phoneNumber ?: user.email?.substringBefore("@") ?: "GoogleUser",
          password = "",
          ownerName = user.displayName ?: "Truck Owner",
          businessName = "ट्रांसपोर्ट हिसाब",
          primaryTruck = ""
        )
        _currentUser.value = userAccount
        prefs.edit().putString("logged_in_mobile", userAccount.mobile).apply()
        onSuccess(user)
      },
      onError = onError,
      onCancelled = onCancelled
    )
  }

  fun logout() {
    syncService.signOut()
    prefs.edit().remove("logged_in_mobile").apply()
    _currentUser.value = null
  }

  fun getAllDrivers(): Flow<List<Driver>> = driverDao.getAllDrivers()

  suspend fun insertDriver(driver: Driver): Long = withContext(Dispatchers.IO) {
    val id = driverDao.insertDriver(driver)
    syncService.uploadDriverToCloud(driver.copy(id = id))
    id
  }

  suspend fun updateDriver(driver: Driver): Unit = withContext(Dispatchers.IO) {
    driverDao.updateDriver(driver)
    syncService.uploadDriverToCloud(driver)
  }

  suspend fun deleteDriver(driver: Driver): Unit = withContext(Dispatchers.IO) {
    driverDao.deleteDriver(driver)
    syncService.deleteDriverFromCloud(driver)
  }

  fun getAllHisabEntries(): Flow<List<HisabEntry>> = hisabDao.getAllEntries()

  fun getHisabEntriesForDate(date: String): Flow<List<HisabEntry>> = hisabDao.getEntriesForDate(date)

  fun getHisabEntriesForDriver(driverId: Long): Flow<List<HisabEntry>> = hisabDao.getEntriesForDriver(driverId)

  fun getHisabEntriesForMonth(monthPrefix: String): Flow<List<HisabEntry>> = hisabDao.getEntriesForMonth(monthPrefix)

  suspend fun saveHisabEntry(entry: HisabEntry): Long = withContext(Dispatchers.IO) {
    val id = if (entry.id == 0L) {
      val newId = hisabDao.insertEntry(entry)
      newId
    } else {
      hisabDao.updateEntry(entry)
      entry.id
    }
    syncService.uploadHisabToCloud(entry.copy(id = id))
    id
  }

  suspend fun deleteHisabEntry(id: Long): Unit = withContext(Dispatchers.IO) {
    val entry = hisabDao.getEntryById(id)
    if (entry != null) {
      syncService.deleteHisabFromCloud(entry)
    }
    hisabDao.deleteEntryById(id)
  }

  fun getAllPayments(): Flow<List<DriverPayment>> = paymentDao.getAllPayments()

  fun getPaymentsForDriver(driverId: Long): Flow<List<DriverPayment>> = paymentDao.getPaymentsForDriver(driverId)

  suspend fun saveDriverPayment(payment: DriverPayment): Long = withContext(Dispatchers.IO) {
    val id = if (payment.id == 0L) {
      paymentDao.insertPayment(payment)
    } else {
      paymentDao.updatePayment(payment)
      payment.id
    }
    syncService.uploadPaymentToCloud(payment.copy(id = id))
    id
  }

  suspend fun deleteDriverPayment(id: Long): Unit = withContext(Dispatchers.IO) {
    val payment = paymentDao.getPaymentById(id)
    if (payment != null) {
      syncService.deletePaymentFromCloud(payment)
      paymentDao.deletePayment(payment)
    }
  }

  fun getAllTrucks(): Flow<List<Truck>> = truckDao.getAllTrucks()

  suspend fun getTruckByNumber(truckNumber: String): Truck? = withContext(Dispatchers.IO) {
    truckDao.getTruckByNumber(truckNumber)
  }

  suspend fun saveTruck(truck: Truck): Long = withContext(Dispatchers.IO) {
    val id = if (truck.id == 0L) {
      truckDao.insertTruck(truck)
    } else {
      truckDao.updateTruck(truck)
      truck.id
    }
    syncService.uploadTruckToCloud(truck.copy(id = id))
    id
  }

  suspend fun deleteTruck(truck: Truck): Unit = withContext(Dispatchers.IO) {
    syncService.deleteTruckFromCloud(truck)
    truckDao.deleteTruck(truck)
  }
}
