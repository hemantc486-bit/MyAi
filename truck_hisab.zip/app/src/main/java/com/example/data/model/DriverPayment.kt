package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "driver_payments")
data class DriverPayment(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val driverId: Long,
  val driverName: String,
  val date: String, // Format: YYYY-MM-DD
  val amount: Double,
  val paymentType: String, // e.g. "एडवांस (Advance)", "वेतन भुगतान (Salary)", "बोनस (Bonus)", "अन्य (Other)"
  val paymentMode: String = "नकद (Cash)", // "नकद (Cash)", "ऑनलाइन / UPI", "बैंक ट्रांसफर"
  val remarks: String = "",
  val createdAt: Long = System.currentTimeMillis()
)
