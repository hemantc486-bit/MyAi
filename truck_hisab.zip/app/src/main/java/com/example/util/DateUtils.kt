package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class CalendarDay(
  val dayNumber: Int,
  val dateString: String, // YYYY-MM-DD
  val isCurrentMonth: Boolean,
  val isToday: Boolean
)

object DateUtils {
  private val HINDI_MONTHS = arrayOf(
    "जनवरी", "फरवरी", "मार्च", "अप्रैल", "मई", "जून",
    "जुलाई", "अगस्त", "सितम्बर", "अक्टूबर", "नवम्बर", "दिसम्बर"
  )

  val WEEKDAYS_HINDI = arrayOf("रवि", "सोम", "मंगल", "बुध", "गुरु", "शुक्र", "शनि")

  fun getAllHindiMonths(): List<String> = HINDI_MONTHS.toList()

  fun getHindiMonthName(month: Int): String {
    val index = (month - 1).coerceIn(0, 11)
    return HINDI_MONTHS[index]
  }

  fun getTodayDateString(): String {
    val cal = Calendar.getInstance()
    val y = cal.get(Calendar.YEAR)
    val m = cal.get(Calendar.MONTH) + 1
    val d = cal.get(Calendar.DAY_OF_MONTH)
    return String.format(Locale.US, "%04d-%02d-%02d", y, m, d)
  }

  fun getYesterdayDateString(): String {
    val cal = Calendar.getInstance()
    cal.add(Calendar.DAY_OF_YEAR, -1)
    val y = cal.get(Calendar.YEAR)
    val m = cal.get(Calendar.MONTH) + 1
    val d = cal.get(Calendar.DAY_OF_MONTH)
    return String.format(Locale.US, "%04d-%02d-%02d", y, m, d)
  }

  fun getPastDateString(daysAgo: Int): String {
    val cal = Calendar.getInstance()
    cal.add(Calendar.DAY_OF_YEAR, -daysAgo)
    val y = cal.get(Calendar.YEAR)
    val m = cal.get(Calendar.MONTH) + 1
    val d = cal.get(Calendar.DAY_OF_MONTH)
    return String.format(Locale.US, "%04d-%02d-%02d", y, m, d)
  }

  fun getCurrentYear(): Int = Calendar.getInstance().get(Calendar.YEAR)
  fun getCurrentMonth(): Int = Calendar.getInstance().get(Calendar.MONTH) + 1

  fun formatToHindiDisplayDate(dateString: String): String {
    return try {
      val parts = dateString.split("-")
      if (parts.size == 3) {
        val y = parts[0]
        val m = parts[1].toInt()
        val d = parts[2].toInt()
        "$d ${getHindiMonthName(m)} $y"
      } else {
        dateString
      }
    } catch (e: Exception) {
      dateString
    }
  }

  fun generateMonthCalendarDays(year: Int, month: Int, todayString: String = getTodayDateString()): List<CalendarDay> {
    val days = mutableListOf<CalendarDay>()

    val cal = Calendar.getInstance()
    cal.set(Calendar.YEAR, year)
    cal.set(Calendar.MONTH, month - 1)
    cal.set(Calendar.DAY_OF_MONTH, 1)

    // First day of week: Calendar.SUNDAY is 1, Calendar.MONDAY is 2, etc.
    val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) // 1 = Sunday, 2 = Monday, ...
    val daysInCurrentMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)

    // Previous month days to fill leading space
    val prevMonthCal = Calendar.getInstance()
    prevMonthCal.set(Calendar.YEAR, year)
    prevMonthCal.set(Calendar.MONTH, month - 1)
    prevMonthCal.add(Calendar.MONTH, -1)
    val daysInPrevMonth = prevMonthCal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val prevYear = prevMonthCal.get(Calendar.YEAR)
    val prevMonth = prevMonthCal.get(Calendar.MONTH) + 1

    val leadingBlanks = firstDayOfWeek - 1 // 0 for Sunday
    for (i in leadingBlanks downTo 1) {
      val dayNum = daysInPrevMonth - i + 1
      val dateStr = String.format(Locale.US, "%04d-%02d-%02d", prevYear, prevMonth, dayNum)
      days.add(CalendarDay(dayNum, dateStr, isCurrentMonth = false, isToday = (dateStr == todayString)))
    }

    // Current month days
    for (d in 1..daysInCurrentMonth) {
      val dateStr = String.format(Locale.US, "%04d-%02d-%02d", year, month, d)
      days.add(CalendarDay(d, dateStr, isCurrentMonth = true, isToday = (dateStr == todayString)))
    }

    // Trailing next month days to complete 35 or 42 grid cells
    val remaining = (7 - (days.size % 7)) % 7
    val nextMonthCal = Calendar.getInstance()
    nextMonthCal.set(Calendar.YEAR, year)
    nextMonthCal.set(Calendar.MONTH, month - 1)
    nextMonthCal.add(Calendar.MONTH, 1)
    val nextYear = nextMonthCal.get(Calendar.YEAR)
    val nextMonth = nextMonthCal.get(Calendar.MONTH) + 1

    for (d in 1..remaining) {
      val dateStr = String.format(Locale.US, "%04d-%02d-%02d", nextYear, nextMonth, d)
      days.add(CalendarDay(d, dateStr, isCurrentMonth = false, isToday = (dateStr == todayString)))
    }

    return days
  }
}
