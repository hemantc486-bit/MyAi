package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.TruckHisabRepository
import com.example.data.model.UserAccount
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AuthUiState(
  val mobile: String = "",
  val password: String = "",
  val ownerName: String = "",
  val businessName: String = "",
  val primaryTruck: String = "",
  val isRegisterMode: Boolean = false,
  val isLoading: Boolean = false,
  val errorMessage: String? = null
)

class AuthViewModel(
  private val repository: TruckHisabRepository
) : ViewModel() {

  val currentUser: StateFlow<UserAccount?> = repository.currentUser

  private val _uiState = MutableStateFlow(AuthUiState())
  val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

  fun onMobileChange(value: String) {
    _uiState.value = _uiState.value.copy(mobile = value, errorMessage = null)
  }

  fun onPasswordChange(value: String) {
    _uiState.value = _uiState.value.copy(password = value, errorMessage = null)
  }

  fun onOwnerNameChange(value: String) {
    _uiState.value = _uiState.value.copy(ownerName = value, errorMessage = null)
  }

  fun onBusinessNameChange(value: String) {
    _uiState.value = _uiState.value.copy(businessName = value, errorMessage = null)
  }

  fun onPrimaryTruckChange(value: String) {
    _uiState.value = _uiState.value.copy(primaryTruck = value, errorMessage = null)
  }

  fun toggleMode() {
    _uiState.value = _uiState.value.copy(
      isRegisterMode = !_uiState.value.isRegisterMode,
      errorMessage = null
    )
  }

  fun fillDemoCredentials() {
    _uiState.value = _uiState.value.copy(
      mobile = "9876543210",
      password = "1234",
      isRegisterMode = false,
      errorMessage = null
    )
  }

  fun clearError() {
    _uiState.value = _uiState.value.copy(errorMessage = null)
  }

  fun login() {
    val state = _uiState.value
    if (state.mobile.isBlank()) {
      _uiState.value = state.copy(errorMessage = "कृपया मोबाइल नंबर दर्ज करें")
      return
    }
    if (state.password.isBlank()) {
      _uiState.value = state.copy(errorMessage = "कृपया पासवर्ड दर्ज करें")
      return
    }

    viewModelScope.launch {
      _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
      val result = repository.login(state.mobile, state.password)
      if (result.isFailure) {
        _uiState.value = _uiState.value.copy(
          isLoading = false,
          errorMessage = result.exceptionOrNull()?.message ?: "लॉगिन असफल रहा"
        )
      } else {
        _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = null)
      }
    }
  }

  fun register() {
    val state = _uiState.value
    if (state.ownerName.isBlank()) {
      _uiState.value = state.copy(errorMessage = "कृपया अपना नाम दर्ज करें")
      return
    }
    if (state.mobile.length < 10) {
      _uiState.value = state.copy(errorMessage = "कृपया 10 अंकों का वैध मोबाइल नंबर दर्ज करें")
      return
    }
    if (state.password.length < 4) {
      _uiState.value = state.copy(errorMessage = "पासवर्ड कम से कम 4 अंकों का होना चाहिए")
      return
    }

    viewModelScope.launch {
      _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
      val newUser = UserAccount(
        mobile = state.mobile.trim(),
        password = state.password.trim(),
        ownerName = state.ownerName.trim(),
        businessName = if (state.businessName.isNotBlank()) state.businessName.trim() else "माय ट्रांसपोर्ट",
        primaryTruck = state.primaryTruck.trim().uppercase()
      )
      val result = repository.register(newUser)
      if (result.isFailure) {
        _uiState.value = _uiState.value.copy(
          isLoading = false,
          errorMessage = result.exceptionOrNull()?.message ?: "खाता बनाने में त्रुटि हुई"
        )
      } else {
        _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = null)
      }
    }
  }

  fun signInWithGoogle(activity: android.app.Activity) {
    _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
    repository.signInWithGoogle(
      activity = activity,
      onSuccess = {
        _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = null)
      },
      onError = { errorMsg ->
        _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = errorMsg)
      },
      onCancelled = {
        _uiState.value = _uiState.value.copy(isLoading = false)
      }
    )
  }

  fun logout() {
    repository.logout()
  }

  class Factory(private val repository: TruckHisabRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
      return AuthViewModel(repository) as T
    }
  }
}
