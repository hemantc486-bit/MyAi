package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.DriverDao
import com.example.data.dao.DriverPaymentDao
import com.example.data.dao.HisabDao
import com.example.data.dao.TruckDao
import com.example.data.dao.UserDao
import com.example.data.model.Driver
import com.example.data.model.DriverPayment
import com.example.data.model.HisabEntry
import com.example.data.model.Truck
import com.example.data.model.UserAccount
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [UserAccount::class, Driver::class, HisabEntry::class, DriverPayment::class, Truck::class],
  version = 3,
  exportSchema = false
)
abstract class TruckHisabDatabase : RoomDatabase() {
  abstract fun userDao(): UserDao
  abstract fun driverDao(): DriverDao
  abstract fun hisabDao(): HisabDao
  abstract fun driverPaymentDao(): DriverPaymentDao
  abstract fun truckDao(): TruckDao

  companion object {
    @Volatile
    private var INSTANCE: TruckHisabDatabase? = null

    fun getDatabase(context: Context, scope: CoroutineScope = CoroutineScope(Dispatchers.IO)): TruckHisabDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          TruckHisabDatabase::class.java,
          "truck_hisab_database"
        )
          .fallbackToDestructiveMigration()
          .addCallback(DatabaseCallback(scope))
          .build()
        INSTANCE = instance
        instance
      }
    }

    private class DatabaseCallback(
      private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
      override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)
        INSTANCE?.let { database ->
          scope.launch {
            populateInitialData(
              database.userDao(),
              database.driverDao(),
              database.hisabDao(),
              database.driverPaymentDao(),
              database.truckDao()
            )
          }
        }
      }

      suspend fun populateInitialData(
        userDao: UserDao,
        driverDao: DriverDao,
        hisabDao: HisabDao,
        paymentDao: DriverPaymentDao,
        truckDao: TruckDao
      ) {
        // Create Default/Demo Transport Account
        val demoUser = UserAccount(
          mobile = "9876543210",
          password = "1234",
          ownerName = "राजेश शर्मा",
          businessName = "शर्मा रोडलाइंस",
          primaryTruck = "RJ 14 GA 5521"
        )
        userDao.insertUser(demoUser)

        // Seed 3 Drivers
        val driver1Id = driverDao.insertDriver(
          Driver(
            name = "रमेश सिंह",
            phone = "9829012345",
            assignedTruck = "RJ 14 GA 5521",
            monthlySalary = 18000.0,
            notes = "जयपुर से दिल्ली रूट"
          )
        )

        val driver2Id = driverDao.insertDriver(
          Driver(
            name = "कुलदीप यादव",
            phone = "9812067890",
            assignedTruck = "HR 55 AB 9988",
            monthlySalary = 20000.0,
            notes = "गुड़गांव से अहमदाबाद"
          )
        )

        val driver3Id = driverDao.insertDriver(
          Driver(
            name = "बलविंदर जीत",
            phone = "9878054321",
            assignedTruck = "PB 10 CT 4321",
            monthlySalary = 22000.0,
            notes = "लुधियाना से मुंबई"
          )
        )

        // Seed sample hisab entries for today and recent days (November 2026)
        val today = "2026-11-04"
        val yesterday = "2026-11-03"
        val dayBefore = "2026-11-02"

        // Entry 1 for today: Ramesh Singh
        hisabDao.insertEntry(
          HisabEntry(
            date = today,
            driverId = driver1Id,
            driverName = "रमेश सिंह",
            truckNumber = "RJ 14 GA 5521",
            salary = 600.0,
            expenseTotal = 8500.0,
            dieselExpense = 6800.0,
            tollExpense = 1100.0,
            repairExpense = 200.0,
            foodExpense = 300.0,
            otherExpense = 100.0,
            deposit = 12000.0,
            balance = 12000.0 - (600.0 + 8500.0), // +2,900
            notes = "जयपुर से दिल्ली माल भाड़ा"
          )
        )

        // Entry 2 for today: Kuldeep Yadav
        hisabDao.insertEntry(
          HisabEntry(
            date = today,
            driverId = driver2Id,
            driverName = "कुलदीप यादव",
            truckNumber = "HR 55 AB 9988",
            salary = 700.0,
            expenseTotal = 14200.0,
            dieselExpense = 11500.0,
            tollExpense = 1800.0,
            repairExpense = 500.0,
            foodExpense = 400.0,
            otherExpense = 0.0,
            deposit = 15000.0,
            balance = 15000.0 - (700.0 + 14200.0), // +100
            notes = "रेवाड़ी से वडोदरा कंटेनर"
          )
        )

        // Entry for yesterday: Balwinder Jeet
        hisabDao.insertEntry(
          HisabEntry(
            date = yesterday,
            driverId = driver3Id,
            driverName = "बलविंदर जीत",
            truckNumber = "PB 10 CT 4321",
            salary = 750.0,
            expenseTotal = 16800.0,
            dieselExpense = 13500.0,
            tollExpense = 2100.0,
            repairExpense = 800.0,
            foodExpense = 400.0,
            otherExpense = 0.0,
            deposit = 18000.0,
            balance = 18000.0 - (750.0 + 16800.0), // +450
            notes = "लुधियाना से कांडला पोर्ट"
          )
        )

        // Entry for day before: Ramesh Singh
        hisabDao.insertEntry(
          HisabEntry(
            date = dayBefore,
            driverId = driver1Id,
            driverName = "रमेश सिंह",
            truckNumber = "RJ 14 GA 5521",
            salary = 600.0,
            expenseTotal = 5200.0,
            dieselExpense = 4200.0,
            tollExpense = 650.0,
            repairExpense = 100.0,
            foodExpense = 250.0,
            otherExpense = 0.0,
            deposit = 7000.0,
            balance = 7000.0 - (600.0 + 5200.0), // +1,200
            notes = "लोकल डिलीवरी"
          )
        )

        // Seed Sample Driver Advance & Salary Payments
        paymentDao.insertPayment(
          DriverPayment(
            driverId = driver1Id,
            driverName = "रमेश सिंह",
            date = "2026-11-01",
            amount = 5000.0,
            paymentType = "एडवांस (Advance)",
            paymentMode = "ऑनलाइन / UPI",
            remarks = "घर खर्च के लिए एडवांस"
          )
        )

        paymentDao.insertPayment(
          DriverPayment(
            driverId = driver1Id,
            driverName = "रमेश सिंह",
            date = "2026-11-04",
            amount = 2000.0,
            paymentType = "एडवांस (Advance)",
            paymentMode = "नकद (Cash)",
            remarks = "रास्ते के खर्च हेतु"
          )
        )

        paymentDao.insertPayment(
          DriverPayment(
            driverId = driver2Id,
            driverName = "कुलदीप यादव",
            date = "2026-11-02",
            amount = 4000.0,
            paymentType = "एडवांस (Advance)",
            paymentMode = "ऑनलाइन / UPI",
            remarks = "ट्रिप एडवांस"
          )
        )

        paymentDao.insertPayment(
          DriverPayment(
            driverId = driver3Id,
            driverName = "बलविंदर जीत",
            date = "2026-10-31",
            amount = 15000.0,
            paymentType = "वेतन भुगतान (Salary)",
            paymentMode = "बैंक ट्रांसफर",
            remarks = "अक्टूबर माह का वेतन भुगतान"
          )
        )

        // Seed 3 Trucks matching our active transport operations
        truckDao.insertTruck(
          Truck(
            truckNumber = "RJ 14 GA 5521",
            truckName = "भारतबेंज 16 चक्का (ट्रॉला)",
            truckModel = "16 चक्का ट्रेलर",
            assignedDriverName = "रमेश सिंह",
            notes = "जयपुर-दिल्ली-मुंबई नेशनल परमिट"
          )
        )

        truckDao.insertTruck(
          Truck(
            truckNumber = "HR 55 AB 9988",
            truckName = "टाटा सिग्ना 12 चक्का",
            truckModel = "12 चक्का ओपन बॉडी",
            assignedDriverName = "कुलदीप यादव",
            notes = "गुड़गांव-रेवाड़ी-वडोदरा रूट"
          )
        )

        truckDao.insertTruck(
          Truck(
            truckNumber = "PB 10 CT 4321",
            truckName = "अशोक लीलैंड कंटेनर",
            truckModel = "कंटेनर बॉडी (32 फीट)",
            assignedDriverName = "बलविंदर जीत",
            notes = "लुधियाना-कांडला पोर्ट माल ढुलाई"
          )
        )
      }
    }
  }
}
