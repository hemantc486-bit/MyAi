package com.example.ai

import com.example.data.model.Driver
import com.example.data.model.DriverPayment
import com.example.data.model.HisabEntry
import com.example.data.model.Truck
import com.example.ui.viewmodel.DriverLedgerSummary
import com.example.ui.viewmodel.TruckLedgerSummary
import com.example.util.DateUtils
import java.util.Locale

object TruckHisabAiContextBuilder {

  fun buildAccountingSnapshotPrompt(
    trucks: List<Truck>,
    drivers: List<Driver>,
    truckSummaries: List<TruckLedgerSummary>,
    driverSummaries: List<DriverLedgerSummary>,
    allEntries: List<HisabEntry>,
    recentPayments: List<DriverPayment>,
    todayDate: String = DateUtils.getTodayDateString()
  ): String {
    val sb = StringBuilder()
    sb.appendLine("=== CURRENT LIVE DATA SNAPSHOT (ट्रक हिसाब का असली डेटा) ===")
    sb.appendLine("आज की तारीख (Today's Date): $todayDate")
    sb.appendLine("चालू वर्ष और महीना: ${todayDate.take(7)}")

    // 1. Registered Trucks
    sb.appendLine("\n[पंजीकृत गाड़ियाँ / Trucks (${trucks.size} कुल)]:")
    if (trucks.isEmpty()) {
      sb.appendLine("कोई ट्रक पंजीकृत नहीं है।")
    } else {
      trucks.forEach { t ->
        sb.appendLine("- गाड़ी नंबर: ${t.truckNumber} | नाम/मॉडल: ${t.truckName} (${t.truckModel}) | तय ड्राइवर: ${t.assignedDriverName.ifBlank { "कोई नहीं" }}")
      }
    }

    // 2. Registered Drivers
    sb.appendLine("\n[पंजीकृत ड्राइवर्स / Drivers (${drivers.size} कुल)]:")
    if (drivers.isEmpty()) {
      sb.appendLine("कोई ड्राइवर पंजीकृत नहीं है।")
    } else {
      drivers.forEach { d ->
        val sum = driverSummaries.find { it.driver.id == d.id }
        val netBal = sum?.netBalance ?: 0.0
        val adv = sum?.totalAdvancePaid ?: 0.0
        val salPaid = sum?.totalSalaryPaid ?: 0.0
        sb.appendLine("- ड्राइवर: ${d.name} (ID: ${d.id}, फोन: ${d.phone.ifBlank { "N/A" }}) | मासिक तय वेतन: ₹${d.monthlySalary} | कुल एडवांस: ₹$adv | चुकाया वेतन: ₹$salPaid | बाकी बैलेंस: ₹$netBal (ऋण/देनदारी)")
      }
    }

    // 3. Today's hisab
    val todayEntries = allEntries.filter { it.date == todayDate }
    val todayIncome = todayEntries.sumOf { it.deposit }
    val todayDiesel = todayEntries.sumOf { it.dieselExpense }
    val todayToll = todayEntries.sumOf { it.tollExpense }
    val todayRepair = todayEntries.sumOf { it.repairExpense }
    val todayFood = todayEntries.sumOf { it.foodExpense }
    val todaySalary = todayEntries.sumOf { it.salary }
    val todayOther = todayEntries.sumOf { it.otherExpense }
    val todayExpense = todayEntries.sumOf { it.expenseTotal + it.salary }
    val todayProfitLoss = todayIncome - todayExpense

    sb.appendLine("\n[आज का हिसाब (Today's Financials - $todayDate)]:")
    sb.appendLine("- कुल प्रविष्टियाँ (Entries): ${todayEntries.size}")
    sb.appendLine("- कुल भाड़ा कमाई (Freight Income / Deposit): ₹$todayIncome")
    sb.appendLine("- कुल डीजल खर्च: ₹$todayDiesel")
    sb.appendLine("- कुल टोल खर्च: ₹$todayToll")
    sb.appendLine("- कुल मरम्मत खर्च: ₹$todayRepair")
    sb.appendLine("- कुल खाना खर्च: ₹$todayFood")
    sb.appendLine("- कुल ड्राइवर वेतन/भत्ता: ₹$todaySalary")
    sb.appendLine("- कुल अन्य खर्च: ₹$todayOther")
    sb.appendLine("- कुल खर्च (Total Expense): ₹$todayExpense")
    sb.appendLine("- आज का शुद्ध नफा/मुनाफा (Profit/Loss): ₹$todayProfitLoss (${if (todayProfitLoss >= 0) "मुनाफा" else "घाटा"})")

    // 4. Per Truck Summaries (Income, Diesel, Profit/Loss)
    sb.appendLine("\n[प्रति गाड़ी वित्तीय विवरण (Per Truck P&L Summary)]:")
    truckSummaries.forEach { ts ->
      sb.appendLine("- ${ts.truck.truckNumber} (${ts.truck.truckName}):")
      sb.appendLine("  • कुल चक्कर (Trips): ${ts.tripCount}")
      sb.appendLine("  • कुल भाड़ा कमाई: ₹${ts.totalFreightIncome}")
      sb.appendLine("  • डीजल खर्च: ₹${ts.dieselExpense}")
      sb.appendLine("  • टोल खर्च: ₹${ts.tollExpense}")
      sb.appendLine("  • मरम्मत/पंचर खर्च: ₹${ts.repairExpense}")
      sb.appendLine("  • कुल खर्च: ₹${ts.totalExpense}")
      sb.appendLine("  • शुद्ध नफा/नुकसान: ₹${ts.netProfitLoss} (${if (ts.isProfit) "मुनाफा" else "घाटा"})")
    }

    // 5. Last 7 Days Overview
    val sevenDaysAgoMillis = System.currentTimeMillis() - (7L * 24 * 60 * 60 * 1000)
    val last7DaysEntries = allEntries.filter { it.createdAt >= sevenDaysAgoMillis || it.date >= DateUtils.getPastDateString(7) }
    val last7Expense = last7DaysEntries.sumOf { it.expenseTotal + it.salary }
    val last7Income = last7DaysEntries.sumOf { it.deposit }
    val last7Diesel = last7DaysEntries.sumOf { it.dieselExpense }
    sb.appendLine("\n[पिछले 7 दिनों का हिसाब (Last 7 Days)]:")
    sb.appendLine("- कुल प्रविष्टियाँ: ${last7DaysEntries.size}")
    sb.appendLine("- पिछले 7 दिनों का कुल खर्च: ₹$last7Expense (जिसमें डीजल: ₹$last7Diesel)")
    sb.appendLine("- पिछले 7 दिनों की कुल कमाई: ₹$last7Income")
    sb.appendLine("- पिछले 7 दिनों का नफा/नुकसान: ₹${last7Income - last7Expense}")

    // 6. Recent Entries
    sb.appendLine("\n[हाल की प्रविष्टियाँ (Recent Trips / Hisab Entries)]:")
    val recentEntries = allEntries.sortedByDescending { it.date + "_" + it.id }.take(10)
    if (recentEntries.isEmpty()) {
      sb.appendLine("कोई हालिया एंट्री नहीं है।")
    } else {
      recentEntries.forEach { e ->
        sb.appendLine("- तारीख: ${e.date} | गाड़ी: ${e.truckNumber} | ड्राइवर: ${e.driverName} | डीजल: ₹${e.dieselExpense} | टोल: ₹${e.tollExpense} | रिपेयर: ₹${e.repairExpense} | भाड़ा जमा: ₹${e.deposit} | बाकी: ₹${e.balance} | नोट: ${e.notes}")
      }
    }

    // 7. Recent Driver Payments
    sb.appendLine("\n[हाल के ड्राइवर भुगतान (Recent Payments)]:")
    recentPayments.take(5).forEach { p ->
      sb.appendLine("- तारीख: ${p.date} | ड्राइवर: ${p.driverName} | रकम: ₹${p.amount} | प्रकार: ${p.paymentType} (${p.paymentMode}) | नोट: ${p.remarks}")
    }
    sb.appendLine("=== END OF LIVE DATA SNAPSHOT ===")
    return sb.toString()
  }
}
