package com.example.ai

import com.example.data.model.Driver
import com.example.data.model.DriverPayment
import com.example.data.model.HisabEntry
import com.example.data.model.Truck

enum class AiMessageSender {
  USER,
  ASSISTANT,
  SYSTEM
}

enum class ActionCardStatus {
  PENDING,
  CONFIRMED,
  CANCELLED
}

sealed class ProposedAction {
  abstract var status: ActionCardStatus

  data class AddHisabEntry(
    val entry: HisabEntry,
    override var status: ActionCardStatus = ActionCardStatus.PENDING
  ) : ProposedAction()

  data class AddDriverPayment(
    val payment: DriverPayment,
    override var status: ActionCardStatus = ActionCardStatus.PENDING
  ) : ProposedAction()

  data class AddNewTruck(
    val truck: Truck,
    override var status: ActionCardStatus = ActionCardStatus.PENDING
  ) : ProposedAction()

  data class AddNewDriver(
    val driver: Driver,
    override var status: ActionCardStatus = ActionCardStatus.PENDING
  ) : ProposedAction()

  data class NavigateToScreen(
    val targetTab: Int,
    val title: String,
    val date: String? = null,
    val truckFilter: String? = null,
    val driverFilterId: Long? = null,
    override var status: ActionCardStatus = ActionCardStatus.PENDING
  ) : ProposedAction()

  data class ShareSummarySlip(
    val shareType: String, // "TRUCK", "DRIVER", "MONTHLY"
    val targetName: String,
    val truck: Truck? = null,
    val driver: Driver? = null,
    override var status: ActionCardStatus = ActionCardStatus.PENDING
  ) : ProposedAction()
}

data class ChatMessage(
  val id: String = java.util.UUID.randomUUID().toString(),
  val sender: AiMessageSender,
  val text: String,
  val timestamp: Long = System.currentTimeMillis(),
  val proposedAction: ProposedAction? = null,
  val isAudioPlaying: Boolean = false,
  val isError: Boolean = false
)
