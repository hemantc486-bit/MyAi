package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DriverPayment
import kotlinx.coroutines.flow.Flow

@Dao
interface DriverPaymentDao {
  @Query("SELECT * FROM driver_payments ORDER BY date DESC, id DESC")
  fun getAllPayments(): Flow<List<DriverPayment>>

  @Query("SELECT * FROM driver_payments WHERE driverId = :driverId ORDER BY date DESC, id DESC")
  fun getPaymentsForDriver(driverId: Long): Flow<List<DriverPayment>>

  @Query("SELECT * FROM driver_payments WHERE date LIKE :monthPrefix || '%' ORDER BY date DESC")
  fun getPaymentsForMonth(monthPrefix: String): Flow<List<DriverPayment>>

  @Query("SELECT * FROM driver_payments WHERE id = :id LIMIT 1")
  suspend fun getPaymentById(id: Long): DriverPayment?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPayment(payment: DriverPayment): Long

  @Update
  suspend fun updatePayment(payment: DriverPayment)

  @Query("DELETE FROM driver_payments WHERE id = :id")
  suspend fun deletePaymentById(id: Long)

  @Delete
  suspend fun deletePayment(payment: DriverPayment)

  @Query("SELECT COUNT(*) FROM driver_payments")
  suspend fun getPaymentCount(): Int
}
