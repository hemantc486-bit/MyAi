package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ai.AiAssistantViewModel
import com.example.data.TruckHisabDatabase
import com.example.data.TruckHisabRepository
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.HisabViewModel
import com.example.util.configureAppCheck

class MainActivity : ComponentActivity() {

  private val repository by lazy {
    val database = TruckHisabDatabase.getDatabase(applicationContext)
    TruckHisabRepository(database, applicationContext)
  }

  private val authViewModel: AuthViewModel by viewModels {
    AuthViewModel.Factory(repository)
  }

  private val hisabViewModel: HisabViewModel by viewModels {
    HisabViewModel.Factory(repository)
  }

  private val aiAssistantViewModel: AiAssistantViewModel by viewModels {
    AiAssistantViewModel.Factory(hisabViewModel, applicationContext)
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    // STEP 1: Mandatory App Check configuration with launch intent before UI or Firebase operations
    configureAppCheck(this, intent)

    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        TruckHisabApp(
          authViewModel = authViewModel,
          hisabViewModel = hisabViewModel,
          aiAssistantViewModel = aiAssistantViewModel
        )
      }
    }
  }
}

@Composable
fun TruckHisabApp(
  authViewModel: AuthViewModel,
  hisabViewModel: HisabViewModel,
  aiAssistantViewModel: AiAssistantViewModel,
  modifier: Modifier = Modifier
) {
  val currentUser by authViewModel.currentUser.collectAsState()

  Crossfade(
    targetState = currentUser,
    label = "AuthCrossfade",
    modifier = modifier.fillMaxSize()
  ) { user ->
    if (user == null) {
      LoginScreen(
        viewModel = authViewModel,
        modifier = Modifier.fillMaxSize()
      )
    } else {
      DashboardScreen(
        user = user,
        hisabViewModel = hisabViewModel,
        aiAssistantViewModel = aiAssistantViewModel,
        onLogout = { authViewModel.logout() },
        modifier = Modifier.fillMaxSize()
      )
    }
  }
}
