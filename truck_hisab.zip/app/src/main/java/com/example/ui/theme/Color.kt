package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Truck Transport Theme Palette
val NavyDark = Color(0xFF0A192F)
val NavyPrimary = Color(0xFF0D2040)
val NavyLight = Color(0xFF1E3A5F)

val AmberAccent = Color(0xFFD97706)
val AmberDark = Color(0xFFB45309)
val AmberLight = Color(0xFFFDE68A)

// Finance semantic colors
val KharchRed = Color(0xFFDC2626)
val KharchRedBg = Color(0xFFFEE2E2)
val JamaGreen = Color(0xFF16A34A)
val JamaGreenBg = Color(0xFFDCFCE7)
val SalaryPurple = Color(0xFF7C3AED)
val SalaryPurpleBg = Color(0xFFEDE9FE)
val BalanceOrange = Color(0xFFEA580C)
val BalanceOrangeBg = Color(0xFFFFEDD5)

// Neutral surfaces
val BackgroundSlate = Color(0xFFF8FAFC)
val SurfaceWhite = Color(0xFFFFFFFF)
val SurfaceVariantSlate = Color(0xFFF1F5F9)
val BorderLight = Color(0xFFE2E8F0)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)
val TextMuted = Color(0xFF94A3B8)
