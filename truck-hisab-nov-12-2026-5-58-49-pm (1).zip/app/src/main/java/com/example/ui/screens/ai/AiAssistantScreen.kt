package com.example.ui.screens.ai

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ai.ActionCardStatus
import com.example.ai.AiAssistantViewModel
import com.example.ai.AiMessageSender
import com.example.ai.ChatMessage
import com.example.ai.ProposedAction
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.JamaGreen
import com.example.ui.theme.KharchRed
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.util.DateUtils
import com.example.util.FormatUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantScreen(
  viewModel: AiAssistantViewModel,
  businessName: String,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val messages by viewModel.messages.collectAsState()
  val isLoading by viewModel.isLoading.collectAsState()
  val inputText by viewModel.inputText.collectAsState()
  val isListening by viewModel.isListening.collectAsState()
  val isSpeaking by viewModel.isSpeaking.collectAsState()
  val autoSpeakEnabled by viewModel.autoSpeakEnabled.collectAsState()

  val listState = rememberLazyListState()

  // Scroll to latest message
  LaunchedEffect(messages.size, isLoading) {
    if (messages.isNotEmpty()) {
      listState.animateScrollToItem(messages.size - 1)
    }
  }

  // Audio permission launcher
  val audioPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { isGranted ->
    if (isGranted) {
      viewModel.startVoiceListening { error ->
        Toast.makeText(context, error, Toast.LENGTH_SHORT).show()
      }
    } else {
      Toast.makeText(context, "माइक की अनुमति (Permission) दें ताकि आप बोलकर हिसाब लिखवा सकें।", Toast.LENGTH_LONG).show()
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    // Header Bar
    Surface(
      color = NavyPrimary,
      tonalElevation = 4.dp,
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(AmberAccent),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.size(20.dp)
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "ट्रक हिसाब AI मुनीम",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              Spacer(modifier = Modifier.width(6.dp))
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .clip(CircleShape)
                  .background(JamaGreen)
              )
            }
            Text(
              text = "Gemini 3.8 AI • बोलकर या लिखकर हिसाब करें",
              style = MaterialTheme.typography.labelSmall,
              color = Color.White.copy(alpha = 0.8f)
            )
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          // Auto speak toggle
          IconButton(
            onClick = { viewModel.toggleAutoSpeak() },
            modifier = Modifier.testTag("ai_toggle_speech_button")
          ) {
            Icon(
              imageVector = if (autoSpeakEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
              contentDescription = "आवाज़ चालू/बंद",
              tint = if (autoSpeakEnabled) AmberAccent else Color.White.copy(alpha = 0.6f)
            )
          }

          // Clear chat
          IconButton(
            onClick = { viewModel.clearChat() },
            modifier = Modifier.testTag("ai_clear_chat_button")
          ) {
            Icon(
              imageVector = Icons.Default.DeleteSweep,
              contentDescription = "चैट साफ़ करें",
              tint = Color.White.copy(alpha = 0.85f)
            )
          }
        }
      }
    }

    // Active Audio Speaking Bar
    AnimatedVisibility(visible = isSpeaking) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(AmberAccent.copy(alpha = 0.15f))
          .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.VolumeUp,
            contentDescription = null,
            tint = AmberAccent,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "AI मुनीम बोल रहा है...",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface
          )
        }
        TextButton(
          onClick = { viewModel.stopSpeaking() },
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Stop,
            contentDescription = null,
            tint = KharchRed,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text("आवाज़ रोकें", color = KharchRed, style = MaterialTheme.typography.labelSmall)
        }
      }
    }

    // Chat Messages List
    LazyColumn(
      state = listState,
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .padding(horizontal = 12.dp),
      contentPadding = PaddingValues(vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      items(messages, key = { it.id }) { message ->
        ChatMessageItem(
          message = message,
          onSpeak = { viewModel.speakMessage(message) },
          onConfirmAction = { action -> viewModel.confirmAction(message.id, action) },
          onCancelAction = { action -> viewModel.cancelAction(message.id, action) }
        )
      }

      if (isLoading) {
        item {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(AmberAccent.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = AmberAccent,
                modifier = Modifier.size(18.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Card(
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
              shape = RoundedCornerShape(16.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                CircularProgressIndicator(
                  modifier = Modifier.size(16.dp),
                  strokeWidth = 2.dp,
                  color = AmberAccent
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                  text = "हिसाब की गणना कर रहा हूँ...",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }
      }
    }

    // Quick Suggestion Chips
    LazyRow(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 8.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      contentPadding = PaddingValues(horizontal = 4.dp)
    ) {
      items(viewModel.suggestionPrompts) { prompt ->
        FilterChip(
          selected = false,
          onClick = { viewModel.sendMessage(prompt) },
          label = {
            Text(
              text = prompt,
              style = MaterialTheme.typography.labelSmall
            )
          },
          leadingIcon = {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = null,
              modifier = Modifier.size(14.dp),
              tint = AmberAccent
            )
          },
          colors = FilterChipDefaults.filterChipColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
          )
        )
      }
    }

    // Listening Voice Indicator
    AnimatedVisibility(visible = isListening) {
      val infiniteTransition = rememberInfiniteTransition(label = "Pulse")
      val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
          animation = tween(600),
          repeatMode = RepeatMode.Reverse
        ),
        label = "PulseScale"
      )

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = KharchRed.copy(alpha = 0.12f)),
        shape = RoundedCornerShape(16.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .scale(pulseScale)
                .clip(CircleShape)
                .background(KharchRed),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = "सुन रहा हूँ... बोलिए",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = KharchRed
              )
              Text(
                text = "जैसे: आज RJ14 का 5000 डीजल लिख दो",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Button(
            onClick = { viewModel.stopVoiceListening() },
            colors = ButtonDefaults.buttonColors(containerColor = KharchRed),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            shape = RoundedCornerShape(12.dp)
          ) {
            Text("रोकें", color = Color.White, style = MaterialTheme.typography.labelSmall)
          }
        }
      }
    }

    // Input Bar
    Surface(
      tonalElevation = 6.dp,
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Voice Mic Button
        IconButton(
          onClick = {
            if (isListening) {
              viewModel.stopVoiceListening()
            } else {
              val hasPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
              ) == PackageManager.PERMISSION_GRANTED

              if (hasPermission) {
                viewModel.startVoiceListening { error ->
                  Toast.makeText(context, error, Toast.LENGTH_SHORT).show()
                }
              } else {
                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
              }
            }
          },
          modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(if (isListening) KharchRed else AmberAccent)
            .testTag("ai_mic_button")
        ) {
          Icon(
            imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
            contentDescription = if (isListening) "माइक रोकें" else "माइक से बोलें",
            tint = Color.White,
            modifier = Modifier.size(26.dp)
          )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Text Input Field
        OutlinedTextField(
          value = inputText,
          onValueChange = { viewModel.onInputTextChanged(it) },
          placeholder = {
            Text(
              text = if (isListening) "आवाज़ सुनी जा रही है..." else "यहाँ लिखें या माइक से बोलें...",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
          },
          modifier = Modifier
            .weight(1f)
            .testTag("ai_input_text_field"),
          shape = RoundedCornerShape(24.dp),
          colors = OutlinedTextFieldDefaults.colors(
            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
            focusedBorderColor = NavyPrimary
          ),
          maxLines = 3
        )

        Spacer(modifier = Modifier.width(8.dp))

        // Send Button
        IconButton(
          onClick = { viewModel.sendMessage() },
          enabled = inputText.isNotBlank() && !isLoading,
          modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(
              if (inputText.isNotBlank() && !isLoading) NavyPrimary else MaterialTheme.colorScheme.surfaceVariant
            )
            .testTag("ai_send_button")
        ) {
          Icon(
            imageVector = Icons.Default.Send,
            contentDescription = "संदेश भेजें",
            tint = if (inputText.isNotBlank() && !isLoading) Color.White else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.size(22.dp)
          )
        }
      }
    }
  }
}

@Composable
fun ChatMessageItem(
  message: ChatMessage,
  onSpeak: () -> Unit,
  onConfirmAction: (ProposedAction) -> Unit,
  onCancelAction: (ProposedAction) -> Unit
) {
  when (message.sender) {
    AiMessageSender.USER -> {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
      ) {
        Card(
          colors = CardDefaults.cardColors(containerColor = NavyPrimary),
          shape = RoundedCornerShape(topStart = 16.dp, topEnd = 4.dp, bottomStart = 16.dp, bottomEnd = 16.dp),
          modifier = Modifier
            .widthIn(max = 300.dp)
            .testTag("chat_user_message")
        ) {
          Text(
            text = message.text,
            color = Color.White,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
          )
        }
      }
    }

    AiMessageSender.ASSISTANT -> {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start
      ) {
        Box(
          modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(if (message.isError) KharchRed else AmberAccent),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(18.dp)
          )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Column(modifier = Modifier.weight(1f)) {
          ElevatedCard(
            colors = CardDefaults.elevatedCardColors(
              containerColor = if (message.isError) KharchRed.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
            ),
            shape = RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp),
            elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("chat_ai_message")
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text(
                text = message.text,
                color = if (message.isError) KharchRed else MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.bodyMedium,
                lineHeight = 22.sp
              )

              if (!message.isError) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.End
                ) {
                  IconButton(
                    onClick = onSpeak,
                    modifier = Modifier.size(32.dp)
                  ) {
                    Icon(
                      imageVector = Icons.Default.VolumeUp,
                      contentDescription = "आवाज़ में सुनें",
                      tint = MaterialTheme.colorScheme.primary,
                      modifier = Modifier.size(18.dp)
                    )
                  }
                }
              }
            }
          }

          // If this message has a proposed action, show the interactive confirmation card!
          if (message.proposedAction != null) {
            Spacer(modifier = Modifier.height(8.dp))
            ProposedActionConfirmationCard(
              action = message.proposedAction,
              onConfirm = { onConfirmAction(message.proposedAction) },
              onCancel = { onCancelAction(message.proposedAction) }
            )
          }
        }
      }
    }

    AiMessageSender.SYSTEM -> {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center
      ) {
        Surface(
          color = JamaGreen.copy(alpha = 0.15f),
          shape = RoundedCornerShape(12.dp)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = null,
              tint = JamaGreen,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = message.text,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = JamaGreen
            )
          }
        }
      }
    }
  }
}

@Composable
fun ProposedActionConfirmationCard(
  action: ProposedAction,
  onConfirm: () -> Unit,
  onCancel: () -> Unit
) {
  when (action) {
    is ProposedAction.AddHisabEntry -> {
      val entry = action.entry
      Card(
        colors = CardDefaults.cardColors(
          containerColor = AmberAccent.copy(alpha = 0.08f)
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, AmberAccent.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.AllInclusive,
                contentDescription = null,
                tint = NavyDark,
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "पुष्टि करें: नया हिसाब दर्ज करें",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = NavyDark
              )
            }

            Surface(
              color = AmberAccent.copy(alpha = 0.2f),
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = DateUtils.formatToHindiDisplayDate(entry.date),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Medium,
                color = NavyDark,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Vehicle & Driver badges
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Surface(
              color = MaterialTheme.colorScheme.surface,
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.weight(1f)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.AllInclusive, null, tint = NavyPrimary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = entry.truckNumber,
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold
                )
              }
            }

            Surface(
              color = MaterialTheme.colorScheme.surface,
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.weight(1f)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.Person, null, tint = AmberAccent, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = entry.driverName,
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))
          HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
          Spacer(modifier = Modifier.height(10.dp))

          // Breakdown
          Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (entry.dieselExpense > 0) {
              HisabDetailRow("⛽ डीजल खर्च (Diesel):", "₹${FormatUtils.formatCurrency(entry.dieselExpense)}", KharchRed)
            }
            if (entry.tollExpense > 0) {
              HisabDetailRow("🛣️ टोल खर्च (Toll):", "₹${FormatUtils.formatCurrency(entry.tollExpense)}", KharchRed)
            }
            if (entry.repairExpense > 0) {
              HisabDetailRow("🔧 रिपेयर/पंचर (Repair):", "₹${FormatUtils.formatCurrency(entry.repairExpense)}", KharchRed)
            }
            if (entry.foodExpense > 0) {
              HisabDetailRow("🍛 खाना खर्च (Food):", "₹${FormatUtils.formatCurrency(entry.foodExpense)}", KharchRed)
            }
            if (entry.salary > 0) {
              HisabDetailRow("👨‍✈️ ड्राइवर वेतन/भत्ता:", "₹${FormatUtils.formatCurrency(entry.salary)}", KharchRed)
            }
            if (entry.otherExpense > 0) {
              HisabDetailRow("📦 अन्य खर्च:", "₹${FormatUtils.formatCurrency(entry.otherExpense)}", KharchRed)
            }
            if (entry.deposit > 0) {
              HisabDetailRow("💰 भाड़ा जमा (Freight Income):", "₹${FormatUtils.formatCurrency(entry.deposit)}", JamaGreen)
            }
            if (entry.notes.isNotBlank()) {
              Text(
                text = "📝 नोट: ${entry.notes}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Action Confirmation Buttons
          when (action.status) {
            ActionCardStatus.PENDING -> {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                OutlinedButton(
                  onClick = onCancel,
                  modifier = Modifier
                    .weight(1f)
                    .testTag("cancel_hisab_button"),
                  shape = RoundedCornerShape(10.dp)
                ) {
                  Icon(Icons.Default.Cancel, null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("रद्द करें", style = MaterialTheme.typography.labelSmall)
                }

                Button(
                  onClick = onConfirm,
                  colors = ButtonDefaults.buttonColors(containerColor = JamaGreen),
                  modifier = Modifier
                    .weight(1.4f)
                    .testTag("confirm_hisab_button"),
                  shape = RoundedCornerShape(10.dp)
                ) {
                  Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(16.dp), tint = Color.White)
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("✓ कन्फर्म और सेव", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
              }
            }

            ActionCardStatus.CONFIRMED -> {
              Surface(
                color = JamaGreen.copy(alpha = 0.15f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier.padding(8.dp),
                  horizontalArrangement = Arrangement.Center,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(Icons.Default.CheckCircle, null, tint = JamaGreen, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("✓ Firebase में सफलतापूर्वक सेव हो गया", color = JamaGreen, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                }
              }
            }

            ActionCardStatus.CANCELLED -> {
              Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier.padding(8.dp),
                  horizontalArrangement = Arrangement.Center,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(Icons.Default.Cancel, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("रद्द किया गया", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                }
              }
            }
          }
        }
      }
    }

    is ProposedAction.AddDriverPayment -> {
      val payment = action.payment
      Card(
        colors = CardDefaults.cardColors(
          containerColor = AmberAccent.copy(alpha = 0.08f)
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, AmberAccent.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Payments,
                contentDescription = null,
                tint = NavyDark,
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "पुष्टि करें: ड्राइवर भुगतान",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = NavyDark
              )
            }

            Surface(
              color = AmberAccent.copy(alpha = 0.2f),
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = DateUtils.formatToHindiDisplayDate(payment.date),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Medium,
                color = NavyDark,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Surface(
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              HisabDetailRow("👤 ड्राइवर का नाम:", payment.driverName, NavyDark)
              HisabDetailRow("💵 भुगतान रकम:", "₹${FormatUtils.formatCurrency(payment.amount)}", KharchRed)
              HisabDetailRow("📋 भुगतान प्रकार:", payment.paymentType, AmberAccent)
              HisabDetailRow("💳 माध्यम:", payment.paymentMode, MaterialTheme.colorScheme.onSurface)
              if (payment.remarks.isNotBlank()) {
                HisabDetailRow("📝 विवरण:", payment.remarks, MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          when (action.status) {
            ActionCardStatus.PENDING -> {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                OutlinedButton(
                  onClick = onCancel,
                  modifier = Modifier
                    .weight(1f)
                    .testTag("cancel_payment_button"),
                  shape = RoundedCornerShape(10.dp)
                ) {
                  Icon(Icons.Default.Cancel, null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("रद्द करें", style = MaterialTheme.typography.labelSmall)
                }

                Button(
                  onClick = onConfirm,
                  colors = ButtonDefaults.buttonColors(containerColor = JamaGreen),
                  modifier = Modifier
                    .weight(1.4f)
                    .testTag("confirm_payment_button"),
                  shape = RoundedCornerShape(10.dp)
                ) {
                  Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(16.dp), tint = Color.White)
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("✓ कन्फर्म और सेव", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
              }
            }

            ActionCardStatus.CONFIRMED -> {
              Surface(
                color = JamaGreen.copy(alpha = 0.15f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier.padding(8.dp),
                  horizontalArrangement = Arrangement.Center,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(Icons.Default.CheckCircle, null, tint = JamaGreen, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("✓ ड्राइवर भुगतान Firebase में सेव हो गया", color = JamaGreen, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                }
              }
            }

            ActionCardStatus.CANCELLED -> {
              Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier.padding(8.dp),
                  horizontalArrangement = Arrangement.Center,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(Icons.Default.Cancel, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("रद्द किया गया", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                }
              }
            }
          }
        }
      }
    }

    is ProposedAction.AddNewTruck -> {
      val truck = action.truck
      Card(
        colors = CardDefaults.cardColors(containerColor = AmberAccent.copy(alpha = 0.08f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, AmberAccent.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.AllInclusive, null, tint = NavyDark, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("पुष्टि करें: नया ट्रक जोड़ें", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = NavyDark)
            }
          }
          Spacer(modifier = Modifier.height(10.dp))
          Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(10.dp)) {
              HisabDetailRow("गाड़ी नंबर:", truck.truckNumber, NavyDark)
              HisabDetailRow("नाम / मॉडल:", "${truck.truckName} (${truck.truckModel})", AmberAccent)
              if (truck.assignedDriverName.isNotBlank()) {
                HisabDetailRow("तय ड्राइवर:", truck.assignedDriverName, MaterialTheme.colorScheme.onSurface)
              }
              if (truck.notes.isNotBlank()) {
                HisabDetailRow("नोट / परमिट:", truck.notes, MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
          Spacer(modifier = Modifier.height(12.dp))
          when (action.status) {
            ActionCardStatus.PENDING -> {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) {
                  Icon(Icons.Default.Cancel, null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("रद्द करें", style = MaterialTheme.typography.labelSmall)
                }
                Button(onClick = onConfirm, colors = ButtonDefaults.buttonColors(containerColor = JamaGreen), modifier = Modifier.weight(1.4f), shape = RoundedCornerShape(10.dp)) {
                  Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(16.dp), tint = Color.White)
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("✓ कन्फर्म और जोड़ें", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
              }
            }
            ActionCardStatus.CONFIRMED -> {
              Surface(color = JamaGreen.copy(alpha = 0.15f), shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(8.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.CheckCircle, null, tint = JamaGreen, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("✓ नया ट्रक फ्लीट में सेव हो गया", color = JamaGreen, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                }
              }
            }
            ActionCardStatus.CANCELLED -> {
              Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(8.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Cancel, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("रद्द किया गया", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                }
              }
            }
          }
        }
      }
    }

    is ProposedAction.AddNewDriver -> {
      val driver = action.driver
      Card(
        colors = CardDefaults.cardColors(containerColor = AmberAccent.copy(alpha = 0.08f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, AmberAccent.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Person, null, tint = NavyDark, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("पुष्टि करें: नया ड्राइवर जोड़ें", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = NavyDark)
            }
          }
          Spacer(modifier = Modifier.height(10.dp))
          Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(10.dp)) {
              HisabDetailRow("ड्राइवर का नाम:", driver.name, NavyDark)
              if (driver.phone.isNotBlank()) HisabDetailRow("फोन नंबर:", driver.phone, MaterialTheme.colorScheme.onSurface)
              if (driver.assignedTruck.isNotBlank()) HisabDetailRow("आवंटित गाड़ी:", driver.assignedTruck, AmberAccent)
              if (driver.monthlySalary > 0) HisabDetailRow("तय मासिक वेतन:", "₹${FormatUtils.formatCurrency(driver.monthlySalary)}", KharchRed)
            }
          }
          Spacer(modifier = Modifier.height(12.dp))
          when (action.status) {
            ActionCardStatus.PENDING -> {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) {
                  Icon(Icons.Default.Cancel, null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("रद्द करें", style = MaterialTheme.typography.labelSmall)
                }
                Button(onClick = onConfirm, colors = ButtonDefaults.buttonColors(containerColor = JamaGreen), modifier = Modifier.weight(1.4f), shape = RoundedCornerShape(10.dp)) {
                  Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(16.dp), tint = Color.White)
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("✓ कन्फर्म और जोड़ें", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
              }
            }
            ActionCardStatus.CONFIRMED -> {
              Surface(color = JamaGreen.copy(alpha = 0.15f), shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(8.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.CheckCircle, null, tint = JamaGreen, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("✓ नया ड्राइवर सफलतापूर्वक जोड़ा गया", color = JamaGreen, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                }
              }
            }
            ActionCardStatus.CANCELLED -> {
              Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(8.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Cancel, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("रद्द किया गया", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                }
              }
            }
          }
        }
      }
    }

    is ProposedAction.NavigateToScreen -> {
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AllInclusive, null, tint = NavyDark, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(action.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
              Text("स्क्रीन पर सीधे जाएं", style = MaterialTheme.typography.labelSmall)
            }
          }
          Button(onClick = onConfirm, colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary), shape = RoundedCornerShape(10.dp)) {
            Text("🚀 अभी खोलें", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    is ProposedAction.ShareSummarySlip -> {
      Card(
        colors = CardDefaults.cardColors(containerColor = AmberAccent.copy(alpha = 0.12f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text("खाता पर्ची: ${action.targetName}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text("WhatsApp या संदेश पर शेयर करें", style = MaterialTheme.typography.labelSmall)
          }
          Button(onClick = onConfirm, colors = ButtonDefaults.buttonColors(containerColor = JamaGreen), shape = RoundedCornerShape(10.dp)) {
            Text("📤 शेयर करें", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
private fun HisabDetailRow(label: String, value: String, color: Color) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Text(
      text = value,
      style = MaterialTheme.typography.bodySmall,
      fontWeight = FontWeight.Bold,
      color = color
    )
  }
}
