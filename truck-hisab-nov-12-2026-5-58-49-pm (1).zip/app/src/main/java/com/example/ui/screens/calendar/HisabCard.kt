package com.example.ui.screens.calendar

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.HisabEntry
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.BorderLight
import com.example.ui.theme.JamaGreen
import com.example.ui.theme.JamaGreenBg
import com.example.ui.theme.KharchRed
import com.example.ui.theme.KharchRedBg
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SalaryPurple
import com.example.util.FormatUtils

@Composable
fun HisabCard(
  entry: HisabEntry,
  businessName: String,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var expandedBreakdown by remember { mutableStateOf(false) }
  var showDeleteConfirm by remember { mutableStateOf(false) }

  val hasBreakdown = entry.dieselExpense > 0 || entry.tollExpense > 0 ||
    entry.repairExpense > 0 || entry.foodExpense > 0 || entry.otherExpense > 0

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("hisab_entry_card_${entry.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      // Driver Name, Truck Number, and Quick Action Buttons
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f)
        ) {
          Box(
            modifier = Modifier
              .size(42.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Person,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.size(24.dp)
            )
          }

          Spacer(modifier = Modifier.width(10.dp))

          Column {
            Text(
              text = entry.driverName,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )

            // Truck Number Badge
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Icon(
                imageVector = Icons.Default.AllInclusive,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(13.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = entry.truckNumber,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
            }
          }
        }

        // Action Icons (WhatsApp Share, Edit, Delete)
        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
          IconButton(
            onClick = { FormatUtils.shareHisabSlip(context, entry, businessName) },
            modifier = Modifier
              .size(36.dp)
              .testTag("share_hisab_button_${entry.id}")
          ) {
            Icon(
              imageVector = Icons.Default.Share,
              contentDescription = "पर्ची शेयर करें",
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(20.dp)
            )
          }

          IconButton(
            onClick = onEdit,
            modifier = Modifier
              .size(36.dp)
              .testTag("edit_hisab_button_${entry.id}")
          ) {
            Icon(
              imageVector = Icons.Default.Edit,
              contentDescription = "संपादित करें",
              tint = MaterialTheme.colorScheme.secondary,
              modifier = Modifier.size(20.dp)
            )
          }

          IconButton(
            onClick = { showDeleteConfirm = true },
            modifier = Modifier
              .size(36.dp)
              .testTag("delete_hisab_button_${entry.id}")
          ) {
            Icon(
              imageVector = Icons.Default.Delete,
              contentDescription = "हटाएं",
              tint = KharchRed,
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }

      if (entry.notes.isNotBlank()) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "📍 ${entry.notes}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      Spacer(modifier = Modifier.height(12.dp))
      Divider(color = BorderLight, thickness = 0.8.dp)
      Spacer(modifier = Modifier.height(12.dp))

      // 4-Column Accounting Matrix: वेतन | खर्च | जमा | बाकी रकम
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        // Salary
        Column(horizontalAlignment = Alignment.Start) {
          Text(
            text = "वेतन",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = FormatUtils.formatRupee(entry.salary),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = SalaryPurple
          )
        }

        // Expense
        Column(horizontalAlignment = Alignment.Start) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "खर्च",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (hasBreakdown) {
              Icon(
                imageVector = if (expandedBreakdown) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                  .size(16.dp)
                  .clickable { expandedBreakdown = !expandedBreakdown }
              )
            }
          }
          Text(
            text = FormatUtils.formatRupee(entry.expenseTotal),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = KharchRed
          )
        }

        // Deposit / Jama
        Column(horizontalAlignment = Alignment.Start) {
          Text(
            text = "जमा (भाड़ा)",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = FormatUtils.formatRupee(entry.deposit),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = JamaGreen
          )
        }

        // Balance (बाकी रकम)
        Column(horizontalAlignment = Alignment.End) {
          Text(
            text = "बाकी रकम",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = FormatUtils.formatRupee(entry.balance),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = if (entry.balance >= 0) JamaGreen else KharchRed
          )
        }
      }

      // Expandable detailed breakdown of expenses
      AnimatedVisibility(visible = expandedBreakdown && hasBreakdown) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(10.dp)
        ) {
          Text(
            text = "खर्च विवरण:",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
          Spacer(modifier = Modifier.height(4.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            if (entry.dieselExpense > 0) {
              Text(
                text = "डीजल: ${FormatUtils.formatRupee(entry.dieselExpense)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            if (entry.tollExpense > 0) {
              Text(
                text = "टोल: ${FormatUtils.formatRupee(entry.tollExpense)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            if (entry.foodExpense > 0) {
              Text(
                text = "खाना: ${FormatUtils.formatRupee(entry.foodExpense)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            if (entry.repairExpense > 0) {
              Text(
                text = "मरम्मत: ${FormatUtils.formatRupee(entry.repairExpense)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            if (entry.otherExpense > 0) {
              Text(
                text = "अन्य: ${FormatUtils.formatRupee(entry.otherExpense)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }
    }
  }

  // Delete Confirmation Dialog
  if (showDeleteConfirm) {
    AlertDialog(
      onDismissRequest = { showDeleteConfirm = false },
      title = { Text("हिसाब हटाएं?") },
      text = { Text("${entry.driverName} का यह हिसाब रिकॉर्ड हटाना चाहते हैं?") },
      confirmButton = {
        Button(
          onClick = {
            showDeleteConfirm = false
            onDelete()
          },
          colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = KharchRed)
        ) {
          Text("हटाएं", color = Color.White)
        }
      },
      dismissButton = {
        TextButton(onClick = { showDeleteConfirm = false }) {
          Text("रद्द करें")
        }
      }
    )
  }
}
