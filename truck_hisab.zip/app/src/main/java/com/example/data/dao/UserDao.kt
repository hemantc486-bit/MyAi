package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.UserAccount

@Dao
interface UserDao {
  @Query("SELECT * FROM user_accounts WHERE mobile = :mobile LIMIT 1")
  suspend fun getUserByMobile(mobile: String): UserAccount?

  @Query("SELECT * FROM user_accounts LIMIT 1")
  suspend fun getFirstUser(): UserAccount?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertUser(user: UserAccount)

  @Update
  suspend fun updateUser(user: UserAccount)
}
