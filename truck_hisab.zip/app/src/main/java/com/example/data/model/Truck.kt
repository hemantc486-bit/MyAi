package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trucks")
data class Truck(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val truckNumber: String, // e.g. "RJ 14 GA 5521"
  val truckName: String, // e.g. "भारतबेंज 16 चक्का"
  val truckModel: String = "", // e.g. "16-Wheeler", "कंटेनर", "ट्रॉला"
  val assignedDriverName: String = "", // Assigned driver's name
  val notes: String = "", // Permit, insurance, or route info
  val createdAt: Long = System.currentTimeMillis()
)
