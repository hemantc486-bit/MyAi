package com.example.ui.screens.auth

import android.app.Activity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.Divider
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.KharchRed
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyLight
import com.example.ui.theme.NavyPrimary
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun LoginScreen(
  viewModel: AuthViewModel,
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsState()
  var passwordVisible by remember { mutableStateOf(false) }
  val focusManager = LocalFocusManager.current

  Surface(
    modifier = modifier.fillMaxSize(),
    color = MaterialTheme.colorScheme.background
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .imePadding()
    ) {
      // Top header gradient background
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(260.dp)
          .background(NavyPrimary)
      )

      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Spacer(modifier = Modifier.height(20.dp))

        // App Logo / Badge
        Box(
          modifier = Modifier
            .size(80.dp)
            .clip(CircleShape)
            .background(AmberAccent),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.AllInclusive,
            contentDescription = "Infinity Logo",
            tint = Color.White,
            modifier = Modifier.size(48.dp)
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = "MySmart Dairy",
          style = MaterialTheme.typography.headlineMedium,
          color = Color.White,
          fontWeight = FontWeight.Bold
        )

        Text(
          text = "ड्राइवर, खर्च, जमा और दैनिक खाता बही",
          style = MaterialTheme.typography.bodyMedium,
          color = Color.White.copy(alpha = 0.85f),
          textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(28.dp))

        // Main Login / Register Card
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("auth_card"),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            // Mode Header
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = if (uiState.isRegisterMode) "नया खाता बनाएं (Register)" else "लॉगिन करें (Login)",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Error Message Banner
            AnimatedVisibility(visible = uiState.errorMessage != null) {
              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(bottom = 12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEE2E2)),
                shape = RoundedCornerShape(10.dp)
              ) {
                Text(
                  text = uiState.errorMessage ?: "",
                  color = KharchRed,
                  style = MaterialTheme.typography.bodySmall,
                  modifier = Modifier.padding(12.dp),
                  fontWeight = FontWeight.Medium
                )
              }
            }

            val context = LocalContext.current
            val activity = context as? Activity

            // Google Sign-In Button (Firebase Authentication)
            Button(
              onClick = {
                if (activity != null) {
                  viewModel.signInWithGoogle(activity)
                }
              },
              modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("google_sign_in_button"),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                contentColor = MaterialTheme.colorScheme.onSurface
              ),
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
              Icon(
                imageVector = Icons.Default.AccountCircle,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp)
              )
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = "Google से साइन इन करें (Firebase Cloud Sync)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
              )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Divider(modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
              Text(
                text = "  या मोबाइल से हिसाब रखें  ",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Divider(modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Register-specific fields
            if (uiState.isRegisterMode) {
              OutlinedTextField(
                value = uiState.ownerName,
                onValueChange = { viewModel.onOwnerNameChange(it) },
                label = { Text("आपका नाम (Owner Name)") },
                placeholder = { Text("जैसे: राजेश शर्मा") },
                leadingIcon = {
                  Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("owner_name_input"),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = FocusDirection.Down.let { ImeAction.Next })
              )

              Spacer(modifier = Modifier.height(12.dp))

              OutlinedTextField(
                value = uiState.businessName,
                onValueChange = { viewModel.onBusinessNameChange(it) },
                label = { Text("ट्रांसपोर्ट का नाम (Business Name)") },
                placeholder = { Text("जैसे: श्री श्याम रोडलाइंस") },
                leadingIcon = {
                  Icon(Icons.Default.Business, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("business_name_input"),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
              )

              Spacer(modifier = Modifier.height(12.dp))

              OutlinedTextField(
                value = uiState.primaryTruck,
                onValueChange = { viewModel.onPrimaryTruckChange(it) },
                label = { Text("मुख्य ट्रक नंबर (Optional)") },
                placeholder = { Text("जैसे: RJ 14 GA 5521") },
                leadingIcon = {
                  Icon(Icons.Default.AllInclusive, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("primary_truck_input"),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
              )

              Spacer(modifier = Modifier.height(12.dp))
            }

            // Mobile Number Input (Required in both)
            OutlinedTextField(
              value = uiState.mobile,
              onValueChange = { if (it.length <= 10) viewModel.onMobileChange(it) },
              label = { Text("मोबाइल नंबर (Mobile Number)") },
              placeholder = { Text("10 अंकों का नंबर दर्ज करें") },
              leadingIcon = {
                Icon(Icons.Default.Phone, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
              },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("mobile_input"),
              singleLine = true,
              keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Phone,
                imeAction = ImeAction.Next
              )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Password Input
            OutlinedTextField(
              value = uiState.password,
              onValueChange = { viewModel.onPasswordChange(it) },
              label = { Text("पासवर्ड (Password)") },
              placeholder = { Text("पासवर्ड दर्ज करें") },
              leadingIcon = {
                Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
              },
              trailingIcon = {
                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                  Icon(
                    imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                    contentDescription = if (passwordVisible) "पासवर्ड छुपाएं" else "पासवर्ड देखें"
                  )
                }
              },
              visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("password_input"),
              singleLine = true,
              keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Password,
                imeAction = ImeAction.Done
              ),
              keyboardActions = KeyboardActions(
                onDone = {
                  focusManager.clearFocus()
                  if (uiState.isRegisterMode) viewModel.register() else viewModel.login()
                }
              )
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Primary Action Button (Login or Register)
            Button(
              onClick = {
                focusManager.clearFocus()
                if (uiState.isRegisterMode) viewModel.register() else viewModel.login()
              },
              modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("login_button"),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
              enabled = !uiState.isLoading
            ) {
              if (uiState.isLoading) {
                CircularProgressIndicator(
                  modifier = Modifier.size(24.dp),
                  color = Color.White,
                  strokeWidth = 2.5.dp
                )
              } else {
                Text(
                  text = if (uiState.isRegisterMode) "खाता बनाएं और शुरू करें" else "लॉगिन करें (Login)",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Toggle Between Login & Register
            TextButton(
              onClick = { viewModel.toggleMode() },
              modifier = Modifier.testTag("toggle_auth_mode_button")
            ) {
              Text(
                text = if (uiState.isRegisterMode)
                  "पहले से खाता है? लॉगिन करें"
                else
                  "नया खाता बनाएं (Create Account)",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.secondary
              )
            }

            // Quick Demo Login Chip
            if (!uiState.isRegisterMode) {
              Spacer(modifier = Modifier.height(8.dp))
              OutlinedButton(
                onClick = {
                  viewModel.fillDemoCredentials()
                  viewModel.login()
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("demo_login_button"),
                shape = RoundedCornerShape(10.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.DirectionsTransit,
                  contentDescription = null,
                  tint = AmberAccent,
                  modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "डेमो अकाउंट से सीधा लॉगिन करें",
                  style = MaterialTheme.typography.bodySmall,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Bottom footer note
        Text(
          text = "सुरक्षित एवं ऑफलाइन • आपका पर्सनल ट्रक हिसाब खाता",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }
}
