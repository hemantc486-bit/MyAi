package com.example.ui.screens.report

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Toll
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.BorderLight
import com.example.ui.theme.JamaGreen
import com.example.ui.theme.JamaGreenBg
import com.example.ui.theme.KharchRed
import com.example.ui.theme.KharchRedBg
import com.example.ui.theme.SalaryPurple
import com.example.ui.viewmodel.HisabViewModel
import com.example.util.DateUtils
import com.example.util.FormatUtils

@Composable
fun MonthlyReportScreen(
  viewModel: HisabViewModel,
  businessName: String,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val year by viewModel.selectedYear.collectAsState()
  val month by viewModel.selectedMonth.collectAsState()
  val summary by viewModel.monthSummary.collectAsState()

  val totalExpense = if (summary.totalExpense > 0) summary.totalExpense else 1.0

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("monthly_report_screen"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Month Header
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(onClick = { viewModel.previousMonth() }) {
            Icon(Icons.Default.ChevronLeft, contentDescription = "पिछला", tint = MaterialTheme.colorScheme.primary)
          }

          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = "मासिक हिसाब रिपोर्ट",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary
            )
            Text(
              text = "${DateUtils.getHindiMonthName(month)} $year",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.secondary,
              fontWeight = FontWeight.SemiBold
            )
          }

          IconButton(onClick = { viewModel.nextMonth() }) {
            Icon(Icons.Default.ChevronRight, contentDescription = "अगला", tint = MaterialTheme.colorScheme.primary)
          }
        }
      }
    }

    // 2. High-level Overview Cards
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Total Jama Card
        Card(
          modifier = Modifier.weight(1f),
          colors = CardDefaults.cardColors(containerColor = JamaGreenBg),
          shape = RoundedCornerShape(14.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Icon(Icons.Default.TrendingUp, contentDescription = null, tint = JamaGreen, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text("कुल जमा / भाड़ा", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(FormatUtils.formatRupee(summary.totalDeposit), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JamaGreen)
          }
        }

        // Total Kharch Card
        Card(
          modifier = Modifier.weight(1f),
          colors = CardDefaults.cardColors(containerColor = KharchRedBg),
          shape = RoundedCornerShape(14.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Icon(Icons.Default.TrendingDown, contentDescription = null, tint = KharchRed, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text("कुल खर्च", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(FormatUtils.formatRupee(summary.totalExpense), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = KharchRed)
          }
        }
      }
    }

    // 3. Net Fleet Balance Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "शुद्ध बचत / बाकी बैलेंस",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = if (summary.netBalance >= 0) "कुल लाभ / जमा स्थिति" else "देय बाकी रकम",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Text(
              text = FormatUtils.formatRupee(summary.netBalance),
              style = MaterialTheme.typography.headlineSmall,
              fontWeight = FontWeight.Bold,
              color = if (summary.netBalance >= 0) JamaGreen else KharchRed
            )
          }

          Spacer(modifier = Modifier.height(12.dp))
          Divider(color = BorderLight)
          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("ड्राइवर वेतन (वेतन मद):", style = MaterialTheme.typography.bodySmall)
            Text(FormatUtils.formatRupee(summary.totalSalary), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = SalaryPurple)
          }

          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("कुल ट्रिप / प्रविष्टियां:", style = MaterialTheme.typography.bodySmall)
            Text("${summary.entryCount} रिकॉर्ड", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // 4. Expense Categories Breakdown
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "मदवार खर्च का विवरण (Expense Breakdown)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Diesel
          ExpenseCategoryRow(
            name = "डीजल (Fuel)",
            amount = summary.totalDiesel,
            total = totalExpense,
            color = AmberAccent,
            icon = Icons.Default.LocalGasStation
          )

          Spacer(modifier = Modifier.height(12.dp))

          // Toll
          ExpenseCategoryRow(
            name = "टोल / Fastag",
            amount = summary.totalToll,
            total = totalExpense,
            color = Color(0xFF0284C7),
            icon = Icons.Default.Toll
          )

          Spacer(modifier = Modifier.height(12.dp))

          // Maintenance
          ExpenseCategoryRow(
            name = "मरम्मत / टायर",
            amount = summary.totalRepair,
            total = totalExpense,
            color = Color(0xFFE11D48),
            icon = Icons.Default.Warning
          )

          Spacer(modifier = Modifier.height(12.dp))

          // Food
          ExpenseCategoryRow(
            name = "खाना / दैनिक भत्ता",
            amount = summary.totalFood,
            total = totalExpense,
            color = Color(0xFF10B981),
            icon = Icons.Default.Restaurant
          )

          Spacer(modifier = Modifier.height(12.dp))

          // Other
          ExpenseCategoryRow(
            name = "अन्य / चालान",
            amount = summary.totalOther,
            total = totalExpense,
            color = Color(0xFF8B5CF6),
            icon = Icons.Default.Payments
          )
        }
      }
    }

    // 5. Share Report Button
    item {
      Button(
        onClick = {
          val monthName = DateUtils.getHindiMonthName(month)
          val sb = StringBuilder()
          sb.appendLine("📊 *मासिक ट्रक हिसाब रिपोर्ट*")
          sb.appendLine("🏢 *$businessName*")
          sb.appendLine("📅 महीना: $monthName $year")
          sb.appendLine("━━━━━━━━━━━━━━━━━━━")
          sb.appendLine("🟢 कुल जमा / भाड़ा: ${FormatUtils.formatRupee(summary.totalDeposit)}")
          sb.appendLine("🔴 कुल खर्च: ${FormatUtils.formatRupee(summary.totalExpense)}")
          sb.appendLine("  ⛽ डीजल खर्च: ${FormatUtils.formatRupee(summary.totalDiesel)}")
          sb.appendLine("  🛣️ टोल खर्च: ${FormatUtils.formatRupee(summary.totalToll)}")
          sb.appendLine("  🔧 मरम्मत खर्च: ${FormatUtils.formatRupee(summary.totalRepair)}")
          sb.appendLine("  🍲 खाना/भत्ता: ${FormatUtils.formatRupee(summary.totalFood)}")
          sb.appendLine("  📝 अन्य खर्च: ${FormatUtils.formatRupee(summary.totalOther)}")
          sb.appendLine("💵 कुल चालक वेतन: ${FormatUtils.formatRupee(summary.totalSalary)}")
          sb.appendLine("━━━━━━━━━━━━━━━━━━━")
          val label = if (summary.netBalance >= 0) "शुद्ध बचत" else "कुल बाकी देय"
          sb.appendLine("⚖️ *नेट बैलेंस ($label):* ${FormatUtils.formatRupee(summary.netBalance)}")
          sb.appendLine("━━━━━━━━━━━━━━━━━━━")
          sb.appendLine("📱 *MySmart Dairy App*")

          val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, sb.toString())
            type = "text/plain"
          }
          val shareIntent = Intent.createChooser(sendIntent, "मासिक रिपोर्ट शेयर करें")
          context.startActivity(shareIntent)
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .testTag("share_monthly_report_button"),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
      ) {
        Icon(Icons.Default.Share, contentDescription = null, tint = Color.White)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "मासिक रिपोर्ट व्हाट्सएप पर भेजें",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = Color.White
        )
      }
    }

    item {
      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}

@Composable
fun ExpenseCategoryRow(
  name: String,
  amount: Double,
  total: Double,
  color: Color,
  icon: ImageVector
) {
  val fraction = (amount / total).coerceIn(0.0, 1.0).toFloat()
  val percent = (fraction * 100).toInt()

  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(color.copy(alpha = 0.15f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
      }

      Text(
        text = "${FormatUtils.formatRupee(amount)} ($percent%)",
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
    }

    Spacer(modifier = Modifier.height(6.dp))

    LinearProgressIndicator(
      progress = { fraction },
      modifier = Modifier
        .fillMaxWidth()
        .height(8.dp)
        .clip(RoundedCornerShape(4.dp)),
      color = color,
      trackColor = MaterialTheme.colorScheme.surfaceVariant
    )
  }
}
