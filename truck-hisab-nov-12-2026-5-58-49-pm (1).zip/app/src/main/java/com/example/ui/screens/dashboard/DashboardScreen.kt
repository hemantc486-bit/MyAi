package com.example.ui.screens.dashboard

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ai.AiAssistantViewModel
import com.example.data.model.UserAccount
import com.example.ui.screens.ai.AiAssistantScreen
import com.example.ui.screens.calendar.CalendarScreen
import com.example.ui.screens.dialogs.AddDriverDialog
import com.example.ui.screens.dialogs.AddEditHisabDialog
import com.example.ui.screens.dialogs.AddTruckDialog
import com.example.ui.screens.dialogs.RecordPaymentDialog
import com.example.ui.screens.dialogs.SearchRecordDialog
import com.example.ui.screens.driver.DriverLedgerScreen
import com.example.ui.screens.report.MonthlyReportScreen
import com.example.ui.screens.truck.TruckLedgerScreen
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.KharchRed
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.viewmodel.HisabViewModel

sealed class DashboardTab(val index: Int, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
  object Calendar : DashboardTab(0, "कैलेंडर", Icons.Default.CalendarMonth)
  object TruckLedger : DashboardTab(1, "गाड़ी खाता", Icons.Default.AllInclusive)
  object DriverLedger : DashboardTab(2, "ड्राइवर खाता", Icons.Default.Group)
  object AiAssistant : DashboardTab(3, "AI मुनीम", Icons.Default.AutoAwesome)
  object Report : DashboardTab(4, "मासिक रिपोर्ट", Icons.Default.BarChart)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
  user: UserAccount,
  hisabViewModel: HisabViewModel,
  aiAssistantViewModel: AiAssistantViewModel,
  onLogout: () -> Unit,
  modifier: Modifier = Modifier
) {
  var currentTabIndex by remember { mutableIntStateOf(DashboardTab.Calendar.index) }
  var showLogoutConfirm by remember { mutableStateOf(false) }

  val isAddEditHisabOpen by hisabViewModel.isAddEditHisabOpen.collectAsState()
  val editingEntry by hisabViewModel.editingEntry.collectAsState()
  val selectedDate by hisabViewModel.selectedDate.collectAsState()
  val allDrivers by hisabViewModel.allDrivers.collectAsState()
  val allTrucks by hisabViewModel.allTrucks.collectAsState()
  val isAddDriverOpen by hisabViewModel.isAddDriverOpen.collectAsState()
  val isAddTruckOpen by hisabViewModel.isAddTruckOpen.collectAsState()
  val isRecordPaymentOpen by hisabViewModel.isRecordPaymentOpen.collectAsState()
  val paymentTargetDriver by hisabViewModel.paymentTargetDriver.collectAsState()
  val editingPayment by hisabViewModel.editingPayment.collectAsState()
  val isSearchOpen by hisabViewModel.isSearchOpen.collectAsState()
  val searchQuery by hisabViewModel.searchQuery.collectAsState()
  val searchResults by hisabViewModel.searchResults.collectAsState()
  val currentYear by hisabViewModel.selectedYear.collectAsState()
  val currentMonth by hisabViewModel.selectedMonth.collectAsState()

  // Handle back button to return to calendar tab first
  BackHandler(enabled = currentTabIndex != DashboardTab.Calendar.index) {
    currentTabIndex = DashboardTab.Calendar.index
  }

  // Handle automated navigation requests from AI Assistant
  LaunchedEffect(Unit) {
    aiAssistantViewModel.navigationEvent.collect { req ->
      currentTabIndex = req.targetTab
      if (req.date != null) {
        hisabViewModel.selectDate(req.date)
      }
      if (req.truckFilter != null) {
        hisabViewModel.setTruckFilter(req.truckFilter)
      }
      if (req.driverFilterId != null) {
        hisabViewModel.setDriverFilter(req.driverFilterId)
      }
    }
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(AmberAccent),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.AllInclusive,
                contentDescription = "MySmart Dairy Infinity Logo",
                tint = Color.White,
                modifier = Modifier.size(22.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = user.businessName.ifBlank { "MySmart Dairy" },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              Text(
                text = "मालिक: ${user.ownerName} (${user.mobile})",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.8f)
              )
            }
          }
        },
        actions = {
          // AI Assistant Quick Top Action
          IconButton(
            onClick = { currentTabIndex = DashboardTab.AiAssistant.index },
            modifier = Modifier.testTag("topbar_ai_assistant_button")
          ) {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = "AI मुनीम खोलें",
              tint = if (currentTabIndex == DashboardTab.AiAssistant.index) AmberAccent else Color.White
            )
          }

          IconButton(
            onClick = { hisabViewModel.openSearch() },
            modifier = Modifier.testTag("topbar_search_button")
          ) {
            Icon(
              imageVector = Icons.Default.Search,
              contentDescription = "रिकॉर्ड खोजें",
              tint = Color.White
            )
          }

          IconButton(
            onClick = { showLogoutConfirm = true },
            modifier = Modifier.testTag("logout_button")
          ) {
            Icon(
              imageVector = Icons.Default.ExitToApp,
              contentDescription = "लॉगआउट",
              tint = Color.White
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = NavyPrimary
        )
      )
    },
    floatingActionButton = {
      // Floating AI Action Button shown on non-AI tabs for 1-tap access
      if (currentTabIndex != DashboardTab.AiAssistant.index) {
        ExtendedFloatingActionButton(
          onClick = { currentTabIndex = DashboardTab.AiAssistant.index },
          containerColor = AmberAccent,
          contentColor = NavyDark,
          modifier = Modifier.testTag("fab_open_ai_assistant")
        ) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "AI मुनीम से बोलें",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelLarge
          )
        }
      }
    },
    bottomBar = {
      NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp
      ) {
        val tabs = listOf(
          DashboardTab.Calendar,
          DashboardTab.TruckLedger,
          DashboardTab.DriverLedger,
          DashboardTab.AiAssistant,
          DashboardTab.Report
        )
        tabs.forEach { tab ->
          val isSelected = currentTabIndex == tab.index
          NavigationBarItem(
            selected = isSelected,
            onClick = { currentTabIndex = tab.index },
            icon = {
              Icon(
                imageVector = tab.icon,
                contentDescription = tab.title,
                tint = if (isSelected) {
                  if (tab == DashboardTab.AiAssistant) AmberAccent else MaterialTheme.colorScheme.primary
                } else MaterialTheme.colorScheme.onSurfaceVariant
              )
            },
            label = {
              Text(
                text = tab.title,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              indicatorColor = AmberAccent.copy(alpha = 0.2f)
            ),
            modifier = Modifier.testTag("nav_tab_${tab.index}")
          )
        }
      }
    }
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
    ) {
      when (currentTabIndex) {
        DashboardTab.Calendar.index -> {
          CalendarScreen(
            viewModel = hisabViewModel,
            businessName = user.businessName.ifBlank { "MySmart Dairy" }
          )
        }
        DashboardTab.TruckLedger.index -> {
          TruckLedgerScreen(
            viewModel = hisabViewModel,
            businessName = user.businessName.ifBlank { "MySmart Dairy" }
          )
        }
        DashboardTab.DriverLedger.index -> {
          DriverLedgerScreen(
            viewModel = hisabViewModel,
            businessName = user.businessName.ifBlank { "MySmart Dairy" }
          )
        }
        DashboardTab.AiAssistant.index -> {
          AiAssistantScreen(
            viewModel = aiAssistantViewModel,
            businessName = user.businessName.ifBlank { "MySmart Dairy" }
          )
        }
        DashboardTab.Report.index -> {
          MonthlyReportScreen(
            viewModel = hisabViewModel,
            businessName = user.businessName.ifBlank { "MySmart Dairy" }
          )
        }
      }
    }
  }

  // Add / Edit Hisab Dialog
  if (isAddEditHisabOpen) {
    AddEditHisabDialog(
      initialDate = selectedDate,
      editingEntry = editingEntry,
      allDrivers = allDrivers,
      allTrucks = allTrucks,
      onDismiss = { hisabViewModel.closeAddEditHisab() },
      onSave = { entry -> hisabViewModel.saveHisab(entry) }
    )
  }

  // Add Driver Dialog
  if (isAddDriverOpen) {
    AddDriverDialog(
      onDismiss = { hisabViewModel.closeAddDriver() },
      onSave = { driver -> hisabViewModel.saveDriver(driver) }
    )
  }

  // Add Truck Dialog
  if (isAddTruckOpen) {
    AddTruckDialog(
      drivers = allDrivers,
      onDismiss = { hisabViewModel.closeAddTruck() },
      onSave = { truck -> hisabViewModel.saveTruck(truck) }
    )
  }

  // Record Payment / Advance Dialog
  if (isRecordPaymentOpen) {
    RecordPaymentDialog(
      drivers = allDrivers,
      initialDriver = paymentTargetDriver,
      initialPayment = editingPayment,
      onDismiss = { hisabViewModel.closeRecordPayment() },
      onSave = { payment -> hisabViewModel.saveDriverPayment(payment) }
    )
  }

  // Search Record Dialog
  if (isSearchOpen) {
    SearchRecordDialog(
      query = searchQuery,
      results = searchResults,
      currentYear = currentYear,
      currentMonth = currentMonth,
      allTrucks = allTrucks,
      onQueryChange = { hisabViewModel.onSearchQueryChange(it) },
      onSelectDate = { date -> hisabViewModel.jumpToSpecificDate(date) },
      onSelectMonthYear = { y, m -> hisabViewModel.setYearAndMonth(y, m) },
      onDismiss = { hisabViewModel.closeSearch() }
    )
  }

  // Logout Confirmation Dialog
  if (showLogoutConfirm) {
    AlertDialog(
      onDismissRequest = { showLogoutConfirm = false },
      title = { Text("लॉगआउट करें?") },
      text = { Text("क्या आप अपने खाते से लॉगआउट करना चाहते हैं?") },
      confirmButton = {
        Button(
          onClick = {
            showLogoutConfirm = false
            onLogout()
          },
          colors = ButtonDefaults.buttonColors(containerColor = KharchRed)
        ) {
          Text("लॉगआउट", color = Color.White)
        }
      },
      dismissButton = {
        TextButton(onClick = { showLogoutConfirm = false }) {
          Text("रद्द करें")
        }
      }
    )
  }
}
