package com.example.ui.screens.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Driver
import com.example.data.model.HisabEntry
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.BorderLight
import com.example.ui.theme.JamaGreen
import com.example.ui.theme.JamaGreenBg
import com.example.ui.theme.KharchRed
import com.example.ui.theme.KharchRedBg
import com.example.ui.theme.NavyLight
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SalaryPurple
import com.example.ui.viewmodel.HisabViewModel
import com.example.util.CalendarDay
import com.example.util.DateUtils
import com.example.util.FormatUtils

@Composable
fun CalendarScreen(
  viewModel: HisabViewModel,
  businessName: String,
  modifier: Modifier = Modifier
) {
  val year by viewModel.selectedYear.collectAsState()
  val month by viewModel.selectedMonth.collectAsState()
  val selectedDate by viewModel.selectedDate.collectAsState()
  val driverFilterId by viewModel.selectedDriverFilterId.collectAsState()
  val truckFilterNumber by viewModel.selectedTruckFilterNumber.collectAsState()
  val allDrivers by viewModel.allDrivers.collectAsState()
  val allTrucks by viewModel.allTrucks.collectAsState()
  val dateEntries by viewModel.selectedDateEntries.collectAsState()
  val monthSummary by viewModel.monthSummary.collectAsState()
  val monthDatesWithEntries by viewModel.monthDatesWithEntries.collectAsState()
  val isCloudSynced by viewModel.isCloudSynced.collectAsState()

  val calendarDays = remember(year, month) {
    DateUtils.generateMonthCalendarDays(year, month)
  }

  // Selected date financial calculations
  val dateTotalExpense = dateEntries.sumOf { it.expenseTotal }
  val dateTotalDeposit = dateEntries.sumOf { it.deposit }
  val dateTotalBalance = dateEntries.sumOf { it.balance }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("calendar_screen"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Month Navigation & Search Header
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          // Month Selector Row
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            IconButton(
              onClick = { viewModel.previousMonth() },
              modifier = Modifier
                .size(44.dp)
                .testTag("prev_month_button")
            ) {
              Icon(
                Icons.Default.ChevronLeft,
                contentDescription = "पिछला महीना",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp)
              )
            }

            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier.clickable { viewModel.openSearch() }
            ) {
              Text(
                text = "${DateUtils.getHindiMonthName(month)} $year",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "${monthSummary.entryCount} हिसाब • टैप करके महीना बदलें",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.secondary
                )
              }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(
                onClick = { viewModel.nextMonth() },
                modifier = Modifier
                  .size(44.dp)
                  .testTag("next_month_button")
              ) {
                Icon(
                  Icons.Default.ChevronRight,
                  contentDescription = "अगला महीना",
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(28.dp)
                )
              }

              IconButton(
                onClick = { viewModel.goToToday() },
                modifier = Modifier
                  .size(40.dp)
                  .testTag("today_button")
              ) {
                Icon(
                  Icons.Default.Today,
                  contentDescription = "आज",
                  tint = AmberAccent,
                  modifier = Modifier.size(24.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Search Past Dates / Records Button
          OutlinedButton(
            onClick = { viewModel.openSearch() },
            modifier = Modifier
              .fillMaxWidth()
              .height(44.dp)
              .testTag("open_search_button"),
            shape = RoundedCornerShape(10.dp)
          ) {
            Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "पुरानी तारीख या हिसाब खोजें (Search Past Records)",
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.primary
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Driver Filter Row
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            FilterChip(
              selected = driverFilterId == null,
              onClick = { viewModel.setDriverFilter(null) },
              label = { Text("सभी ड्राइवर") },
              modifier = Modifier.testTag("filter_all_drivers")
            )

            allDrivers.forEach { driver ->
              val isSelected = driverFilterId == driver.id
              FilterChip(
                selected = isSelected,
                onClick = { viewModel.setDriverFilter(driver.id) },
                label = { Text(driver.name) },
                leadingIcon = if (isSelected) {
                  { Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp)) }
                } else null,
                modifier = Modifier.testTag("filter_driver_${driver.id}")
              )
            }
          }

          // Truck Filter Row
          if (allTrucks.isNotEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              FilterChip(
                selected = truckFilterNumber == null,
                onClick = { viewModel.setTruckFilter(null) },
                label = { Text("सभी गाड़ियां") },
                modifier = Modifier.testTag("filter_all_trucks")
              )

              allTrucks.forEach { trk ->
                val isSelected = truckFilterNumber?.trim()?.equals(trk.truckNumber.trim(), ignoreCase = true) == true
                FilterChip(
                  selected = isSelected,
                  onClick = {
                    if (isSelected) viewModel.setTruckFilter(null) else viewModel.setTruckFilter(trk.truckNumber)
                  },
                  label = { Text(trk.truckNumber) },
                  leadingIcon = if (isSelected) {
                    { Icon(Icons.Default.AllInclusive, contentDescription = null, modifier = Modifier.size(16.dp)) }
                  } else null,
                  modifier = Modifier.testTag("filter_truck_${trk.id}")
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Month Financial Quick Stats
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .background(MaterialTheme.colorScheme.surfaceVariant)
              .padding(vertical = 10.dp, horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(horizontalAlignment = Alignment.Start) {
              Text("महीने का खर्च", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(FormatUtils.formatRupee(monthSummary.totalExpense), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = KharchRed)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("महीने की जमा", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(FormatUtils.formatRupee(monthSummary.totalDeposit), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = JamaGreen)
            }
            Column(horizontalAlignment = Alignment.End) {
              Text("कुल बाकी", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                FormatUtils.formatRupee(monthSummary.netBalance),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = if (monthSummary.netBalance >= 0) JamaGreen else KharchRed
              )
            }
          }

          // Firebase Cloud Backup indicator
          if (isCloudSynced) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center,
              modifier = Modifier.fillMaxWidth()
            ) {
              Icon(
                imageVector = Icons.Default.CloudDone,
                contentDescription = null,
                tint = JamaGreen,
                modifier = Modifier.size(15.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Firebase Cloud Firestore सिंक सक्रिय (डेटा क्लाउड में सुरक्षित है)",
                style = MaterialTheme.typography.labelSmall,
                color = JamaGreen,
                fontWeight = FontWeight.Medium
              )
            }
          }
        }
      }
    }

    // 2. Full Month Interactive Calendar Grid
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
        ) {
          // Weekday Headers (रवि red, बाकी slate)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
          ) {
            DateUtils.WEEKDAYS_HINDI.forEach { dayName ->
              Text(
                text = dayName,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (dayName == "रवि") KharchRed else MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 7-Column Day Cells Grid
          val weeks = calendarDays.chunked(7)
          weeks.forEach { weekDays ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp),
              horizontalArrangement = Arrangement.SpaceAround
            ) {
              weekDays.forEach { day ->
                val isSelected = day.dateString == selectedDate
                val entryCount = monthDatesWithEntries[day.dateString] ?: 0

                CalendarDayCell(
                  day = day,
                  isSelected = isSelected,
                  entryCount = entryCount,
                  onClick = {
                    if (!day.isCurrentMonth) {
                      viewModel.jumpToSpecificDate(day.dateString)
                    } else {
                      viewModel.selectDate(day.dateString)
                    }
                  },
                  modifier = Modifier.weight(1f)
                )
              }
            }
          }
        }
      }
    }

    // 3. Selected Date Section Header & Action Button
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "📅 ${DateUtils.formatToHindiDisplayDate(selectedDate)}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
              Text(
                text = if (dateEntries.isEmpty())
                  "इस दिन कोई हिसाब दर्ज नहीं है"
                else
                  "${dateEntries.size} प्रविष्टियां दर्ज हैं",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Button(
              onClick = { viewModel.openAddHisab(selectedDate) },
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.testTag("add_hisab_for_date_button")
            ) {
              Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "+ हिसाब लिखें",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
          }

          // If entries exist for this day, show that day's financial summary
          if (dateEntries.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = BorderLight)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = "आज का खर्च: ${FormatUtils.formatRupee(dateTotalExpense)}",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = KharchRed
              )
              Text(
                text = "आज की जमा: ${FormatUtils.formatRupee(dateTotalDeposit)}",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = JamaGreen
              )
              Text(
                text = "बाकी: ${FormatUtils.formatRupee(dateTotalBalance)}",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (dateTotalBalance >= 0) JamaGreen else KharchRed
              )
            }
          }
        }
      }
    }

    // 4. Entries for the Selected Date
    if (dateEntries.isEmpty()) {
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("empty_hisab_card"),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(
              imageVector = Icons.Default.DateRange,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.secondary,
              modifier = Modifier.size(44.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "इस तारीख का हिसाब खाली है",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "ऊपर '+ हिसाब लिखें' बटन दबाकर ड्राइवर का वेतन, खर्च और जमा दर्ज करें। हर प्रविष्टि सीधे Firebase में सुरक्षित रहेगी।",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              textAlign = TextAlign.Center
            )
          }
        }
      }
    } else {
      items(dateEntries, key = { it.id }) { entry ->
        HisabCard(
          entry = entry,
          businessName = businessName,
          onEdit = { viewModel.openEditHisab(entry) },
          onDelete = { viewModel.deleteHisab(entry.id) }
        )
      }
    }

    item {
      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}

@Composable
fun CalendarDayCell(
  day: CalendarDay,
  isSelected: Boolean,
  entryCount: Int,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val cellBg = when {
    isSelected -> MaterialTheme.colorScheme.primary
    day.isToday -> AmberAccent.copy(alpha = 0.15f)
    entryCount > 0 -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    else -> Color.Transparent
  }

  val textColor = when {
    isSelected -> Color.White
    !day.isCurrentMonth -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)
    day.isToday -> AmberAccent
    else -> MaterialTheme.colorScheme.onSurface
  }

  Box(
    modifier = modifier
      .padding(horizontal = 2.dp)
      .aspectRatio(1f)
      .clip(RoundedCornerShape(10.dp))
      .background(cellBg)
      .then(
        if (day.isToday && !isSelected)
          Modifier.border(1.2.dp, AmberAccent, RoundedCornerShape(10.dp))
        else Modifier
      )
      .clickable { onClick() }
      .testTag("calendar_day_${day.dateString}"),
    contentAlignment = Alignment.Center
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Text(
        text = "${day.dayNumber}",
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = if (isSelected || day.isToday || entryCount > 0) FontWeight.Bold else FontWeight.Normal,
        color = textColor
      )

      // Indicator for entries on this date
      if (entryCount > 0) {
        Row(
          horizontalArrangement = Arrangement.Center,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(6.dp)
              .clip(CircleShape)
              .background(if (isSelected) AmberAccent else JamaGreen)
          )
        }
      } else {
        Spacer(modifier = Modifier.height(6.dp))
      }
    }
  }
}
