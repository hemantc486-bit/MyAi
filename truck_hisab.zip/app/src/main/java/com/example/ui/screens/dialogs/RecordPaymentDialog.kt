package com.example.ui.screens.dialogs

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Driver
import com.example.data.model.DriverPayment
import com.example.ui.theme.JamaGreen
import com.example.ui.theme.SalaryPurple
import com.example.util.DateUtils

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun RecordPaymentDialog(
  drivers: List<Driver>,
  initialDriver: Driver? = null,
  initialPayment: DriverPayment? = null,
  onDismiss: () -> Unit,
  onSave: (DriverPayment) -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  var selectedDriver by remember {
    mutableStateOf(
      initialDriver
        ?: drivers.find { it.id == initialPayment?.driverId }
        ?: drivers.firstOrNull()
    )
  }
  var isDriverDropdownOpen by remember { mutableStateOf(false) }

  var date by remember {
    mutableStateOf(initialPayment?.date ?: DateUtils.getTodayDateString())
  }
  var amountText by remember {
    mutableStateOf(initialPayment?.let { if (it.amount > 0) it.amount.toInt().toString() else "" } ?: "")
  }

  val paymentTypes = listOf("एडवांस (Advance)", "वेतन भुगतान (Salary)", "बोनस (Bonus)", "अन्य (Other)")
  var selectedType by remember {
    mutableStateOf(initialPayment?.paymentType ?: paymentTypes[0])
  }

  val paymentModes = listOf("नकद (Cash)", "ऑनलाइन / UPI", "बैंक ट्रांसफर")
  var selectedMode by remember {
    mutableStateOf(initialPayment?.paymentMode ?: paymentModes[0])
  }

  var remarks by remember {
    mutableStateOf(initialPayment?.remarks ?: "")
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp)
        .padding(bottom = 32.dp)
        .verticalScroll(rememberScrollState())
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = if (initialPayment != null) "भुगतान सुधारें" else "एडवांस / वेतन भुगतान दर्ज करें",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
          Text(
            text = "ड्राइवर को दिया गया एडवांस या वेतन हिसाब में जोड़ें",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "बंद करें")
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Driver Selector
      Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
          value = selectedDriver?.let { "${it.name} (${it.assignedTruck})" } ?: "ड्राइवर चुनें",
          onValueChange = {},
          readOnly = true,
          label = { Text("ड्राइवर चुनें *") },
          leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
          trailingIcon = {
            if (initialDriver == null && drivers.size > 1) {
              Text(
                text = "बदलें ▼",
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(end = 8.dp)
              )
            }
          },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("payment_driver_selector")
            .clickable(enabled = initialDriver == null) {
              if (initialDriver == null) isDriverDropdownOpen = true
            }
        )

        if (initialDriver == null) {
          DropdownMenu(
            expanded = isDriverDropdownOpen,
            onDismissRequest = { isDriverDropdownOpen = false }
          ) {
            drivers.forEach { drv ->
              DropdownMenuItem(
                text = {
                  Column {
                    Text(drv.name, fontWeight = FontWeight.Bold)
                    Text("गाड़ी: ${drv.assignedTruck} • ${drv.phone}", style = MaterialTheme.typography.bodySmall)
                  }
                },
                onClick = {
                  selectedDriver = drv
                  isDriverDropdownOpen = false
                }
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Date & Amount in a 2-column row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = date,
          onValueChange = { date = it },
          label = { Text("तारीख (YYYY-MM-DD)") },
          leadingIcon = { Icon(Icons.Default.CalendarMonth, contentDescription = null) },
          modifier = Modifier
            .weight(1.1f)
            .testTag("payment_date_input"),
          singleLine = true
        )

        OutlinedTextField(
          value = amountText,
          onValueChange = { amountText = it },
          label = { Text("रकम (Amount) ₹ *") },
          placeholder = { Text("जैसे: 5000") },
          leadingIcon = { Icon(Icons.Default.CurrencyRupee, contentDescription = null, tint = SalaryPurple) },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier
            .weight(1f)
            .testTag("payment_amount_input"),
          singleLine = true
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Payment Type Selector
      Text(
        text = "भुगतान प्रकार (Payment Type):",
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.height(6.dp))
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        paymentTypes.forEach { type ->
          val isSelected = selectedType == type
          FilterChip(
            selected = isSelected,
            onClick = { selectedType = type },
            label = { Text(type, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
              selectedLabelColor = Color.White
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Payment Mode Selector
      Text(
        text = "भुगतान का माध्यम (Payment Mode):",
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.height(6.dp))
      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        paymentModes.forEach { mode ->
          val isSelected = selectedMode == mode
          FilterChip(
            selected = isSelected,
            onClick = { selectedMode = mode },
            label = { Text(mode, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
              selectedLabelColor = Color.White
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Remarks / Note
      OutlinedTextField(
        value = remarks,
        onValueChange = { remarks = it },
        label = { Text("विवरण / टिप्पणी (Remarks)") },
        placeholder = { Text("जैसे: घर खर्च एडवांस, रास्ते का डीजल एडवांस, वेतन") },
        leadingIcon = { Icon(Icons.Default.Notes, contentDescription = null) },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("payment_remarks_input"),
        singleLine = true
      )

      Spacer(modifier = Modifier.height(24.dp))

      // Action Buttons
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        OutlinedButton(
          onClick = onDismiss,
          modifier = Modifier
            .weight(1f)
            .height(50.dp),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text("रद्द करें")
        }

        val parsedAmount = amountText.toDoubleOrNull() ?: 0.0
        val isValid = selectedDriver != null && parsedAmount > 0.0 && date.isNotBlank()

        Button(
          onClick = {
            if (!isValid) return@Button
            val payment = DriverPayment(
              id = initialPayment?.id ?: 0L,
              driverId = selectedDriver!!.id,
              driverName = selectedDriver!!.name,
              date = date.trim(),
              amount = parsedAmount,
              paymentType = selectedType,
              paymentMode = selectedMode,
              remarks = remarks.trim()
            )
            onSave(payment)
          },
          enabled = isValid,
          modifier = Modifier
            .weight(1.5f)
            .height(50.dp)
            .testTag("save_payment_button"),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
          Icon(Icons.Default.Payments, contentDescription = null, tint = Color.White)
          Spacer(modifier = Modifier.width(6.dp))
          Text("भुगतान दर्ज करें", fontWeight = FontWeight.Bold, color = Color.White)
        }
      }
    }
  }
}
