package com.example.ui.screens.truck

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Toll
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.HisabEntry
import com.example.data.model.Truck
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.BorderLight
import com.example.ui.theme.JamaGreen
import com.example.ui.theme.JamaGreenBg
import com.example.ui.theme.KharchRed
import com.example.ui.theme.KharchRedBg
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SalaryPurple
import com.example.ui.viewmodel.FleetSummary
import com.example.ui.viewmodel.HisabViewModel
import com.example.ui.viewmodel.TruckLedgerSummary
import com.example.util.DateUtils
import com.example.util.FormatUtils

@Composable
fun TruckLedgerScreen(
  viewModel: HisabViewModel,
  businessName: String,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val truckSummaries by viewModel.truckSummaries.collectAsState()
  val fleetSummary by viewModel.fleetSummary.collectAsState()
  val allEntries by viewModel.allEntries.collectAsState()
  val detailTruck by viewModel.selectedTruckForDetail.collectAsState()

  var truckToDelete by remember { mutableStateOf<Truck?>(null) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("truck_ledger_screen"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Header & Add Truck Button
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "गाड़ी मैनेजमेंट (Truck Files)",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
          Text(
            text = "हर गाड़ी की अलग हिसाब फाइल, खर्च और नफा-नुकसान",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Button(
          onClick = { viewModel.openAddTruck() },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.testTag("add_truck_button")
        ) {
          Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("+ नया ट्रक", fontWeight = FontWeight.Bold, color = Color.White)
        }
      }
    }

    // 2. Fleet Overview Card
    item {
      FleetOverviewCard(fleetSummary = fleetSummary)
    }

    // 3. Empty State or Trucks List
    if (truckSummaries.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(
              imageVector = Icons.Default.AllInclusive,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.secondary,
              modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = "कोई गाड़ी पंजीकृत नहीं है",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "नई गाड़ी जोड़ने के लिए '+ नया ट्रक' बटन दबाएं।",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    } else {
      items(truckSummaries, key = { it.truck.id }) { summary ->
        TruckSummaryCard(
          summary = summary,
          onViewDetail = { viewModel.openTruckDetail(summary.truck) },
          onShare = {
            val truckEntries = allEntries.filter {
              it.truckNumber.trim().equals(summary.truck.truckNumber.trim(), ignoreCase = true)
            }
            FormatUtils.shareTruckSummary(context, summary.truck, truckEntries, businessName)
          },
          onDelete = { truckToDelete = summary.truck }
        )
      }
    }

    item {
      Spacer(modifier = Modifier.height(24.dp))
    }
  }

  // Truck Dedicated Ledger Detail BottomSheet / File
  detailTruck?.let { truck ->
    val truckEntries = allEntries.filter {
      it.truckNumber.trim().equals(truck.truckNumber.trim(), ignoreCase = true)
    }
    TruckDetailLedgerSheet(
      truck = truck,
      entries = truckEntries,
      businessName = businessName,
      onDismiss = { viewModel.closeTruckDetail() },
      onAddHisab = {
        viewModel.closeTruckDetail()
        viewModel.selectDate(DateUtils.getTodayDateString())
        viewModel.openAddHisab()
      },
      onEditEntry = { entry ->
        viewModel.closeTruckDetail()
        viewModel.openEditHisab(entry)
      },
      onDeleteEntry = { entryId ->
        viewModel.deleteHisab(entryId)
      }
    )
  }

  // Delete Truck Confirmation Dialog
  truckToDelete?.let { trk ->
    AlertDialog(
      onDismissRequest = { truckToDelete = null },
      title = { Text("गाड़ी हटाएं?") },
      text = { Text("क्या आप गाड़ी ${trk.truckNumber} (${trk.truckName}) को हटाना चाहते हैं?") },
      confirmButton = {
        Button(
          onClick = {
            viewModel.deleteTruck(trk)
            truckToDelete = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = KharchRed)
        ) {
          Text("हटाएं", color = Color.White)
        }
      },
      dismissButton = {
        TextButton(onClick = { truckToDelete = null }) {
          Text("रद्द करें")
        }
      }
    )
  }
}

@Composable
fun FleetOverviewCard(fleetSummary: FleetSummary) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = NavyDark),
    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(AmberAccent),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.AllInclusive, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text("कुल गाड़ियां: ${fleetSummary.totalTrucks}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White)
            Text("कुल ट्रिप: ${fleetSummary.totalTrips}", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.8f))
          }
        }

        // Net Profit/Loss Badge
        val isNetProfit = fleetSummary.netProfitLoss >= 0
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isNetProfit) JamaGreen else KharchRed)
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = if (isNetProfit) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = if (isNetProfit) "कुल मुनाफा" else "कुल घाटा",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))
      Divider(color = Color.White.copy(alpha = 0.15f), thickness = 0.8.dp)
      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text("कुल कमाई (Income)", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
          Text(FormatUtils.formatRupee(fleetSummary.totalFreightIncome), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JamaGreen)
        }
        Column {
          Text("कुल खर्च (Expense)", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
          Text(FormatUtils.formatRupee(fleetSummary.totalExpense), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = KharchRed)
        }
        Column(horizontalAlignment = Alignment.End) {
          Text("शुद्ध परिणाम", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
          Text(
            FormatUtils.formatRupee(Math.abs(fleetSummary.netProfitLoss)),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = if (fleetSummary.netProfitLoss >= 0) JamaGreen else KharchRed
          )
        }
      }
    }
  }
}

@Composable
fun TruckSummaryCard(
  summary: TruckLedgerSummary,
  onViewDetail: () -> Unit,
  onShare: () -> Unit,
  onDelete: () -> Unit
) {
  val truck = summary.truck

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("truck_card_${truck.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      // Truck Number & Truck Name
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(46.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.AllInclusive,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.size(26.dp)
            )
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column {
            Text(
              text = truck.truckNumber,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = truck.truckName + if (truck.truckModel.isNotBlank()) " • ${truck.truckModel}" else "",
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.secondary
            )
            if (truck.assignedDriverName.isNotBlank()) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(13.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                  text = "चालक: ${truck.assignedDriverName}",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }

        IconButton(
          onClick = onDelete,
          modifier = Modifier.size(34.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Delete,
            contentDescription = "हटाएं",
            tint = KharchRed.copy(alpha = 0.7f),
            modifier = Modifier.size(18.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))
      Divider(color = BorderLight, thickness = 0.8.dp)
      Spacer(modifier = Modifier.height(12.dp))

      // Financial Matrix (Income, Expense, Profit/Loss)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text("कुल कमाई (भाड़ा)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = FormatUtils.formatRupee(summary.totalFreightIncome),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = JamaGreen
          )
        }
        Column {
          Text("कुल खर्च", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = FormatUtils.formatRupee(summary.totalExpense),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = KharchRed
          )
        }
        Column(horizontalAlignment = Alignment.End) {
          Text("नफा / नुकसान (P&L)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = FormatUtils.formatRupee(Math.abs(summary.netProfitLoss)),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = if (summary.isProfit) JamaGreen else KharchRed
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Mini Expense Breakdown Chips
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        if (summary.dieselExpense > 0) {
          ExpenseMiniBadge("डीजल: ${FormatUtils.formatRupee(summary.dieselExpense)}")
        }
        if (summary.tollExpense > 0) {
          ExpenseMiniBadge("टोल: ${FormatUtils.formatRupee(summary.tollExpense)}")
        }
        if (summary.repairExpense > 0) {
          ExpenseMiniBadge("मरम्मत: ${FormatUtils.formatRupee(summary.repairExpense)}")
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Status Tag & Action Buttons Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Profit / Loss status badge
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (summary.isProfit) JamaGreenBg else KharchRedBg)
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text(
            text = if (summary.isProfit)
              "मुनाफा: +${FormatUtils.formatRupee(summary.netProfitLoss)}"
            else
              "घाटा: -${FormatUtils.formatRupee(Math.abs(summary.netProfitLoss))}",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = if (summary.isProfit) JamaGreen else KharchRed
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedButton(
            onClick = onShare,
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("शेयर", style = MaterialTheme.typography.labelSmall)
          }

          Button(
            onClick = onViewDetail,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
            modifier = Modifier.testTag("view_truck_file_${truck.id}")
          ) {
            Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
            Spacer(modifier = Modifier.width(4.dp))
            Text("खाता फाइल", style = MaterialTheme.typography.labelSmall, color = Color.White, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun ExpenseMiniBadge(text: String) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(4.dp))
      .background(MaterialTheme.colorScheme.surfaceVariant)
      .padding(horizontal = 6.dp, vertical = 2.dp)
  ) {
    Text(text, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TruckDetailLedgerSheet(
  truck: Truck,
  entries: List<HisabEntry>,
  businessName: String,
  onDismiss: () -> Unit,
  onAddHisab: () -> Unit,
  onEditEntry: (HisabEntry) -> Unit,
  onDeleteEntry: (Long) -> Unit
) {
  val context = LocalContext.current
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  val totalIncome = entries.sumOf { it.deposit }
  val totalDiesel = entries.sumOf { it.dieselExpense }
  val totalToll = entries.sumOf { it.tollExpense }
  val totalRepair = entries.sumOf { it.repairExpense }
  val totalSalary = entries.sumOf { it.salary }
  val totalFood = entries.sumOf { it.foodExpense }
  val totalOther = entries.sumOf { it.otherExpense }
  val totalExpense = entries.sumOf { it.expenseTotal + it.salary }
  val netProfitLoss = totalIncome - totalExpense
  val isProfit = netProfitLoss >= 0

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 18.dp)
        .padding(bottom = 36.dp)
    ) {
      // 1. Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "गाड़ी खाता: ${truck.truckNumber}",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
          Text(
            text = "${truck.truckName} ${if (truck.truckModel.isNotBlank()) "(${truck.truckModel})" else ""}${if (truck.assignedDriverName.isNotBlank()) " • चालक: ${truck.assignedDriverName}" else ""}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "बंद करें")
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // 2. Action Buttons
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Button(
          onClick = {
            FormatUtils.shareTruckSummary(context, truck, entries, businessName)
          },
          modifier = Modifier.weight(1.2f),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
        ) {
          Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
          Spacer(modifier = Modifier.width(6.dp))
          Text("व्हाट्सएप पर खाता शेयर करें", style = MaterialTheme.typography.labelSmall, color = Color.White, fontWeight = FontWeight.Bold)
        }

        OutlinedButton(
          onClick = onAddHisab,
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(10.dp),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
        ) {
          Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("+ हिसाब लिखें", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // 3. Profit & Loss Card
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(14.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("कुल ट्रिप संख्या:", style = MaterialTheme.typography.bodySmall)
            Text("${entries.size} ट्रिप", fontWeight = FontWeight.Bold)
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("कुल कमाई (भाड़ा जमा):", style = MaterialTheme.typography.bodySmall)
            Text(FormatUtils.formatRupee(totalIncome), fontWeight = FontWeight.Bold, color = JamaGreen)
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("कुल खर्च (Total Expense):", style = MaterialTheme.typography.bodySmall)
            Text(FormatUtils.formatRupee(totalExpense), fontWeight = FontWeight.Bold, color = KharchRed)
          }
          Spacer(modifier = Modifier.height(6.dp))
          Divider(color = BorderLight)
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("शुद्ध परिणाम (Profit / Loss):", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
              Text(
                text = if (isProfit) "शुद्ध मुनाफा" else "शुद्ध घाटा",
                style = MaterialTheme.typography.labelSmall,
                color = if (isProfit) JamaGreen else KharchRed
              )
            }
            Text(
              text = FormatUtils.formatRupee(Math.abs(netProfitLoss)),
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Bold,
              color = if (isProfit) JamaGreen else KharchRed
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // 4. Expense Breakdown Grid
      Text(
        text = "खर्चों का पूरा विवरण (Expense Breakdown):",
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.height(6.dp))
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          ExpenseRowItem(label = "⛽ डीजल खर्च (Diesel)", amount = totalDiesel)
          ExpenseRowItem(label = "🛣️ टोल / फ़ास्टैग (Toll)", amount = totalToll)
          ExpenseRowItem(label = "🔧 मरम्मत / मेंटेनेंस (Repair)", amount = totalRepair)
          ExpenseRowItem(label = "💵 ड्राइवर दैनिक वेतन (Driver Salary)", amount = totalSalary)
          ExpenseRowItem(label = "🍲 खोराकी / खाना (Food)", amount = totalFood)
          if (totalOther > 0) {
            ExpenseRowItem(label = "📝 अन्य खर्च (Other)", amount = totalOther)
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))
      Text("तारीखवार ट्रिप हिसाब सूची:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
      Spacer(modifier = Modifier.height(8.dp))

      // 5. Trip entries list
      if (entries.isEmpty()) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(160.dp),
          contentAlignment = Alignment.Center
        ) {
          Text("इस गाड़ी का कोई दैनिक हिसाब दर्ज नहीं है।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      } else {
        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .height(200.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          items(entries, key = { it.id }) { item ->
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
              elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = "${DateUtils.formatToHindiDisplayDate(item.date)} • ${item.driverName}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                  )
                  if (item.notes.isNotBlank()) {
                    Text(text = item.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                  Text(
                    text = "डीजल: ${FormatUtils.formatRupee(item.dieselExpense)} | टोल: ${FormatUtils.formatRupee(item.tollExpense)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }

                Column(horizontalAlignment = Alignment.End) {
                  Text(
                    text = "जमा: ${FormatUtils.formatRupee(item.deposit)}",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = JamaGreen
                  )
                  Text(
                    text = "खर्च: ${FormatUtils.formatRupee(item.expenseTotal)}",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = KharchRed
                  )
                }

                Spacer(modifier = Modifier.width(4.dp))
                IconButton(
                  onClick = { onDeleteEntry(item.id) },
                  modifier = Modifier.size(28.dp)
                ) {
                  Icon(Icons.Default.Delete, contentDescription = "हटाएं", tint = KharchRed.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun ExpenseRowItem(label: String, amount: Double) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
    Text(FormatUtils.formatRupee(amount), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
  }
}
