package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
  primary = NavyPrimary,
  onPrimary = SurfaceWhite,
  primaryContainer = NavyLight,
  onPrimaryContainer = SurfaceWhite,
  secondary = AmberAccent,
  onSecondary = SurfaceWhite,
  secondaryContainer = AmberLight,
  onSecondaryContainer = AmberDark,
  tertiary = JamaGreen,
  onTertiary = SurfaceWhite,
  background = BackgroundSlate,
  onBackground = TextPrimary,
  surface = SurfaceWhite,
  onSurface = TextPrimary,
  surfaceVariant = SurfaceVariantSlate,
  onSurfaceVariant = TextSecondary,
  outline = BorderLight
)

private val DarkColorScheme = darkColorScheme(
  primary = AmberAccent,
  onPrimary = NavyDark,
  primaryContainer = NavyLight,
  onPrimaryContainer = SurfaceWhite,
  secondary = AmberLight,
  onSecondary = NavyDark,
  tertiary = JamaGreen,
  onTertiary = SurfaceWhite,
  background = NavyDark,
  onBackground = SurfaceWhite,
  surface = Color(0xFF132238),
  onSurface = SurfaceWhite,
  surfaceVariant = Color(0xFF1E3A5F),
  onSurfaceVariant = Color(0xFFCBD5E1),
  outline = Color(0xFF334155)
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  val view = LocalView.current
  if (!view.isInEditMode) {
    SideEffect {
      val window = (view.context as? Activity)?.window
      if (window != null) {
        window.statusBarColor = colorScheme.primary.toArgb()
        WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = darkTheme
      }
    }
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
