package com.example

import com.example.util.DateUtils
import com.example.util.FormatUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class ExampleHisabLogicTest {

  @Test
  fun testBalanceCalculation() {
    val salary = 600.0
    val expense = 8500.0
    val deposit = 12000.0
    val balance = deposit - (salary + expense)
    assertEquals(2900.0, balance, 0.01)
  }

  @Test
  fun testHindiMonthName() {
    assertEquals("नवम्बर", DateUtils.getHindiMonthName(11))
    assertEquals("जनवरी", DateUtils.getHindiMonthName(1))
  }

  @Test
  fun testAllHindiMonthsList() {
    val months = DateUtils.getAllHindiMonths()
    assertEquals(12, months.size)
    assertEquals("जनवरी", months[0])
    assertEquals("दिसम्बर", months[11])
  }

  @Test
  fun testDateFormatting() {
    val display = DateUtils.formatToHindiDisplayDate("2026-11-04")
    assertEquals("4 नवम्बर 2026", display)
  }

  @Test
  fun testCurrencyFormatting() {
    val formatted = FormatUtils.formatRupee(2900.0)
    assertTrue(formatted.contains("2,900") || formatted.contains("2900"))
  }

  @Test
  fun testDriverNetBalanceCalculation() {
    // Driver trip calculations:
    // Deposit: ₹12,000, Expense: ₹8,500, Daily Salary: ₹600 -> Trip Cash Balance = +₹2,900
    val tripBalance = 12000.0 - (600.0 + 8500.0)
    assertEquals(2900.0, tripBalance, 0.01)

    // Advance given to driver: ₹5,000 (advance) + ₹2,000 (advance) = ₹7,000
    val totalAdvance = 5000.0 + 2000.0
    // Salary disbursed: ₹0
    val salaryDisbursed = 0.0

    // Final balance in driver's hands = ₹2,900 + ₹7,000 = ₹9,900
    val finalBalance = tripBalance + totalAdvance - salaryDisbursed
    assertEquals(9900.0, finalBalance, 0.01)
  }

  @Test
  fun testDriverPaymentTypes() {
    val payment = com.example.data.model.DriverPayment(
      driverId = 1L,
      driverName = "रमेश सिंह",
      date = "2026-11-04",
      amount = 5000.0,
      paymentType = "एडवांस (Advance)",
      paymentMode = "ऑनलाइन / UPI"
    )
    assertEquals("रमेश सिंह", payment.driverName)
    assertEquals(5000.0, payment.amount, 0.01)
    assertTrue(payment.paymentType.contains("Advance") || payment.paymentType.contains("एडवांस"))
  }

  @Test
  fun testTruckProfitLossCalculation() {
    // Freight deposit: ₹15,000
    val income = 15000.0
    // Expenses: Diesel ₹9,000 + Toll ₹1,500 + Repair ₹800 + Food ₹400 + Salary ₹700 = ₹12,400
    val diesel = 9000.0
    val toll = 1500.0
    val repair = 800.0
    val food = 400.0
    val salary = 700.0
    val totalExpense = diesel + toll + repair + food + salary
    assertEquals(12400.0, totalExpense, 0.01)

    // Net Profit: ₹15,000 - ₹12,400 = +₹2,600 (Profit)
    val profitLoss = income - totalExpense
    assertEquals(2600.0, profitLoss, 0.01)
    assertTrue(profitLoss >= 0)
  }

  @Test
  fun testTruckEntity() {
    val truck = com.example.data.model.Truck(
      truckNumber = "RJ 14 GA 5521",
      truckName = "भारतबेंज 16 चक्का (ट्रॉला)",
      truckModel = "16 चक्का ट्रेलर",
      assignedDriverName = "रमेश सिंह"
    )
    assertEquals("RJ 14 GA 5521", truck.truckNumber)
    assertEquals("भारतबेंज 16 चक्का (ट्रॉला)", truck.truckName)
    assertEquals("रमेश सिंह", truck.assignedDriverName)
  }

  @Test
  fun testAiActionJsonParsing() {
    val sampleAiResponse = """
      जी भाईजी, मैंने गाड़ी RJ 14 GA 5521 के लिए ₹5,000 का डीजल खर्च तैयार कर दिया है।
      ```json
      {
        "action": "ADD_HISAB",
        "truckNumber": "RJ 14 GA 5521",
        "driverName": "राम सिंह",
        "date": "2026-11-06",
        "dieselExpense": 5000.0,
        "tollExpense": 500.0,
        "repairExpense": 0.0,
        "foodExpense": 0.0,
        "otherExpense": 0.0,
        "salary": 0.0,
        "deposit": 0.0,
        "notes": "डीजल और टोल खर्च"
      }
      ```
    """.trimIndent()

    val jsonRegex = Regex("```(?:json)?\\s*(\\{[\\s\\S]*?\\})\\s*```")
    val match = jsonRegex.find(sampleAiResponse)
    org.junit.Assert.assertNotNull(match)
    val jsonContent = match!!.groupValues[1]
    val jsonObj = org.json.JSONObject(jsonContent)
    assertEquals("ADD_HISAB", jsonObj.getString("action"))
    assertEquals("RJ 14 GA 5521", jsonObj.getString("truckNumber"))
    assertEquals(5000.0, jsonObj.getDouble("dieselExpense"), 0.01)
    assertEquals(500.0, jsonObj.getDouble("tollExpense"), 0.01)

    val cleanText = sampleAiResponse.replace(match.value, "").trim()
    assertTrue(cleanText.contains("जी भाईजी"))
    assertTrue(!cleanText.contains("```json"))
  }
}
