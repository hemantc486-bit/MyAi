package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.HisabEntry
import kotlinx.coroutines.flow.Flow

@Dao
interface HisabDao {
  @Query("SELECT * FROM hisab_entries ORDER BY date DESC, id DESC")
  fun getAllEntries(): Flow<List<HisabEntry>>

  @Query("SELECT * FROM hisab_entries WHERE date = :date ORDER BY id DESC")
  fun getEntriesForDate(date: String): Flow<List<HisabEntry>>

  @Query("SELECT * FROM hisab_entries WHERE driverId = :driverId ORDER BY date DESC, id DESC")
  fun getEntriesForDriver(driverId: Long): Flow<List<HisabEntry>>

  @Query("SELECT * FROM hisab_entries WHERE date LIKE :monthPrefix || '%' ORDER BY date ASC")
  fun getEntriesForMonth(monthPrefix: String): Flow<List<HisabEntry>>

  @Query("SELECT * FROM hisab_entries WHERE id = :id LIMIT 1")
  suspend fun getEntryById(id: Long): HisabEntry?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertEntry(entry: HisabEntry): Long

  @Update
  suspend fun updateEntry(entry: HisabEntry)

  @Delete
  suspend fun deleteEntry(entry: HisabEntry)

  @Query("DELETE FROM hisab_entries WHERE id = :id")
  suspend fun deleteEntryById(id: Long)

  @Query("SELECT COUNT(*) FROM hisab_entries")
  suspend fun getEntryCount(): Int
}
