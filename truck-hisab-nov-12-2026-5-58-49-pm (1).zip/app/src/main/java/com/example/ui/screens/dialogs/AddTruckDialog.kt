package com.example.ui.screens.dialogs

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Driver
import com.example.data.model.Truck

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddTruckDialog(
  drivers: List<Driver> = emptyList(),
  onDismiss: () -> Unit,
  onSave: (Truck) -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  var truckNumber by remember { mutableStateOf("") }
  var truckName by remember { mutableStateOf("") }
  var truckModel by remember { mutableStateOf("16 चक्का (ट्रॉला)") }
  var assignedDriverName by remember { mutableStateOf("") }
  var isDriverDropdownOpen by remember { mutableStateOf(false) }
  var notes by remember { mutableStateOf("") }

  val commonTypes = listOf(
    "16 चक्का (ट्रॉला)",
    "12 चक्का (सिग्ना)",
    "14 चक्का",
    "10 चक्का",
    "कंटेनर (32 फीट)",
    "ओपन बॉडी",
    "ट्रेलर",
    "कैंटर / पिकअप"
  )

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp)
        .padding(bottom = 36.dp)
        .verticalScroll(rememberScrollState())
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "नया ट्रक जोड़ें (Add New Truck)",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
          Text(
            text = "गाड़ी नंबर और नाम दर्ज कर अलग हिसाब फाइल बनाएं",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "बंद करें")
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Truck Number Input
      OutlinedTextField(
        value = truckNumber,
        onValueChange = { truckNumber = it.uppercase() },
        label = { Text("गाड़ी / ट्रक नंबर (Truck Number) *") },
        placeholder = { Text("जैसे: RJ 14 GA 5521 या DL 01 AB 1234") },
        leadingIcon = { Icon(Icons.Default.Tag, contentDescription = null) },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("truck_number_input"),
        singleLine = true
      )

      Spacer(modifier = Modifier.height(12.dp))

      // Truck Name Input
      OutlinedTextField(
        value = truckName,
        onValueChange = { truckName = it },
        label = { Text("ट्रक का नाम / पहचान (Truck Name) *") },
        placeholder = { Text("जैसे: भारतबेंज 16 चक्का, सिग्ना 407, नई गाड़ी") },
        leadingIcon = { Icon(Icons.Default.AllInclusive, contentDescription = null) },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("truck_name_input"),
        singleLine = true
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Truck Type / Model quick chips
      Text(
        text = "गाड़ी का प्रकार / बॉडी (Truck Type):",
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.height(6.dp))
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        commonTypes.forEach { type ->
          val isSelected = truckModel == type
          FilterChip(
            selected = isSelected,
            onClick = { truckModel = type },
            label = { Text(type, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
              selectedLabelColor = Color.White
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Assigned Driver (dropdown or text)
      Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
          value = assignedDriverName,
          onValueChange = { assignedDriverName = it },
          label = { Text("आवंटित ड्राइवर (Assigned Driver)") },
          placeholder = { Text("जैसे: रमेश सिंह (वैकल्पिक)") },
          leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
          trailingIcon = {
            if (drivers.isNotEmpty()) {
              Text(
                text = "ड्राइवर चुनें ▼",
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                  .clickable { isDriverDropdownOpen = true }
                  .padding(end = 8.dp)
              )
            }
          },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("truck_assigned_driver_input"),
          singleLine = true
        )

        if (drivers.isNotEmpty()) {
          DropdownMenu(
            expanded = isDriverDropdownOpen,
            onDismissRequest = { isDriverDropdownOpen = false }
          ) {
            drivers.forEach { drv ->
              DropdownMenuItem(
                text = {
                  Column {
                    Text(drv.name, fontWeight = FontWeight.Bold)
                    if (drv.phone.isNotBlank()) {
                      Text(drv.phone, style = MaterialTheme.typography.bodySmall)
                    }
                  }
                },
                onClick = {
                  assignedDriverName = drv.name
                  isDriverDropdownOpen = false
                }
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Notes / Route Info
      OutlinedTextField(
        value = notes,
        onValueChange = { notes = it },
        label = { Text("रूट / परमिट / टिप्पणी (Notes)") },
        placeholder = { Text("जैसे: नेशनल परमिट, दिल्ली-मुंबई रूट, फिटनेस 2027") },
        leadingIcon = { Icon(Icons.Default.Notes, contentDescription = null) },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("truck_notes_input"),
        singleLine = true
      )

      Spacer(modifier = Modifier.height(24.dp))

      // Buttons
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        OutlinedButton(
          onClick = onDismiss,
          modifier = Modifier
            .weight(1f)
            .height(50.dp),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text("रद्द करें")
        }

        val isValid = truckNumber.isNotBlank() && truckName.isNotBlank()

        Button(
          onClick = {
            if (!isValid) return@Button
            val truck = Truck(
              truckNumber = truckNumber.trim(),
              truckName = truckName.trim(),
              truckModel = truckModel.trim(),
              assignedDriverName = assignedDriverName.trim(),
              notes = notes.trim()
            )
            onSave(truck)
          },
          enabled = isValid,
          modifier = Modifier
            .weight(1.5f)
            .height(50.dp)
            .testTag("save_truck_button"),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
          Icon(Icons.Default.AllInclusive, contentDescription = null, tint = Color.White)
          Spacer(modifier = Modifier.width(6.dp))
          Text("ट्रक सेव करें", fontWeight = FontWeight.Bold, color = Color.White)
        }
      }
    }
  }
}
