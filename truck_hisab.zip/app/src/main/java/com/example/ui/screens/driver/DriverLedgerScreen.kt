package com.example.ui.screens.driver

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Driver
import com.example.data.model.DriverPayment
import com.example.data.model.HisabEntry
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.BorderLight
import com.example.ui.theme.JamaGreen
import com.example.ui.theme.JamaGreenBg
import com.example.ui.theme.KharchRed
import com.example.ui.theme.KharchRedBg
import com.example.ui.theme.SalaryPurple
import com.example.ui.theme.SalaryPurpleBg
import com.example.ui.viewmodel.DriverLedgerSummary
import com.example.ui.viewmodel.HisabViewModel
import com.example.util.DateUtils
import com.example.util.FormatUtils

@Composable
fun DriverLedgerScreen(
  viewModel: HisabViewModel,
  businessName: String,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val driverSummaries by viewModel.driverSummaries.collectAsState()
  val allEntries by viewModel.allEntries.collectAsState()
  val allPayments by viewModel.allPayments.collectAsState()
  val detailDriver by viewModel.driverForDetailLedger.collectAsState()

  var driverToDelete by remember { mutableStateOf<Driver?>(null) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("driver_ledger_screen"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Header & Add Driver Button
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "ड्राइवर मैनेजमेंट (Driver Files)",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
          Text(
            text = "प्रत्येक ड्राइवर का अलग हिसाब, वेतन और एडवांस रिकॉर्ड",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Button(
          onClick = { viewModel.openAddDriver() },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.testTag("add_driver_button")
        ) {
          Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("+ नया ड्राइवर", fontWeight = FontWeight.Bold, color = Color.White)
        }
      }
    }

    // 2. Empty State or Drivers List
    if (driverSummaries.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(
              imageVector = Icons.Default.Person,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.secondary,
              modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = "कोई ड्राइवर खाता नहीं मिला",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "नया ड्राइवर जोड़ने के लिए '+ नया ड्राइवर' बटन दबाएं।",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    } else {
      items(driverSummaries, key = { it.driver.id }) { summary ->
        DriverSummaryCard(
          summary = summary,
          onViewDetail = { viewModel.openDriverDetail(summary.driver) },
          onAddPayment = { viewModel.openRecordPayment(driver = summary.driver) },
          onShare = {
            val driverEntries = allEntries.filter { it.driverId == summary.driver.id }
            val driverPayments = allPayments.filter { it.driverId == summary.driver.id }
            FormatUtils.shareDriverSummary(context, summary.driver, driverEntries, driverPayments, businessName)
          },
          onDelete = { driverToDelete = summary.driver }
        )
      }
    }

    item {
      Spacer(modifier = Modifier.height(24.dp))
    }
  }

  // Driver Dedicated Ledger Detail BottomSheet / File
  detailDriver?.let { driver ->
    val driverEntries = allEntries.filter { it.driverId == driver.id }
    val driverPayments = allPayments.filter { it.driverId == driver.id }
    DriverDetailLedgerSheet(
      driver = driver,
      entries = driverEntries,
      payments = driverPayments,
      businessName = businessName,
      onDismiss = { viewModel.closeDriverDetail() },
      onAddPayment = { viewModel.openRecordPayment(driver = driver) },
      onAddHisab = {
        viewModel.closeDriverDetail()
        viewModel.selectDate(DateUtils.getTodayDateString())
        viewModel.openAddHisab()
      },
      onEditEntry = { entry ->
        viewModel.closeDriverDetail()
        viewModel.openEditHisab(entry)
      },
      onDeleteEntry = { entryId ->
        viewModel.deleteHisab(entryId)
      },
      onDeletePayment = { paymentId ->
        viewModel.deleteDriverPayment(paymentId)
      }
    )
  }

  // Delete Driver Confirmation Dialog
  driverToDelete?.let { drv ->
    AlertDialog(
      onDismissRequest = { driverToDelete = null },
      title = { Text("ड्राइवर खाता हटाएं?") },
      text = { Text("क्या आप ${drv.name} का संपूर्ण खाता हटाना चाहते हैं?") },
      confirmButton = {
        Button(
          onClick = {
            viewModel.deleteDriver(drv)
            driverToDelete = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = KharchRed)
        ) {
          Text("हटाएं", color = Color.White)
        }
      },
      dismissButton = {
        TextButton(onClick = { driverToDelete = null }) {
          Text("रद्द करें")
        }
      }
    )
  }
}

@Composable
fun DriverSummaryCard(
  summary: DriverLedgerSummary,
  onViewDetail: () -> Unit,
  onAddPayment: () -> Unit,
  onShare: () -> Unit,
  onDelete: () -> Unit
) {
  val driver = summary.driver

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("driver_card_${driver.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      // Driver Name, Phone, and Assigned Truck
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(46.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Person,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.size(26.dp)
            )
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column {
            Text(
              text = driver.name,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
              if (driver.assignedTruck.isNotBlank()) {
                Icon(
                  imageVector = Icons.Default.LocalShipping,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.secondary,
                  modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                  text = driver.assignedTruck,
                  style = MaterialTheme.typography.bodySmall,
                  fontWeight = FontWeight.SemiBold,
                  color = MaterialTheme.colorScheme.secondary
                )
              }
              if (driver.phone.isNotBlank()) {
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "• ${driver.phone}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
            if (driver.monthlySalary > 0) {
              Text(
                text = "मासिक वेतन: ${FormatUtils.formatRupee(driver.monthlySalary)}",
                style = MaterialTheme.typography.labelSmall,
                color = SalaryPurple,
                fontWeight = FontWeight.SemiBold
              )
            }
          }
        }

        // Delete button
        IconButton(
          onClick = onDelete,
          modifier = Modifier.size(34.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Delete,
            contentDescription = "हटाएं",
            tint = KharchRed.copy(alpha = 0.7f),
            modifier = Modifier.size(18.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))
      Divider(color = BorderLight, thickness = 0.8.dp)
      Spacer(modifier = Modifier.height(12.dp))

      // Financial Matrix
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text("एडवांस दिया", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = FormatUtils.formatRupee(summary.totalAdvancePaid),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = SalaryPurple
          )
        }
        Column {
          Text("कुल ट्रिप खर्च", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = FormatUtils.formatRupee(summary.totalExpense),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = KharchRed
          )
        }
        Column {
          Text("कुल जमा भाड़ा", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = FormatUtils.formatRupee(summary.totalDeposit),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = JamaGreen
          )
        }
        Column(horizontalAlignment = Alignment.End) {
          Text("बाकी रकम", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = FormatUtils.formatRupee(Math.abs(summary.netBalance)),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = if (summary.netBalance >= 0) JamaGreen else KharchRed
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Status Tag & Action Buttons Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Balance Status Badge
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (summary.netBalance >= 0) JamaGreenBg else KharchRedBg)
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text(
            text = if (summary.netBalance >= 0)
              "चालक के पास शेष: ${FormatUtils.formatRupee(summary.netBalance)}"
            else
              "मालिक से लेना बाकी: ${FormatUtils.formatRupee(Math.abs(summary.netBalance))}",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = if (summary.netBalance >= 0) JamaGreen else KharchRed
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          // Quick Advance Button
          OutlinedButton(
            onClick = onAddPayment,
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.testTag("quick_advance_btn_${driver.id}")
          ) {
            Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(14.dp), tint = SalaryPurple)
            Spacer(modifier = Modifier.width(4.dp))
            Text("+ एडवांस", style = MaterialTheme.typography.labelSmall, color = SalaryPurple, fontWeight = FontWeight.Bold)
          }

          // Open Driver File
          Button(
            onClick = onViewDetail,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
            modifier = Modifier.testTag("view_driver_statement_${driver.id}")
          ) {
            Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
            Spacer(modifier = Modifier.width(4.dp))
            Text("खाता फाइल", style = MaterialTheme.typography.labelSmall, color = Color.White, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DriverDetailLedgerSheet(
  driver: Driver,
  entries: List<HisabEntry>,
  payments: List<DriverPayment>,
  businessName: String,
  onDismiss: () -> Unit,
  onAddPayment: () -> Unit,
  onAddHisab: () -> Unit,
  onEditEntry: (HisabEntry) -> Unit,
  onDeleteEntry: (Long) -> Unit,
  onDeletePayment: (Long) -> Unit
) {
  val context = LocalContext.current
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  var selectedTab by remember { mutableIntStateOf(0) } // 0: Payments/Advance, 1: Trip Entries

  val totalSalaryAllowance = entries.sumOf { it.salary }
  val totalExpense = entries.sumOf { it.expenseTotal }
  val totalDeposit = entries.sumOf { it.deposit }
  val tripBalance = entries.sumOf { it.balance }

  val totalAdvances = payments.filter { it.paymentType.contains("एडवांस") || it.paymentType.contains("Advance") }.sumOf { it.amount }
  val totalSalaryDisbursed = payments.filter { it.paymentType.contains("वेतन") || it.paymentType.contains("Salary") }.sumOf { it.amount }
  val totalAllPayments = payments.sumOf { it.amount }

  val netBalance = tripBalance + totalAdvances - totalSalaryDisbursed

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 18.dp)
        .padding(bottom = 36.dp)
    ) {
      // 1. Header with Name & Actions
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "${driver.name} की खाता फाइल",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
          Text(
            text = "गाड़ी: ${driver.assignedTruck} • तय वेतन: ${FormatUtils.formatRupee(driver.monthlySalary)}/माह",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "बंद करें")
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Direct Call / WhatsApp Quick Bar
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        if (driver.phone.isNotBlank()) {
          OutlinedButton(
            onClick = {
              val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${driver.phone}"))
              context.startActivity(dialIntent)
            },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("कॉल करें", style = MaterialTheme.typography.labelSmall)
          }
        }

        Button(
          onClick = {
            FormatUtils.shareDriverSummary(context, driver, entries, payments, businessName)
          },
          modifier = Modifier.weight(1.3f),
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
        ) {
          Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
          Spacer(modifier = Modifier.width(4.dp))
          Text("व्हाट्सएप पर खाता भेजें", style = MaterialTheme.typography.labelSmall, color = Color.White)
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Financial Summary Box
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(14.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("कुल दिया गया एडवांस:", style = MaterialTheme.typography.bodySmall)
            Text(FormatUtils.formatRupee(totalAdvances), fontWeight = FontWeight.Bold, color = SalaryPurple)
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("कुल ट्रिप खर्च:", style = MaterialTheme.typography.bodySmall)
            Text(FormatUtils.formatRupee(totalExpense), fontWeight = FontWeight.Bold, color = KharchRed)
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("कुल जमा / भाड़ा मिला:", style = MaterialTheme.typography.bodySmall)
            Text(FormatUtils.formatRupee(totalDeposit), fontWeight = FontWeight.Bold, color = JamaGreen)
          }
          Spacer(modifier = Modifier.height(6.dp))
          Divider(color = BorderLight)
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("कुल शुद्ध बाकी रकम:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
              Text(
                text = if (netBalance >= 0) "चालक के पास शेष / जमा" else "मालिक से लेना बाकी",
                style = MaterialTheme.typography.labelSmall,
                color = if (netBalance >= 0) JamaGreen else KharchRed
              )
            }
            Text(
              text = FormatUtils.formatRupee(Math.abs(netBalance)),
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Bold,
              color = if (netBalance >= 0) JamaGreen else KharchRed
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Action Buttons: + एडवांस / भुगतान & + ट्रिप हिसाब
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Button(
          onClick = onAddPayment,
          modifier = Modifier
            .weight(1f)
            .testTag("file_add_payment_btn"),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
          Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
          Spacer(modifier = Modifier.width(6.dp))
          Text("+ एडवांस / भुगतान", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
        }

        OutlinedButton(
          onClick = onAddHisab,
          modifier = Modifier
            .weight(1f)
            .testTag("file_add_trip_hisab_btn"),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("+ ट्रिप हिसाब", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Tab Row for Advance / Payments vs Trip Hisab
      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.primary
      ) {
        Tab(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          text = { Text("एडवांस व भुगतान (${payments.size})", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal) }
        )
        Tab(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          text = { Text("ट्रिप हिसाब (${entries.size})", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal) }
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Tab Content: Payments Tab (Tab 0)
      if (selectedTab == 0) {
        if (payments.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(200.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("कोई एडवांस या भुगतान दर्ज नहीं है।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Spacer(modifier = Modifier.height(6.dp))
              Text("'+ एडवांस / भुगतान' बटन दबाकर भुगतान जोड़ें।", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
          }
        } else {
          LazyColumn(
            modifier = Modifier
              .fillMaxWidth()
              .height(260.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            items(payments, key = { it.id }) { pay ->
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Text(
                        text = DateUtils.formatToHindiDisplayDate(pay.date),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                      )
                      Spacer(modifier = Modifier.width(8.dp))
                      Box(
                        modifier = Modifier
                          .clip(RoundedCornerShape(4.dp))
                          .background(SalaryPurpleBg)
                          .padding(horizontal = 6.dp, vertical = 2.dp)
                      ) {
                        Text(pay.paymentType, style = MaterialTheme.typography.labelSmall, color = SalaryPurple, fontWeight = FontWeight.Bold)
                      }
                    }
                    Text(
                      text = "माध्यम: ${pay.paymentMode}${if (pay.remarks.isNotBlank()) " • ${pay.remarks}" else ""}",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }

                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = FormatUtils.formatRupee(pay.amount),
                      style = MaterialTheme.typography.titleMedium,
                      fontWeight = FontWeight.Bold,
                      color = SalaryPurple
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                      onClick = { onDeletePayment(pay.id) },
                      modifier = Modifier.size(28.dp)
                    ) {
                      Icon(Icons.Default.Delete, contentDescription = "हटाएं", tint = KharchRed.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                    }
                  }
                }
              }
            }
          }
        }
      }

      // Tab Content: Trip Entries (Tab 1)
      if (selectedTab == 1) {
        if (entries.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(200.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("इस ड्राइवर का कोई दैनिक ट्रिप हिसाब नहीं मिला।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Spacer(modifier = Modifier.height(6.dp))
              Text("'+ ट्रिप हिसाब' दबाकर दैनिक हिसाब जोड़ें।", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
          }
        } else {
          LazyColumn(
            modifier = Modifier
              .fillMaxWidth()
              .height(260.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            items(entries, key = { it.id }) { item ->
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = DateUtils.formatToHindiDisplayDate(item.date),
                      style = MaterialTheme.typography.bodyMedium,
                      fontWeight = FontWeight.Bold
                    )
                    if (item.notes.isNotBlank()) {
                      Text(text = item.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                      text = "खर्च: ${FormatUtils.formatRupee(item.expenseTotal)} • जमा: ${FormatUtils.formatRupee(item.deposit)}",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }

                  Column(horizontalAlignment = Alignment.End) {
                    Text(
                      text = FormatUtils.formatRupee(item.balance),
                      style = MaterialTheme.typography.titleSmall,
                      fontWeight = FontWeight.Bold,
                      color = if (item.balance >= 0) JamaGreen else KharchRed
                    )
                    Text(
                      text = if (item.balance >= 0) "जमा शेष" else "देना बाकी",
                      style = MaterialTheme.typography.labelSmall,
                      color = if (item.balance >= 0) JamaGreen else KharchRed
                    )
                  }

                  Spacer(modifier = Modifier.width(4.dp))
                  IconButton(
                    onClick = { onDeleteEntry(item.id) },
                    modifier = Modifier.size(28.dp)
                  ) {
                    Icon(Icons.Default.Delete, contentDescription = "हटाएं", tint = KharchRed.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
