package com.example.util

import android.content.Context
import android.content.Intent
import com.example.data.model.Driver
import com.example.data.model.HisabEntry
import java.text.NumberFormat
import java.util.Locale

object FormatUtils {
  private val indianLocale = Locale("en", "IN")
  private val currencyFormatter = NumberFormat.getCurrencyInstance(indianLocale).apply {
    maximumFractionDigits = 0
  }

  fun formatRupee(amount: Double): String {
    return try {
      val formatted = currencyFormatter.format(amount)
      // Ensure clean ₹ symbol without extra code
      if (!formatted.startsWith("₹")) {
        "₹ " + String.format(Locale.US, "%,.0f", amount)
      } else {
        formatted
      }
    } catch (e: Exception) {
      "₹ " + String.format(Locale.US, "%,.0f", amount)
    }
  }

  fun formatCurrency(amount: Double): String = formatRupee(amount)

  fun shareHisabSlip(context: Context, entry: HisabEntry, businessName: String = "ट्रक ट्रांसपोर्ट") {
    val formattedDate = DateUtils.formatToHindiDisplayDate(entry.date)
    val bakiText = if (entry.balance >= 0) {
      "+ ${formatRupee(entry.balance)} (चालक के पास शेष / जमा)"
    } else {
      "- ${formatRupee(Math.abs(entry.balance))} (मालिक से लेना बाकी)"
    }

    val sb = StringBuilder()
    sb.appendLine("🚚 *दैनिक ट्रक हिसाब पर्ची*")
    sb.appendLine("🏢 *$businessName*")
    sb.appendLine("━━━━━━━━━━━━━━━━━━━")
    sb.appendLine("📅 तारीख: $formattedDate")
    sb.appendLine("👤 ड्राइवर: ${entry.driverName}")
    sb.appendLine("🚛 गाड़ी नंबर: ${entry.truckNumber}")
    if (entry.notes.isNotBlank()) {
      sb.appendLine("📍 रूट / टिप्पणी: ${entry.notes}")
    }
    sb.appendLine("───────────────────")
    if (entry.salary > 0) {
      sb.appendLine("💵 वेतन (Salary): ${formatRupee(entry.salary)}")
    }
    if (entry.dieselExpense > 0) {
      sb.appendLine("⛽ डीजल खर्च: ${formatRupee(entry.dieselExpense)}")
    }
    if (entry.tollExpense > 0) {
      sb.appendLine("🛣️ टोल / फ़ास्टैग: ${formatRupee(entry.tollExpense)}")
    }
    if (entry.repairExpense > 0) {
      sb.appendLine("🔧 मरम्मत / टायर: ${formatRupee(entry.repairExpense)}")
    }
    if (entry.foodExpense > 0) {
      sb.appendLine("🍲 खाना / दैनिक भत्ता: ${formatRupee(entry.foodExpense)}")
    }
    if (entry.otherExpense > 0) {
      sb.appendLine("📝 अन्य खर्च: ${formatRupee(entry.otherExpense)}")
    }
    sb.appendLine("━━━━━━━━━━━━━━━━━━━")
    sb.appendLine("🔴 *कुल खर्च (Total Expense):* ${formatRupee(entry.expenseTotal)}")
    sb.appendLine("🟢 *जमा / भाड़ा (Total Jama):* ${formatRupee(entry.deposit)}")
    sb.appendLine("━━━━━━━━━━━━━━━━━━━")
    sb.appendLine("⚖️ *बाकी रकम (Net Balance):* $bakiText")
    sb.appendLine("━━━━━━━━━━━━━━━━━━━")
    sb.appendLine("📱 *MySmart Dairy App द्वारा प्रेषित*")

    val sendIntent = Intent().apply {
      action = Intent.ACTION_SEND
      putExtra(Intent.EXTRA_TEXT, sb.toString())
      type = "text/plain"
    }
    val shareIntent = Intent.createChooser(sendIntent, "हिसाब पर्ची शेयर करें")
    context.startActivity(shareIntent)
  }

  fun shareDriverSummary(
    context: Context,
    driver: Driver,
    entries: List<HisabEntry>,
    payments: List<com.example.data.model.DriverPayment> = emptyList(),
    businessName: String = "ट्रक ट्रांसपोर्ट"
  ) {
    val totalSalary = entries.sumOf { it.salary }
    val totalExpense = entries.sumOf { it.expenseTotal }
    val totalDeposit = entries.sumOf { it.deposit }
    val tripBalance = entries.sumOf { it.balance }

    val totalAdvances = payments.filter { it.paymentType.contains("एडवांस") || it.paymentType.contains("Advance") }.sumOf { it.amount }
    val totalSalaryPaid = payments.filter { it.paymentType.contains("वेतन") || it.paymentType.contains("Salary") }.sumOf { it.amount }
    val finalBalance = tripBalance + totalAdvances - totalSalaryPaid

    val sb = StringBuilder()
    sb.appendLine("📋 *ड्राइवर हिसाब-किताब फाइल (Driver Ledger File)*")
    sb.appendLine("🏢 *$businessName*")
    sb.appendLine("━━━━━━━━━━━━━━━━━━━")
    sb.appendLine("👤 ड्राइवर का नाम: ${driver.name}")
    if (driver.phone.isNotBlank()) sb.appendLine("📞 फोन नंबर: ${driver.phone}")
    if (driver.assignedTruck.isNotBlank()) sb.appendLine("🚛 आवंटित गाड़ी: ${driver.assignedTruck}")
    if (driver.monthlySalary > 0) sb.appendLine("💵 तय मासिक वेतन: ${formatRupee(driver.monthlySalary)}")
    sb.appendLine("━━━━━━━━━━━━━━━━━━━")
    sb.appendLine("📊 *ट्रिप हिसाब सारांश:*")
    sb.appendLine("• कुल ट्रिप दिन: ${entries.size}")
    sb.appendLine("• कुल जमा भाड़ा: ${formatRupee(totalDeposit)}")
    sb.appendLine("• कुल ट्रिप खर्च: ${formatRupee(totalExpense)}")
    sb.appendLine("• कुल ट्रिप दैनिक वेतन: ${formatRupee(totalSalary)}")
    sb.appendLine("• ट्रिप रोकड़ शेष: ${formatRupee(tripBalance)}")
    sb.appendLine("───────────────────")
    sb.appendLine("💸 *भुगतान व एडवांस सारांश:*")
    sb.appendLine("• दिया गया कुल एडवांस: ${formatRupee(totalAdvances)}")
    sb.appendLine("• दिया गया वेतन भुगतान: ${formatRupee(totalSalaryPaid)}")
    sb.appendLine("━━━━━━━━━━━━━━━━━━━")
    val bakiLabel = if (finalBalance >= 0) "चालक के पास शेष / जमा" else "मालिक से लेना बाकी"
    sb.appendLine("⚖️ *अंतिम बाकी रकम:* ${formatRupee(Math.abs(finalBalance))} ($bakiLabel)")
    sb.appendLine("━━━━━━━━━━━━━━━━━━━")

    if (payments.isNotEmpty()) {
      sb.appendLine("📝 *हालिया भुगतान विवरण:*")
      payments.take(5).forEach { p ->
        sb.appendLine("• ${DateUtils.formatToHindiDisplayDate(p.date)}: ${formatRupee(p.amount)} [${p.paymentType} - ${p.paymentMode}] ${if (p.remarks.isNotBlank()) "(${p.remarks})" else ""}")
      }
      sb.appendLine("━━━━━━━━━━━━━━━━━━━")
    }

    sb.appendLine("📱 *MySmart Dairy App द्वारा स्वचालित तैयार*")

    val sendIntent = Intent().apply {
      action = Intent.ACTION_SEND
      putExtra(Intent.EXTRA_TEXT, sb.toString())
      type = "text/plain"
    }
    val shareIntent = Intent.createChooser(sendIntent, "ड्राइवर खाता शेयर करें")
    context.startActivity(shareIntent)
  }

  fun shareTruckSummary(
    context: Context,
    truck: com.example.data.model.Truck,
    entries: List<HisabEntry>,
    businessName: String = "ट्रक ट्रांसपोर्ट"
  ) {
    val totalIncome = entries.sumOf { it.deposit }
    val totalDiesel = entries.sumOf { it.dieselExpense }
    val totalToll = entries.sumOf { it.tollExpense }
    val totalRepair = entries.sumOf { it.repairExpense }
    val totalSalary = entries.sumOf { it.salary }
    val totalFood = entries.sumOf { it.foodExpense }
    val totalOther = entries.sumOf { it.otherExpense }
    val totalExpense = entries.sumOf { it.expenseTotal + it.salary }
    val netProfitLoss = totalIncome - totalExpense
    val isProfit = netProfitLoss >= 0

    val sb = StringBuilder()
    sb.appendLine("🚛 *गाड़ी हिसाब-किताब फाइल (Truck Ledger File)*")
    sb.appendLine("🏢 *$businessName*")
    sb.appendLine("━━━━━━━━━━━━━━━━━━━")
    sb.appendLine("🔢 गाड़ी नंबर: ${truck.truckNumber}")
    sb.appendLine("🏷️ नाम / मॉडल: ${truck.truckName} ${if (truck.truckModel.isNotBlank()) "(${truck.truckModel})" else ""}")
    if (truck.assignedDriverName.isNotBlank()) sb.appendLine("👤 ड्राइवर: ${truck.assignedDriverName}")
    if (truck.notes.isNotBlank()) sb.appendLine("📍 परमिट / रूट: ${truck.notes}")
    sb.appendLine("━━━━━━━━━━━━━━━━━━━")
    sb.appendLine("📊 *कमाई व खर्च सारांश:*")
    sb.appendLine("• कुल ट्रिप संख्या: ${entries.size}")
    sb.appendLine("• 🟢 कुल कमाई (Freight Income): ${formatRupee(totalIncome)}")
    sb.appendLine("• 🔴 कुल खर्च (Total Expense): ${formatRupee(totalExpense)}")
    sb.appendLine("───────────────────")
    sb.appendLine("📑 *खर्चों का विवरण:*")
    sb.appendLine("  ⛽ डीजल: ${formatRupee(totalDiesel)}")
    sb.appendLine("  🛣️ टोल / फ़ास्टैग: ${formatRupee(totalToll)}")
    sb.appendLine("  🔧 मरम्मत / मेंटेनेंस: ${formatRupee(totalRepair)}")
    sb.appendLine("  💵 ड्राइवर वेतन / भत्ता: ${formatRupee(totalSalary)}")
    sb.appendLine("  🍲 खोराकी / खाना: ${formatRupee(totalFood)}")
    if (totalOther > 0) sb.appendLine("  📝 अन्य खर्च: ${formatRupee(totalOther)}")
    sb.appendLine("━━━━━━━━━━━━━━━━━━━")
    val profitLabel = if (isProfit) "✅ शुद्ध मुनाफा (Net Profit)" else "⚠️ शुद्ध घाटा (Net Loss)"
    sb.appendLine("⚖️ *$profitLabel:* ${formatRupee(Math.abs(netProfitLoss))}")
    sb.appendLine("━━━━━━━━━━━━━━━━━━━")

    if (entries.isNotEmpty()) {
      sb.appendLine("📝 *हालिया ट्रिप विवरण:*")
      entries.take(5).forEach { e ->
        sb.appendLine("• ${DateUtils.formatToHindiDisplayDate(e.date)}: जमा ${formatRupee(e.deposit)} | खर्च ${formatRupee(e.expenseTotal)} ${if (e.notes.isNotBlank()) "(${e.notes})" else ""}")
      }
      sb.appendLine("━━━━━━━━━━━━━━━━━━━")
    }

    sb.appendLine("📱 *MySmart Dairy App द्वारा जनरेट किया गया*")

    val sendIntent = Intent().apply {
      action = Intent.ACTION_SEND
      putExtra(Intent.EXTRA_TEXT, sb.toString())
      type = "text/plain"
    }
    val shareIntent = Intent.createChooser(sendIntent, "गाड़ी खाता शेयर करें")
    context.startActivity(shareIntent)
  }
}
