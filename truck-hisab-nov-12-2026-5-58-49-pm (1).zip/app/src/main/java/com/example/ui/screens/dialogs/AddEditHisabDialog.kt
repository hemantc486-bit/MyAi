package com.example.ui.screens.dialogs

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Driver
import com.example.data.model.HisabEntry
import com.example.data.model.Truck
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.JamaGreen
import com.example.ui.theme.JamaGreenBg
import com.example.ui.theme.KharchRed
import com.example.ui.theme.KharchRedBg
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SalaryPurple
import com.example.util.DateUtils
import com.example.util.FormatUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditHisabDialog(
  initialDate: String,
  editingEntry: HisabEntry?,
  allDrivers: List<Driver>,
  allTrucks: List<Truck> = emptyList(),
  onDismiss: () -> Unit,
  onSave: (HisabEntry) -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  var date by remember { mutableStateOf(editingEntry?.date ?: initialDate) }
  var selectedDriverId by remember { mutableStateOf(editingEntry?.driverId ?: allDrivers.firstOrNull()?.id ?: 0L) }
  var driverName by remember {
    mutableStateOf(
      editingEntry?.driverName
        ?: allDrivers.firstOrNull { it.id == selectedDriverId }?.name
        ?: ""
    )
  }
  var truckNumber by remember {
    mutableStateOf(
      editingEntry?.truckNumber
        ?: allDrivers.firstOrNull { it.id == selectedDriverId }?.assignedTruck
        ?: ""
    )
  }

  var salaryText by remember { mutableStateOf(if ((editingEntry?.salary ?: 0.0) > 0) editingEntry?.salary?.toInt().toString() else "") }
  var depositText by remember { mutableStateOf(if ((editingEntry?.deposit ?: 0.0) > 0) editingEntry?.deposit?.toInt().toString() else "") }

  // Expense breakdown
  var isBreakdownOpen by remember { mutableStateOf(editingEntry != null && (editingEntry.dieselExpense > 0 || editingEntry.tollExpense > 0)) }
  var totalExpenseText by remember { mutableStateOf(if ((editingEntry?.expenseTotal ?: 0.0) > 0) editingEntry?.expenseTotal?.toInt().toString() else "") }
  var dieselText by remember { mutableStateOf(if ((editingEntry?.dieselExpense ?: 0.0) > 0) editingEntry?.dieselExpense?.toInt().toString() else "") }
  var tollText by remember { mutableStateOf(if ((editingEntry?.tollExpense ?: 0.0) > 0) editingEntry?.tollExpense?.toInt().toString() else "") }
  var repairText by remember { mutableStateOf(if ((editingEntry?.repairExpense ?: 0.0) > 0) editingEntry?.repairExpense?.toInt().toString() else "") }
  var foodText by remember { mutableStateOf(if ((editingEntry?.foodExpense ?: 0.0) > 0) editingEntry?.foodExpense?.toInt().toString() else "") }
  var otherText by remember { mutableStateOf(if ((editingEntry?.otherExpense ?: 0.0) > 0) editingEntry?.otherExpense?.toInt().toString() else "") }

  var notes by remember { mutableStateOf(editingEntry?.notes ?: "") }
  var showDriverDropdown by remember { mutableStateOf(false) }

  // If breakdown fields are edited, recalculate total expense
  fun updateExpenseFromBreakdown() {
    val d = dieselText.toDoubleOrNull() ?: 0.0
    val t = tollText.toDoubleOrNull() ?: 0.0
    val r = repairText.toDoubleOrNull() ?: 0.0
    val f = foodText.toDoubleOrNull() ?: 0.0
    val o = otherText.toDoubleOrNull() ?: 0.0
    val sum = d + t + r + f + o
    if (sum > 0) {
      totalExpenseText = sum.toInt().toString()
    }
  }

  // Calculated values
  val salaryVal = salaryText.toDoubleOrNull() ?: 0.0
  val depositVal = depositText.toDoubleOrNull() ?: 0.0
  val expenseVal = totalExpenseText.toDoubleOrNull() ?: 0.0
  val balanceVal = depositVal - (salaryVal + expenseVal)

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp)
        .padding(bottom = 36.dp)
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = if (editingEntry != null) "हिसाब संशोधित करें (Edit)" else "नया दैनिक हिसाब दर्ज करें",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
          Text(
            text = "तारीख: ${DateUtils.formatToHindiDisplayDate(date)}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        IconButton(
          onClick = onDismiss,
          modifier = Modifier.testTag("close_hisab_dialog_button")
        ) {
          Icon(Icons.Default.Close, contentDescription = "बंद करें")
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Quick driver selector chips
      Text(
        text = "ड्राइवर चुनें (Select Driver):",
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary
      )
      Spacer(modifier = Modifier.height(6.dp))

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        allDrivers.forEach { drv ->
          val isSelected = drv.id == selectedDriverId
          FilterChip(
            selected = isSelected,
            onClick = {
              selectedDriverId = drv.id
              driverName = drv.name
              if (drv.assignedTruck.isNotBlank()) {
                truckNumber = drv.assignedTruck
              }
            },
            label = { Text(drv.name) },
            leadingIcon = if (isSelected) {
              { Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp)) }
            } else null
          )
        }
      }

      if (allTrucks.isNotEmpty()) {
        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = "गाड़ी चुनें (Select Truck):",
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.secondary
        )
        Spacer(modifier = Modifier.height(6.dp))

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          allTrucks.forEach { trk ->
            val isSelected = trk.truckNumber.trim().equals(truckNumber.trim(), ignoreCase = true)
            FilterChip(
              selected = isSelected,
              onClick = {
                truckNumber = trk.truckNumber
                if (trk.assignedDriverName.isNotBlank() && driverName.isBlank()) {
                  driverName = trk.assignedDriverName
                }
              },
              label = { Text(trk.truckNumber) },
              leadingIcon = if (isSelected) {
                { Icon(Icons.Default.AllInclusive, contentDescription = null, modifier = Modifier.size(16.dp)) }
              } else null
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Driver Name & Truck Number Fields
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = driverName,
          onValueChange = { driverName = it },
          label = { Text("ड्राइवर का नाम *") },
          modifier = Modifier
            .weight(1.2f)
            .testTag("hisab_driver_name_input"),
          singleLine = true,
          leadingIcon = {
            Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          }
        )

        OutlinedTextField(
          value = truckNumber,
          onValueChange = { truckNumber = it.uppercase() },
          label = { Text("गाड़ी नंबर *") },
          modifier = Modifier
            .weight(1f)
            .testTag("hisab_truck_number_input"),
          singleLine = true,
          leadingIcon = {
            Icon(Icons.Default.AllInclusive, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          }
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Financial Inputs Section (Salary, Expense, Deposit)
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(14.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          // 1. Salary Field
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(SalaryPurple.copy(alpha = 0.15f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Payment, contentDescription = null, tint = SalaryPurple, modifier = Modifier.size(22.dp))
            }
            OutlinedTextField(
              value = salaryText,
              onValueChange = { salaryText = it },
              label = { Text("वेतन / सैलरी (Salary) ₹") },
              placeholder = { Text("0") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              modifier = Modifier
                .weight(1f)
                .testTag("hisab_salary_input"),
              singleLine = true
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 2. Deposit / Jama Field
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(JamaGreen.copy(alpha = 0.15f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.TrendingUp, contentDescription = null, tint = JamaGreen, modifier = Modifier.size(22.dp))
            }
            OutlinedTextField(
              value = depositText,
              onValueChange = { depositText = it },
              label = { Text("जमा / मिला भाड़ा / एडवांस (Deposit) ₹") },
              placeholder = { Text("0") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              modifier = Modifier
                .weight(1f)
                .testTag("hisab_deposit_input"),
              singleLine = true
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 3. Expense (खर्च) Field
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(KharchRed.copy(alpha = 0.15f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.TrendingDown, contentDescription = null, tint = KharchRed, modifier = Modifier.size(22.dp))
            }
            OutlinedTextField(
              value = totalExpenseText,
              onValueChange = { totalExpenseText = it },
              label = { Text("कुल खर्च (Total Expense) ₹ *") },
              placeholder = { Text("0") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              modifier = Modifier
                .weight(1f)
                .testTag("hisab_expense_input"),
              singleLine = true
            )
          }

          // Toggle for Expense Breakdown (डीजल, टोल, खाना, आदि)
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { isBreakdownOpen = !isBreakdownOpen }
              .padding(top = 8.dp, bottom = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = if (isBreakdownOpen) "खर्च का विवरण छुपाएं" else "खर्च का अलग-अलग विवरण भरें (डीजल, टोल, खाना...)",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.secondary,
              fontWeight = FontWeight.SemiBold
            )
            Icon(
              imageVector = if (isBreakdownOpen) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.secondary
            )
          }

          // Breakdown Fields
          AnimatedVisibility(visible = isBreakdownOpen) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                OutlinedTextField(
                  value = dieselText,
                  onValueChange = {
                    dieselText = it
                    updateExpenseFromBreakdown()
                  },
                  label = { Text("डीजल (Fuel) ₹") },
                  modifier = Modifier.weight(1f),
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                  singleLine = true
                )
                OutlinedTextField(
                  value = tollText,
                  onValueChange = {
                    tollText = it
                    updateExpenseFromBreakdown()
                  },
                  label = { Text("टोल / Fastag ₹") },
                  modifier = Modifier.weight(1f),
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                  singleLine = true
                )
              }

              Spacer(modifier = Modifier.height(8.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                OutlinedTextField(
                  value = repairText,
                  onValueChange = {
                    repairText = it
                    updateExpenseFromBreakdown()
                  },
                  label = { Text("मरम्मत / टायर ₹") },
                  modifier = Modifier.weight(1f),
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                  singleLine = true
                )
                OutlinedTextField(
                  value = foodText,
                  onValueChange = {
                    foodText = it
                    updateExpenseFromBreakdown()
                  },
                  label = { Text("ड्राइवर खाना / खोराकी ₹") },
                  modifier = Modifier.weight(1f),
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                  singleLine = true
                )
              }

              Spacer(modifier = Modifier.height(8.dp))

              OutlinedTextField(
                value = otherText,
                onValueChange = {
                  otherText = it
                  updateExpenseFromBreakdown()
                },
                label = { Text("चालान / अन्य खर्च ₹") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Live Calculated "बाकी रकम" (Balance Card)
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("balance_preview_card"),
        colors = CardDefaults.cardColors(
          containerColor = if (balanceVal >= 0) JamaGreenBg else KharchRedBg
        ),
        shape = RoundedCornerShape(14.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "बाकी रकम (Net Balance)",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = if (balanceVal >= 0) JamaGreen else KharchRed
            )
            Text(
              text = if (balanceVal >= 0)
                "चालक के पास जमा शेष"
              else
                "मालिक की तरफ से देना बाकी",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          Text(
            text = FormatUtils.formatRupee(balanceVal),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = if (balanceVal >= 0) JamaGreen else KharchRed
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Notes / Route Info
      OutlinedTextField(
        value = notes,
        onValueChange = { notes = it },
        label = { Text("रूट / विवरण / टिप्पणी (Notes)") },
        placeholder = { Text("जैसे: जयपुर से दिल्ली - 25 टन सीमेंट") },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("hisab_notes_input"),
        minLines = 2,
        maxLines = 3
      )

      Spacer(modifier = Modifier.height(20.dp))

      // Action Buttons
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        OutlinedButton(
          onClick = onDismiss,
          modifier = Modifier
            .weight(1f)
            .height(50.dp),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text("रद्द करें")
        }

        Button(
          onClick = {
            if (driverName.isBlank() || truckNumber.isBlank()) {
              return@Button
            }

            val entry = HisabEntry(
              id = editingEntry?.id ?: 0L,
              date = date,
              driverId = selectedDriverId,
              driverName = driverName.trim(),
              truckNumber = truckNumber.trim().uppercase(),
              salary = salaryVal,
              expenseTotal = expenseVal,
              dieselExpense = dieselText.toDoubleOrNull() ?: 0.0,
              tollExpense = tollText.toDoubleOrNull() ?: 0.0,
              repairExpense = repairText.toDoubleOrNull() ?: 0.0,
              foodExpense = foodText.toDoubleOrNull() ?: 0.0,
              otherExpense = otherText.toDoubleOrNull() ?: 0.0,
              deposit = depositVal,
              balance = balanceVal,
              notes = notes.trim(),
              createdAt = editingEntry?.createdAt ?: System.currentTimeMillis()
            )
            onSave(entry)
          },
          modifier = Modifier
            .weight(1.5f)
            .height(50.dp)
            .testTag("save_hisab_button"),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
          enabled = driverName.isNotBlank() && truckNumber.isNotBlank()
        ) {
          Text(
            text = "हिसाब सुरक्षित करें",
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }
      }
    }
  }
}
