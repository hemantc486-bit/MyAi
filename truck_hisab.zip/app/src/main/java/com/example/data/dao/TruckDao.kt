package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Truck
import kotlinx.coroutines.flow.Flow

@Dao
interface TruckDao {
  @Query("SELECT * FROM trucks ORDER BY truckNumber ASC")
  fun getAllTrucks(): Flow<List<Truck>>

  @Query("SELECT * FROM trucks WHERE id = :id LIMIT 1")
  suspend fun getTruckById(id: Long): Truck?

  @Query("SELECT * FROM trucks WHERE truckNumber = :truckNumber LIMIT 1")
  suspend fun getTruckByNumber(truckNumber: String): Truck?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTruck(truck: Truck): Long

  @Update
  suspend fun updateTruck(truck: Truck)

  @Delete
  suspend fun deleteTruck(truck: Truck)

  @Query("DELETE FROM trucks WHERE id = :id")
  suspend fun deleteTruckById(id: Long)

  @Query("SELECT COUNT(*) FROM trucks")
  suspend fun getTruckCount(): Int
}
